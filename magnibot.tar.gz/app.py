from threading import Lock
from flask import Flask, Response, render_template, session, request, \
    copy_current_request_context
from flask_socketio import SocketIO, emit, join_room, leave_room, \
    close_room, rooms, disconnect
import socket
import time 
import os
from datetime import datetime
import ZoomLib as ZoomLib
import WifiLib as WifiLib
import subprocess 
import json
import jinja2
from flask import send_file

DEBUG=True

# Set this to "library" or "binary" to use a Python C wrapped .so  or a binary file (.bin)


app = Flask(__name__)
app.config.from_pyfile('config.py')

if app.config['DISABLE_HTML_LOGGING']:
    import logging
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.ERROR)
if app.config['ENABLE_MOTORS']:
    import RPi.GPIO as GPIO
    import RpiMotorLib as RpiMotorLib
    cameraZoom = ZoomLib.ZoomLib("binary")
    try:
        current_zoom = cameraZoom.zoomStop() - 1
    except:
        print("Can't access camera!")
    print( type(cameraZoom) )

wifi_lib = WifiLib.WifiLib()

host = socket.gethostname()
port = 8080                   # The same port as used by the server

# Set this variable to "threading", "eventlet" or "gevent" to test the
# different async modes, or leave it set to None for the application to choose
# the best option based on installed packages.
#async_mode = None
async_mode = 'threading'
MIN_ZOOM = 0
MAX_ZOOM = 29

current_distance = 0
horizontal_direction = 0
no_movement_x = 0
vertical_direction = 0
MAX_DISTANCE = 200
MIN_DISTANCE = 5
MAX_SPEED = 0.005
MIN_SPEED = 0.03
MAX_SPEED_HORIZONTAL = 0.002
MIN_SPEED_HORIZONTAL = 0.02

socketio = SocketIO(app, async_mode=async_mode, logger = False)
thread = None
thread_lock = Lock()

import JSONLib as JSONLib
import check_for_update as UpdateChecker

json_obj = JSONLib.JSONLib()
tmpUpdater=UpdateChecker.UpdaterLib()




print('Started')

if app.config['ENABLE_MOTORS']:
    hMotor = RpiMotorLib.BYJMotor("HorizontalMotor", "28BYJ")
    vMotor = RpiMotorLib.BYJMotor("VerticalMotor", "28BYJ")
    hGpioPins = [29,31,33,35]
    vGpioPins = [8,10,12,16]

@app.route('/')
def index():
    if json_obj.get_video_mode()==0:
        return render_template('index.html', async_mode=socketio.async_mode, is_video_h264=1)      
    else:
        return render_template('index.html', async_mode=socketio.async_mode, is_video_h264=0)      


#socket.emit('pan_setarea', {box_bounds: MAX_FINGER_AREA });
@socketio.event
def pan_setarea(message):
    global MAX_DISTANCE
    global MIN_DISTANCE
    # Divide whole rect to get distance from origin
    MIN_DISTANCE = message['min_distance']  
    MAX_DISTANCE = message['box_bounds'] / 2 

@socketio.event
def check_for_update():
    print("Checking for update")
    if DEBUG:
        socketio.emit("check_for_update_response",{'data': False})    
    else:
        socketio.emit("check_for_update_response",{'data': tmpUpdater.check_for_update()})

    
@socketio.event
def update_app():
    print("Updating")
    subprocess.Popen(['rm','/home/pi/magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    subprocess.Popen(['rm','magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # process = subprocess.Popen(['./download_from_github.sh','-v',tmpUpdater.get_latest_tag()],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # process = subprocess.Popen(['wget','https://trysight.com/downloads/magnibot/magnibot.tar.gz','/home/pi/magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    process = subprocess.Popen(['wget', 'https://github.com/trysightdev/magnibot_releases/raw/main/magnibot.tar.gz' ],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    file_stats = os.stat('magnibot.tar.gz')
    if file_stats.st_size==tmpUpdater.get_file_size():
        print("Filesize: " , file_stats.st_size, " ", tmpUpdater.get_file_size())
        subprocess.Popen(['mv','magnibot.tar.gz','/home/pi/magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        subprocess.Popen(['touch','/home/pi/FINISHED_DOWNLOADING'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    else:
        socketio.emit('refresh_window')
        print("Updating failed")

@socketio.event
def toggle_h264(message):
    json_obj.set_video_mode(message['format'])
    json_obj.set_video_resolution(message['resolution'])
    video_format=""
    video_resolution=""
    if json_obj.get_video_mode()==0:
        video_format="H264"
    elif json_obj.get_video_mode()==1:
        video_format="MJPEG"

    if json_obj.get_video_resolution()==0:
        video_resolution="1920x1080"
    elif json_obj.get_video_resolution()==1:
        video_resolution="1280x720"
    elif json_obj.get_video_resolution()==2:
        video_resolution="640x480"

    process = subprocess.Popen(['./change_resolution.sh','-m',video_format,'-r',video_resolution, '-f', '30'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    ssid = "";
    print("", out, err)
    if DEBUG:
        subprocess.Popen(['sudo','systemctl','restart','ustreamer.service'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        time.sleep(10)
        socketio.emit('refresh_window')
    else:
        subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE) 
    


@socketio.event
def pan_event(message):
    global current_zoom
    global horizontal_direction
    global vertical_direction
    global no_movement_x
    rspText = message['data']
    distanceFromOrigin = message['distanceFromOrigin']
    dAngle = message['angle_degrees']
    deltaXY = max(min(abs(distanceFromOrigin) , MAX_DISTANCE), 0)
    session['receive_count'] = session.get('receive_count', 0) + 1
    # Lower everything by a step or increase by a step so that when at the lowest level it will be the minimum speed and max speed.
    pctZoom = current_zoom/MAX_ZOOM
    pctDistanceXY = abs(deltaXY) / MAX_DISTANCE
    SPEED_RANGE = abs(MAX_SPEED - MIN_SPEED)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    ZOOM_ADJUSTMENT = pctZoom * 0.05
    speedXY = max( MIN_SPEED - ( 0.06 * pctDistanceXY ) + ZOOM_ADJUSTMENT, MAX_SPEED)
    SPEED_RANGE_HORIZONTAL = abs(MAX_SPEED_HORIZONTAL - MIN_SPEED_HORIZONTAL)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    speedXY_horizontal = max( MIN_SPEED_HORIZONTAL - ( 0.06 * pctDistanceXY ) + ZOOM_ADJUSTMENT, MAX_SPEED_HORIZONTAL)
    #emit('my_response',{'data': message['data'], 'count': session['receive_count']})
    ANGLE_THRESHOLD = 30
    if rspText == "pan":
        # Only switch directions if there is a change of 10px of distance within the last 100ms
        if abs(deltaXY) > MIN_DISTANCE:
            if( dAngle > 180 - ANGLE_THRESHOLD and dAngle < 180 + ANGLE_THRESHOLD):
                if horizontal_direction == 0:
                    horizontal_direction = 1
                    hMotor.motor_run(hGpioPins, speedXY_horizontal,False,False,"half", .00)
                elif horizontal_direction == 2:
                    hMotor.motor_stop()
                    horizontal_direction = 0
                elif horizontal_direction == 1:
                    hMotor.motor_speed(speedXY_horizontal)
            elif( dAngle > 360 - ANGLE_THRESHOLD or dAngle < 0 + ANGLE_THRESHOLD ):
                if horizontal_direction == 0:
                    horizontal_direction = 2
                    hMotor.motor_run(hGpioPins, speedXY_horizontal,True,False,"half", .00)
                elif horizontal_direction == 1:
                    hMotor.motor_stop()
                    horizontal_direction = 0
                elif horizontal_direction == 2:
                    hMotor.motor_speed(speedXY_horizontal)
            else:
                hMotor.motor_stop()
                horizontal_direction = 0

            if( dAngle > 270 - ANGLE_THRESHOLD and dAngle < 270 + ANGLE_THRESHOLD):
                if vertical_direction == 0:
                    vertical_direction = 1
                    vMotor.motor_run(vGpioPins, speedXY,True,False,"half", .00)
                elif vertical_direction == 2:
                    vMotor.motor_stop()
                    vertical_direction = 0
                elif vertical_direction == 1:
                    vMotor.motor_speed(speedXY)
            elif( dAngle > 90 - ANGLE_THRESHOLD and dAngle < 90 + ANGLE_THRESHOLD ):
                if vertical_direction == 0:
                    vertical_direction = 2
                    vMotor.motor_run(vGpioPins, speedXY,False,False,"half", .00)
                elif vertical_direction == 1:
                    vMotor.motor_stop()
                    vertical_direction = 0
                elif vertical_direction == 2:
                    vMotor.motor_speed(speedXY)
            else:
                vMotor.motor_stop()
                vertical_direction = 0
        else:
            if vertical_direction != 0:
                no_movement_x+=1
                if no_movement_x > 2:
                    vMotor.motor_stop()
                    vertical_direction = 0
            if horizontal_direction != 0:
                no_movement_x+=1
                if no_movement_x > 2:
                    hMotor.motor_stop()
                    horizontal_direction = 0
    elif rspText == "panend":
         hMotor.motor_stop()
         vMotor.motor_stop()
         horizontal_direction = 0
         vertical_direction = 0


@socketio.event
def my_event(message):
    global current_zoom
    rspText = message['data']
    session['receive_count'] = session.get('receive_count', 0) + 1
    # Lower everything by a step or increase by a step so that when at the lowest level it will be the minimum speed and max speed.
    pctZoom = current_zoom / MAX_ZOOM
    SPEED_RANGE = abs(MAX_SPEED - MIN_SPEED)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    speed = MAX_SPEED + ( SPEED_RANGE * pctZoom )
    SPEED_RANGE_HORIZONTAL = abs(MAX_SPEED_HORIZONTAL - 0.01)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    speed_horizontal = MAX_SPEED_HORIZONTAL + ( SPEED_RANGE_HORIZONTAL * pctZoom )
#    emit('my_response',{'data': message['data'], 'count': session['receive_count']})
    if not app.config['DISABLE_HTML_LOGGING']:
        emit('my_response',{'data': message['data'], 'count': session['receive_count']})
    if app.config['ENABLE_MOTORS']:
        if rspText.find("right") != -1:
            hMotor.motor_run(hGpioPins, speed_horizontal,False,False,"half", .00)
        elif rspText.find("left") != -1:
            hMotor.motor_run(hGpioPins, speed_horizontal,True,False,"half", .00)
        elif rspText.find("up") != -1:
            vMotor.motor_run(vGpioPins,speed,True,False,"half", .00)
        elif rspText.find("down") != -1:
            vMotor.motor_run(vGpioPins,speed,False,False,"half", .00)
        elif rspText.find("stopHorizontal") != -1:
            hMotor.motor_stop()
        elif rspText.find("stopVertical") != -1:
            vMotor.motor_stop()
    else:
        print("Motors disabled")
    if rspText.find("zoomin") != -1:
        cameraZoom.zoomIn()
    elif rspText.find("zoomout") != -1:
        cameraZoom.zoomOut()
    elif rspText.find("zoomstop") != -1:
        current_zoom = cameraZoom.zoomStop() - 1
        emit('my_response',{'data': 'speed: ' + str(speed) + ', zoom: ' + str(current_zoom), 'count': session['receive_count']})
    
def getBatteryLevel():
#    battery_level =  core.get_battery_percent()
#    process = subprocess.Popen(['./pisugar-poweroff'],cwd = './lib', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p1 = subprocess.Popen(["echo","get battery"], stdout=subprocess.PIPE)
    p2 = subprocess.Popen(["nc","-q","0","127.0.0.1","8423"], stdin=p1.stdout, stdout=subprocess.PIPE)
    out_level, err = p2.communicate()
    p3 = subprocess.Popen(["echo","get battery_power_plugged"], stdout=subprocess.PIPE)    
    p4 = subprocess.Popen(["nc","-q","0","127.0.0.1","8423"], stdin=p3.stdout, stdout=subprocess.PIPE)
    out_plugged, err = p4.communicate()
    if out_level.decode("utf-8") == '':
        socketio.emit('update_batterylevel', {'data':  0 , "is_plugged": 0 })
    else: 
        results = out_level.decode("utf-8").replace('\n','').split(' ')
        battery_level = int(results[1].split('.')[0])
        results = out_plugged.decode("utf-8").replace('\n','').split(' ')
        is_plugged = results[1]
        if is_plugged.find("true")!=-1:
            plugged = 1
        else:
            plugged = 0
        socketio.emit('update_batterylevel',
            {'data':  battery_level , "is_plugged": plugged })
def check_network_connection():
    process = subprocess.Popen(['iw','dev'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    ssid = "";
#    print("", out, err)
    if err == '':
        try:
            results = out.split("Interface")[2].split('\n')
        except:
            print("USB Wifi is not connected!")
            return
 #       print("", results)
        for x in results:
            if x.find("ssid") != -1:
                s_pos = x.find(" ") + 1
                ssid = x[s_pos:].replace('"','')
                print("", ssid)

    emit('my_response', {'data': ssid, 'count': 0})


def update_wifi():
    check_network_connection()
    process = subprocess.Popen(['sudo','iwlist','wlan0','scan'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()

#    print("",out.decode("utf-8"), err) 
    if out.decode("utf-8") == '':
        socketio.emit('update_wifi', { 'data': ''})
    else: 
        #results = out.decode("utf-8").replace(' ','').replace('\n',';').replace('\\','').split('Cell')
        results = out.decode("utf-8").replace('\\','').split('Cell')
        wifi_list = []
        wifi_array = []
        for x in results:
            SSID = ""
            Encryption = ""
            Quality = ""
            for y in x.split('\n'):
                if y.find("Quality") != -1:
                    tmp = y.split('Quality=')[1].split('S')[0].split('/')
                    Quality = int(float(tmp[0]) / float(tmp[1]) * 100.0)
                if y.find("Encryption") != -1:
                    if y.split(':')[1].find("on") != -1:
                        Encryption = 0
                    else:
                        Encryption = 1
                if y.find("SSID") != -1:
                    SSID += y.split('ESSID:')[1] 
                    if SSID.find("magnibot") != -1:
                        continue
                    if len(SSID) == 2:
                        print("",len(SSID))
                        continue
                    wifi_array.append([SSID, Quality, Encryption]) 
        wifi_array.sort(key=lambda tup: tup[1],reverse=True)
        for w in wifi_array:
            wifi_string = "{\"SSID\": " + w[0] + ", " + "\"Quality\": \"" + str(w[1]) + "\", " + "\"Encryption\": \"" + str(w[2]) + "\"}"
            print(wifi_string)
            wifi_list.append(wifi_string)
        socketio.emit('update_wifi', { 'data': wifi_list})

def change_ssid():
    process = subprocess.Popen(['bash','-c','./change_ssid.sh'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    ssid = "";
    print("", out, err)

@socketio.event
def connect_wifi(message):
    print("",message)
    wifi_lib.connect( message['SSID'], message['NO_PWD'], message['PWD'] )
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

@socketio.event
def my_ping():
    emit('my_pong')
    

@socketio.event
def disconnect_wifi():
    print("Disconnect wifi")
    wifi_lib.disconnect()
#    time.sleep(15)
#    socketio.emit('refresh_window')
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

@socketio.event
def set_rotation(message):
    print("",message)
    global json_obj
    json_obj.set_rotation(message['rotation_value'])
    print('updated: ',json_obj.get_rotation())

@socketio.event
def set_brightness(message):
    print("",message)
    global json_obj
    json_obj.set_brightness(message['brightness_value'])
    print('updated: ',json_obj.get_brightness())

@socketio.event
def set_contrast(message):
    print("",message)
    global json_obj
    json_obj.set_contrast(message['contrast_value'])
    print('updated: ',json_obj.get_contrast())


@socketio.event
def restart():
    print("Reboot")
    #wifi_lib.disconnect()
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

@socketio.event
def take_snapshot():
    print("take_snapshot")
    timestr = '/images/img_' + time.strftime("%Y%m%d%H%M%S") + '.jpg'
    os.system('rm static/images/img_*.jpg' )
    os.system('curl http://localhost/snapshot > static' + timestr )
    socketio.emit('finished_take_snapshot', { 'data' : timestr})

@app.route('/getPlotCSV')
def return_files_tut():
        try:
            timestr = '/home/pi/Pictures/img_' + time.strftime("%Y%m%d%H%M%S") + '.jpg'
            os.system('curl http://localhost/snapshot > ' + timestr )
            return send_file(timestr, mimetype='image/jpeg',as_attachment=True)
        except Exception as e:
            print("",e)
            return str(e)
debug_counter = 0
def debug_thread():
    """Example of how to send server generated events to clients."""
    global debug_counter
    global horizontal_direction
    print("",horizontal_direction)
    if horizontal_direction == 2:
        horizontal_direction = 1
        hMotor.motor_stop()
        hMotor.motor_test(hGpioPins, 0.01,False,False,"half", .00,100)
    elif horizontal_direction == 1:
        horizontal_direction = 2
        hMotor.motor_stop()
        hMotor.motor_test(hGpioPins, 0.01,True,False,"half", .00,100)
    else:
        horizontal_direction = 1
    debug_counter+=1
    if debug_counter >= 2:
        subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

thread = None
thread_lock = Lock()
def background_thread():
    """Example of how to send server generated events to clients."""
    while True:
        socketio.sleep(10)
        getBatteryLevel()
#        debug_thread()


@socketio.event
def test_connect():
    if( tmpUpdater.internet_on() ):
        print("",tmpUpdater.check_for_update())
    else:
        print("",tmpUpdater.get_current_tag())
        print("No internet")
    socketio.emit(
            'first_connect',
            {
                'calibrated_rotation': json_obj.get_rotation() ,
                'calibrated_brightness': json_obj.get_brightness() , 
                'calibrated_contrast': json_obj.get_contrast() ,
                'video_format': json_obj.get_video_mode() ,
                'video_resolution': json_obj.get_video_resolution() ,
                'verson_code': json_obj.get_version_code() ,
                }) 
    global thread
    getBatteryLevel()
    with thread_lock:
        if thread is None:
            thread = socketio.start_background_task(background_thread)
    update_wifi()
    #socketio.emit('update_wifi', { 'data': ''})
if __name__ == '__main__':
    # change_ssid()
    socketio.run(app, host='127.0.0.1', port=5000, debug=True)
