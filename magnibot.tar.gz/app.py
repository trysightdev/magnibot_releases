from threading import Lock
from flask import Flask, Response, render_template, session, request, \
    copy_current_request_context
from flask_socketio import SocketIO, emit, join_room, leave_room, \
    close_room, rooms, disconnect
import socket
import time 
import os
from datetime import datetime
import ZoomLib as ZoomLib
import WifiLib as WifiLib
import subprocess 
import json
import jinja2
from flask import send_file
import shutil
import ResolutionLib as ResolutionLib
DEBUG=False
UNMOUNTED_FAR=1
MOUNTED_NEAR=2
MOUNTED_FAR=4
MOUNTED_DEADZONE=8
STEP_TYPE = "full"
STEP_COUNTER = 7
# Set this to "library" or "binary" to use a Python C wrapped .so  or a binary file (.bin)
if not os.path.exists('config.py'):
    shutil.copy('config_default.py', 'config.py')
app = Flask(__name__)
app.config.from_pyfile('config.py')
MIN_ZOOM = 1
MAX_ZOOM = 31
if app.config['DISABLE_HTML_LOGGING']:
    import logging
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.ERROR)
if app.config['ENABLE_MOTORS']:
    import RPi.GPIO as GPIO
    import RpiMotorLib as RpiMotorLib
    cameraZoom = ZoomLib.ZoomLib("binary")
    try:
        current_zoom = cameraZoom.zoomStop()
    except:
        print("Can't access camera!")
        current_zoom = 1
    if current_zoom > 30:
        current_zoom = 30
    elif current_zoom < 1:
        current_zoom = 1
wifi_lib = WifiLib.WifiLib()
host = socket.gethostname()
port = 8080                   # The same port as used by the server
# Set this variable to "threading", "eventlet" or "gevent" to test the
# different async modes, or leave it set to None for the application to choose
# the best option based on installed packages.
#async_mode = None
async_mode = 'threading'
current_distance = 0
horizontal_direction = 0
no_movement_x = 0
vertical_direction = 0
MAX_DISTANCE = 200
MIN_DISTANCE = 5
MAX_SPEED_VERT = 0.005
MIN_SPEED_VERT = 0.03
MAX_SPEED_HORIZONTAL = 0.002
MIN_SPEED_HORIZONTAL = 0.02
changing_orientation = False

socketio = SocketIO(app, async_mode=async_mode, logger = False)
thread = None
thread_lock = Lock()
import JSONLib as JSONLib
import check_for_update as UpdateChecker
json_obj = JSONLib.JSONLib()
tmpUpdater=UpdateChecker.UpdaterLib()
res_lib = ResolutionLib.ResolutionLib()
print('Started')
if app.config['ENABLE_MOTORS']:
    hMotor = RpiMotorLib.BYJMotor("HorizontalMotor", "28BYJ")
    vMotor = RpiMotorLib.BYJMotor("VerticalMotor", "28BYJ")
    hGpioPins = [29,31,33,35]
    vGpioPins = [8,10,12,16]
    hMotor.set_adjustment_steps(8)
    vMotor.set_adjustment_steps(8)
@app.route('/')
def index():
    if json_obj.get_video_mode()==0:
        return render_template('index.html', async_mode=socketio.async_mode, is_video_h264=1)      
    else:
        return render_template('index.html', async_mode=socketio.async_mode, is_video_h264=0)      
@app.route('/settings')
def settings():
    return render_template('settings.html', async_mode=socketio.async_mode)
#socket.emit('pan_setarea', {box_bounds: MAX_FINGER_AREA });
@socketio.event
def pan_setarea(message):
    global MAX_DISTANCE
    global MIN_DISTANCE
    # Divide whole rect to get distance from origin
    MIN_DISTANCE = message['min_distance']  
    MAX_DISTANCE = message['box_bounds'] / 2 
@socketio.event
def check_for_update():
    print("Checking for update")
    if DEBUG:
        socketio.emit("check_for_update_response",{'data': False})    
    else:
        socketio.emit("check_for_update_response",{'data': tmpUpdater.check_for_update()})
@socketio.event
def update_app():
    print("Updating")
    subprocess.Popen(['rm','/home/pi/magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    subprocess.Popen(['rm','magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # process = subprocess.Popen(['./download_from_github.sh','-v',tmpUpdater.get_latest_tag()],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # process = subprocess.Popen(['wget','https://trysight.com/downloads/magnibot/magnibot.tar.gz','/home/pi/magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    process = subprocess.Popen(['wget', 'https://github.com/trysightdev/magnibot_releases/raw/main/magnibot.tar.gz' ],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    file_stats = os.stat('magnibot.tar.gz')
    if file_stats.st_size==tmpUpdater.get_file_size():
        subprocess.Popen(['mv','magnibot.tar.gz','/home/pi/magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        subprocess.Popen(['touch','/home/pi/FINISHED_DOWNLOADING'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    else:
        socketio.emit('refresh_window')
        print("Updating failed")
@socketio.event
def toggle_h264(message):
    json_obj.set_video_mode(message['format'])
    json_obj.set_video_resolution(message['resolution'])
    video_format=""
    video_resolution=""
    if json_obj.get_video_mode()==0:
        video_format="H264"
    elif json_obj.get_video_mode()==1:
        video_format="MJPEG"
    if json_obj.get_video_resolution()==0:
        video_resolution="1920x1080"
    elif json_obj.get_video_resolution()==1:
        video_resolution="1280x720"
    elif json_obj.get_video_resolution()==2:
        video_resolution="640x480"
    # res_lib.setup_ustreamer(video_format, video_resolution, '30')
    process = subprocess.Popen(['./change_resolution.sh','-m',video_format,'-r',video_resolution, '-f', '30'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    ssid = "";
    if DEBUG:
        subprocess.Popen(['sudo','systemctl','restart','ustreamer.service'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        time.sleep(10)
        socketio.emit('refresh_window')
    else:
        subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE) 
@socketio.event
def pan_event(message):
    global current_zoom
    global horizontal_direction
    global vertical_direction
    global no_movement_x
    rspText = message['data']
    distanceFromOrigin = message['distanceFromOrigin']
    dAngle = message['angle_degrees']
    deltaXY = max(min(abs(distanceFromOrigin) , MAX_DISTANCE), 0)
    session['receive_count'] = session.get('receive_count', 0) + 1
    # Lower everything by a step or increase by a step so that when at the lowest level it will be the minimum speed and max speed.
    pctZoom = current_zoom/MAX_ZOOM
    pctDistanceXY = abs(deltaXY) / MAX_DISTANCE
    SPEED_RANGE = abs(MAX_SPEED_VERT - MIN_SPEED_VERT)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    ZOOM_ADJUSTMENT = pctZoom * 0.05
    speedXY = max( MIN_SPEED_VERT - ( 0.06 * pctDistanceXY ) + ZOOM_ADJUSTMENT, MAX_SPEED_VERT)
    SPEED_RANGE_HORIZONTAL = abs(MAX_SPEED_HORIZONTAL - MIN_SPEED_HORIZONTAL)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    speedXY_horizontal = max( MIN_SPEED_HORIZONTAL - ( 0.06 * pctDistanceXY ) + ZOOM_ADJUSTMENT, MAX_SPEED_HORIZONTAL)
    ANGLE_THRESHOLD = 30
    if rspText == "pan":
        # Only switch directions if there is a change of 10px of distance within the last 100ms
        if abs(deltaXY) > MIN_DISTANCE:
            if current_orientation == MOUNTED_NEAR or current_orientation == MOUNTED_FAR:
                if( dAngle > 90 - ANGLE_THRESHOLD and dAngle < 90 + ANGLE_THRESHOLD ):
                    if horizontal_direction == 0:
                        horizontal_direction = 1
                        hMotor.motor_run(hGpioPins, speedXY_horizontal,False,False,STEP_TYPE, .00)
                    elif horizontal_direction == 2:
                        hMotor.motor_stop()
                        horizontal_direction = 0
                    elif horizontal_direction == 1:
                        hMotor.motor_speed(speedXY_horizontal)
                elif( dAngle > 270 - ANGLE_THRESHOLD and dAngle < 270 + ANGLE_THRESHOLD ):
                    if horizontal_direction == 0:
                        horizontal_direction = 2
                        hMotor.motor_run(hGpioPins, speedXY_horizontal,True,False,STEP_TYPE, .00)
                    elif horizontal_direction == 1:
                        hMotor.motor_stop()
                        horizontal_direction = 0
                    elif horizontal_direction == 2:
                        hMotor.motor_speed(speedXY_horizontal)
                else:
                    hMotor.motor_stop()
                    horizontal_direction = 0
                if( dAngle > 180 - ANGLE_THRESHOLD and dAngle < 180 + ANGLE_THRESHOLD):
                    if vertical_direction == 0:
                        vertical_direction = 1
                        vMotor.motor_run(vGpioPins, speedXY,True,False,STEP_TYPE, .00)
                    elif vertical_direction == 2:
                        vMotor.motor_stop()
                        vertical_direction = 0
                    elif vertical_direction == 1:
                        vMotor.motor_speed(speedXY)
                elif( dAngle > 360 - ANGLE_THRESHOLD or dAngle < 0 + ANGLE_THRESHOLD  ):
                    if vertical_direction == 0:
                        vertical_direction = 2
                        vMotor.motor_run(vGpioPins, speedXY,False,False,STEP_TYPE, .00)
                    elif vertical_direction == 1:
                        vMotor.motor_stop()
                        vertical_direction = 0
                    elif vertical_direction == 2:
                        vMotor.motor_speed(speedXY)
                else:
                    vMotor.motor_stop()
                    vertical_direction = 0
            else:
                if( dAngle > 180 - ANGLE_THRESHOLD and dAngle < 180 + ANGLE_THRESHOLD):
                    if horizontal_direction == 0:
                        horizontal_direction = 1
                        hMotor.motor_run(hGpioPins, speedXY_horizontal,False,False,STEP_TYPE, .00)
                    elif horizontal_direction == 2:
                        hMotor.motor_stop()
                        horizontal_direction = 0
                    elif horizontal_direction == 1:
                        hMotor.motor_speed(speedXY_horizontal)
                elif( dAngle > 360 - ANGLE_THRESHOLD or dAngle < 0 + ANGLE_THRESHOLD ):
                    if horizontal_direction == 0:
                        horizontal_direction = 2
                        hMotor.motor_run(hGpioPins, speedXY_horizontal,True,False,STEP_TYPE, .00)
                    elif horizontal_direction == 1:
                        hMotor.motor_stop()
                        horizontal_direction = 0
                    elif horizontal_direction == 2:
                        hMotor.motor_speed(speedXY_horizontal)
                else:
                    hMotor.motor_stop()
                    horizontal_direction = 0
                if( dAngle > 270 - ANGLE_THRESHOLD and dAngle < 270 + ANGLE_THRESHOLD):
                    if vertical_direction == 0:
                        vertical_direction = 1
                        vMotor.motor_run(vGpioPins, speedXY,True,False,STEP_TYPE, .00)
                    elif vertical_direction == 2:
                        vMotor.motor_stop()
                        vertical_direction = 0
                    elif vertical_direction == 1:
                        vMotor.motor_speed(speedXY)
                elif( dAngle > 90 - ANGLE_THRESHOLD and dAngle < 90 + ANGLE_THRESHOLD ):
                    if vertical_direction == 0:
                        vertical_direction = 2
                        vMotor.motor_run(vGpioPins, speedXY,False,False,STEP_TYPE, .00)
                    elif vertical_direction == 1:
                        vMotor.motor_stop()
                        vertical_direction = 0
                    elif vertical_direction == 2:
                        vMotor.motor_speed(speedXY)
                else:
                    vMotor.motor_stop()
                    vertical_direction = 0
        else:
            if vertical_direction != 0:
                no_movement_x+=1
                if no_movement_x > 2:
                    vMotor.motor_stop()
                    vertical_direction = 0
            if horizontal_direction != 0:
                no_movement_x+=1
                if no_movement_x > 2:
                    hMotor.motor_stop()
                    horizontal_direction = 0
    elif rspText == "panend":
        stop_motors()
def toggle_camera():
    global changing_orientation
    if changing_orientation:
        return
    global mounted_orientation
    MAX_STEPS=1000
    stop_motors()
    if mounted_orientation == MOUNTED_NEAR:
        start_orientation_change(MOUNTED_FAR)
        tmpX = hMotor.get_steps()
        tmpY = vMotor.get_steps()
        minX,maxX = hMotor.get_steps_range()
        minY,maxY = vMotor.get_steps_range()
        json_obj.set_motor_location_near([tmpX,tmpY])
        x, y = json_obj.get_motor_location_far()
        stepsX = 620
        
        deltaX = (tmpX + minX) - (x + minX)
        if deltaX < 0:
            stepsX  = stepsX - abs(deltaX)
        elif deltaX > 0:
            stepsX  = stepsX + abs(deltaX)
        # hMotor.motor_test(hGpioPins, 0.002,True,False,"full", .00,stepsX)
        socketio.start_background_task(motor_x,True, stepsX)

        deltaY = abs(tmpY + minY) - abs(y + minY)
        if deltaY > 0:
            # vMotor.motor_test(vGpioPins,auto_home_speed_v,False,False,STEP_TYPE, .00, abs(deltaY))
            socketio.start_background_task(motor_y,False, abs(deltaY))
        elif deltaY < 0:
            # vMotor.motor_test(vGpioPins,auto_home_speed_v,True,False,STEP_TYPE, .00, abs(deltaY))
            socketio.start_background_task(motor_y,True, abs(deltaY))
        else:
            vert_complete.set()
            
        horiz_complete.wait()
        vert_complete.wait()
        vert_complete.clear()
        horiz_complete.clear()
        
        hMotor.reset_steps()
        vMotor.reset_steps()
        
        hMotor.set_steps(x)
        vMotor.set_steps(y)
        
        set_focus_mode(MOUNTED_FAR)
        set_rotation_zoom(MOUNTED_FAR)
        end_orientation_change()
        
        mounted_orientation = MOUNTED_FAR
        
    elif mounted_orientation == MOUNTED_FAR:
        start_orientation_change(MOUNTED_NEAR)
        tmpX = hMotor.get_steps()
        tmpY = vMotor.get_steps()
        minX,maxX = hMotor.get_steps_range()
        minY,maxY = vMotor.get_steps_range()
        json_obj.set_motor_location_far([tmpX,tmpY])
        x, y = json_obj.get_motor_location_near()
        stepsX = 620
        
        deltaX = (tmpX + minX) - (x + minX)
        if deltaX < 0:
            stepsX  = stepsX + abs(deltaX)
        elif deltaX > 0:
            stepsX  = stepsX - abs(deltaX)
            
        socketio.start_background_task(motor_x,False, stepsX)
        
        deltaY = (tmpY + minY) - (y + minY)
        
        if deltaY < 0:
            socketio.start_background_task(motor_y,False, abs(deltaY))
        elif deltaY > 0:
            socketio.start_background_task(motor_y,True, abs(deltaY))
        else:
            vert_complete.set()
            
        horiz_complete.wait()
        vert_complete.wait()

        vert_complete.clear()
        horiz_complete.clear()
        
        hMotor.reset_steps()
        vMotor.reset_steps()
        
        hMotor.set_steps(x)
        vMotor.set_steps(y)
        set_focus_mode(MOUNTED_NEAR)
        set_rotation_zoom(MOUNTED_NEAR)
        end_orientation_change()
        mounted_orientation = MOUNTED_NEAR


auto_home_speed_h = 0.002
auto_home_speed_v = 0.003

import threading

horiz_complete = threading.Event()
vert_complete = threading.Event()
def auto_home_horiz(h_offset):
    
    global horizontal_direction
    global arduino_thread
    
    hMotor.motor_stop()
    horizontal_direction = 0
    # vstopper_to_bstopper_steps = 420
    accelVals = arduino_thread.get_value()
    # accel_y = 1.0 - Up, accel_y = -1.0 down
    # accel_z = -1.0 - Fwd, accel_z = 1.0 back
    
    vstopper_to_bstopper_steps = 1024
    y = accelVals['y']
    z = accelVals['z']
    right = z > 0
    down = y < 0
    print(f"{down} {right}")
    quarter_circle = 550
    
    
    if down and right:
        # print("Direction: down right")
        vstopper_to_bstopper_steps = quarter_circle
    elif down and not right:
        # print("Direction: down left")
        vstopper_to_bstopper_steps = (quarter_circle * 1) + ( abs(z) / 1.0 * quarter_circle )
    elif not down and right:
        # print("Direction: up right")
        vstopper_to_bstopper_steps = (quarter_circle * 2) + ( abs(z) / 1.0 * quarter_circle )
    elif not down and not right:
        # print("Direction: up left")
        vstopper_to_bstopper_steps = (quarter_circle * 3) + ( abs(y) / 1.0 * quarter_circle )
    else:
        print("Unknown direction")

    
        
    # print(f"vstopper_to_bstopper_steps {vstopper_to_bstopper_steps}")
    
    
    from_bstopper_to_center = 350
    # speed = 0.005
    
    hMotor.motor_test(hGpioPins,auto_home_speed_h,False,False,STEP_TYPE, .00, vstopper_to_bstopper_steps)
    hMotor.motor_test(hGpioPins,auto_home_speed_h,True,False,STEP_TYPE, .00, from_bstopper_to_center)
    
    horiz_complete.set()

def auto_home_vert(v_offset):
    global accel
    global vertical_direction
    vMotor.motor_stop()
    vertical_direction = 0
    vstopper_to_bstopper_steps = 250 
    
    from_bstopper_to_center = 125
    vMotor.motor_test(vGpioPins,auto_home_speed_v,False,False,STEP_TYPE, .00, vstopper_to_bstopper_steps)
    vMotor.motor_test(vGpioPins,auto_home_speed_v,True,False,STEP_TYPE, .00, from_bstopper_to_center)
    
    vert_complete.set()

auto_home_speed_h = 0.002
auto_home_speed_v = 0.003

import threading

horiz_complete = threading.Event()
vert_complete = threading.Event()
def motor_x(ccwise, steps):
    
    global horizontal_direction
    global arduino_thread
    
    hMotor.motor_stop()
    horizontal_direction = 0
    
    if( ccwise ):
        hMotor.motor_test(hGpioPins,auto_home_speed_h,True,False,STEP_TYPE, .00, steps)
    else:
        hMotor.motor_test(hGpioPins,auto_home_speed_h,False,False,STEP_TYPE, .00, steps)
    
    horiz_complete.set()

def motor_y(ccwise, steps):
    global accel
    global vertical_direction
    vMotor.motor_stop()
    vertical_direction = 0
       
    if( ccwise ):
        vMotor.motor_test(vGpioPins,auto_home_speed_v,True,False,STEP_TYPE, .00, steps)
    else:
        vMotor.motor_test(vGpioPins,auto_home_speed_v,False,False,STEP_TYPE, .00, steps)
    
    vert_complete.set()
    
def auto_home():
    global auto_home_running
    global horizontal_direction
    global mounted_orientation
    # auto_home_running = True 
    x = 0
    y = 0
    json_obj.set_motor_location_near([x,y])
    json_obj.set_motor_location_far([x,y])
    x,y =json_obj.get_motor_location_near()
    
    socketio.start_background_task(auto_home_vert,y)
    socketio.start_background_task(auto_home_horiz,x)
    
    vert_complete.wait()
    horiz_complete.wait()

    vert_complete.clear()
    horiz_complete.clear()
    
    hMotor.reset_steps()
    vMotor.reset_steps()
    
    vMotor.set_steps(y)
    hMotor.set_steps(x)
    
    vMotor.set_steps_range(-50,50)
    hMotor.set_steps_range(-250,250)
    mounted_orientation = MOUNTED_NEAR

@socketio.event
def my_event(message):
    global current_zoom
    rspText = message['data']
    session['receive_count'] = session.get('receive_count', 0) + 1
    # Lower everything by a step or increase by a step so that when at the lowest level it will be the minimum speed and max speed.
    pctZoom = current_zoom/MAX_ZOOM
    SPEED_RANGE = abs(MAX_SPEED_VERT - MIN_SPEED_VERT)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    speed_vert = MAX_SPEED_VERT + ( SPEED_RANGE * pctZoom )
    SPEED_RANGE_HORIZONTAL = abs(MAX_SPEED_HORIZONTAL - 0.01)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    speed_horizontal = MAX_SPEED_HORIZONTAL + ( SPEED_RANGE_HORIZONTAL * pctZoom )
    speed_horizontal = max(auto_home_speed_h,speed_horizontal)
    speed_vert = max(auto_home_speed_v,speed_vert)
    if app.config['ENABLE_MOTORS']:
        # If mounted switch direction of motors buttons
        if current_orientation == MOUNTED_NEAR or current_orientation == MOUNTED_FAR:
            if rspText == "down":
                hMotor.motor_run(hGpioPins, speed_horizontal,False,False,STEP_TYPE, .00)
            elif rspText=="up":
                hMotor.motor_run(hGpioPins, speed_horizontal,True,False,STEP_TYPE, .00)
            elif rspText=="right":
                vMotor.motor_run(vGpioPins,speed_vert,True,False,STEP_TYPE, .00)
            elif rspText=="left":
                vMotor.motor_run(vGpioPins,speed_vert,False,False,STEP_TYPE, .00)
            elif rspText=="toggle_camera":
                toggle_camera()
            elif rspText=="stopVertical":
                hMotor.motor_stop()
            elif rspText=="stopHorizontal":
                vMotor.motor_stop()
        else:
            if rspText=="right":
                hMotor.motor_run(hGpioPins, speed_horizontal,False,False,STEP_TYPE, .00)
            elif rspText=="left":
                hMotor.motor_run(hGpioPins, speed_horizontal,True,False,STEP_TYPE, .00)
            elif rspText=="up":
                vMotor.motor_run(vGpioPins,speed_vert,True,False,STEP_TYPE, .00)
            elif rspText == "down":
                vMotor.motor_run(vGpioPins,speed_vert,False,False,STEP_TYPE, .00)
            elif rspText=="stopHorizontal":
                hMotor.motor_stop()
            elif rspText=="stopVertical":
                vMotor.motor_stop()

    if rspText.find("zoomin") != -1:
        cameraZoom.zoomIn()
    elif rspText.find("zoomout") != -1:
        cameraZoom.zoomOut()
    elif rspText.find("zoomstop") != -1:
        current_zoom = cameraZoom.zoomStop()
        if current_orientation == UNMOUNTED_FAR:
            json_obj.set_zoomIndex(current_zoom,int(current_orientation))
        elif current_orientation == MOUNTED_NEAR:
            json_obj.set_zoomIndex(current_zoom,int(mounted_orientation))
            
        print("current_zoom: ", current_zoom)
    elif rspText.find("fiftyHz") != -1:
        cameraZoom.setRefreshRate(1)
    elif rspText.find("sixtyHz") != -1:
        cameraZoom.setRefreshRate(0)
def getBatteryLevel():
#    battery_level =  core.get_battery_percent()
#    process = subprocess.Popen(['./pisugar-poweroff'],cwd = './lib', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p1 = subprocess.Popen(["echo","get battery"], stdout=subprocess.PIPE)
    p2 = subprocess.Popen(["nc","-q","0","127.0.0.1","8423"], stdin=p1.stdout, stdout=subprocess.PIPE)
    out_level, err = p2.communicate()
    p3 = subprocess.Popen(["echo","get battery_power_plugged"], stdout=subprocess.PIPE)    
    p4 = subprocess.Popen(["nc","-q","0","127.0.0.1","8423"], stdin=p3.stdout, stdout=subprocess.PIPE)
    out_plugged, err = p4.communicate()
    if out_level.decode("utf-8") == '':
        socketio.emit('update_batterylevel', {'data':  0 , "is_plugged": 0 })
    else: 
        results = out_level.decode("utf-8").replace('\n','').replace('single','').split(' ')
        battery_level = int(results[1].split('.')[0])
        results = out_plugged.decode("utf-8").replace('\n','').split(' ')
        is_plugged = results[1]
        if is_plugged.find("true")!=-1:
            plugged = 1
        else:
            plugged = 0
        socketio.emit('update_batterylevel',
            {'data':  battery_level , "is_plugged": plugged })
def check_network_connection():
    process = subprocess.Popen(['iw','dev'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    ssid = ""
    ip_address = ""
    if err == '':
        try:
            results = out.split("Interface")[1].split('\n')
        except:
            print("USB Wifi is not connected!")
            return
        for x in results:
            if x.find("ssid") != -1:
                s_pos = x.find(" ") + 1
                ssid = x[s_pos:].replace('"','')
                print("SSID: ", ssid)
    if not ssid == "":
        process = subprocess.Popen(['hostname','-I'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = process.communicate()
        out = out.decode("utf-8")
        err = err.decode("utf-8")
        ip_address = out
        print("ip_address: ", ssid)
    socketio.emit('network_connected_to', {'ssid': ssid, 'ip_address': ip_address})
    return ssid
def update_wifi():
    check_network_connection()
    process = subprocess.Popen(['sudo','iwlist','wlan1','scan'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    if out.decode("utf-8") == '':
        socketio.emit('update_wifi', { 'data': ''})
    else: 
        results = out.decode("utf-8").replace('\\','').split('Cell')
        wifi_list = []
        wifi_array = []
        for x in results:
            SSID = ""
            Encryption = 0
            Quality = 0
            skip = False
            for y in x.split('\n'):
                if y.find("Quality") != -1:
                    try:
                        tmp = y.split('Quality=')
                        tmp = tmp[1].split('S')
                        tmp = tmp[0].split('/')
                        Quality = int(float(tmp[0]) / float(tmp[1]) * 100.0)
                    except:
                        print("Skipped quality")
                        Quality = 1
                if y.find("Encryption") != -1:
                    if y.split(':')[1].find("on") != -1:
                        Encryption = 0
                    else:
                        Encryption = 1
                if y.find("SSID") != -1:
                    SSID += y.split('ESSID:')[1] 
                    if SSID.find("magnibot") != -1:
                        skip = True
                        break
                    if len(SSID) == 2:
                        skip = True
                        print("",len(SSID))
                        break
            if not skip and len(SSID) > 2:
                wifi_array.append([SSID, Quality, Encryption]) 
        wifi_array.sort(key=lambda tup: tup[1],reverse=True)
        for w in wifi_array:
            wifi_string = "{\"SSID\": " + w[0] + ", " + "\"Quality\": \"" + str(w[1]) + "\", " + "\"Encryption\": \"" + str(w[2]) + "\"}"
            wifi_list.append(wifi_string)
        socketio.emit('update_wifi', { 'data': wifi_list})
def change_ssid():
    process = subprocess.Popen(['bash','-c','./change_ssid.sh'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    ssid = ""
    print("", out, err)
@socketio.event
def connect_wifi(message):
    wifi_lib.connect( message['SSID'], message['NO_PWD'], message['PWD'] )
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
@socketio.event
def advanced_connect_wifi(message):
    wifi_lib.advanced_connect( message['SSID'], message['USERNAME'], message['PWD'] )
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
@socketio.event
def my_ping():
    emit('my_pong')
@socketio.event
def disconnect_wifi():
    wifi_lib.disconnect()
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
@socketio.event
def set_rotation(message):
    global json_obj
    json_obj.set_rotation(message['rotation_value'])
@socketio.event
def set_brightness(message):
    global json_obj
    json_obj.set_brightness(message['brightness_value'])
@socketio.event
def set_brightnessC(message):
    global json_obj
    json_obj.set_brightnessC(message['brightness_value'])
@socketio.event
def set_contrast(message):
    global json_obj
    json_obj.set_contrast(message['contrast_value'])
@socketio.event
def set_shaderIndex(message):
    global json_obj
    if current_orientation==UNMOUNTED_FAR:
        json_obj.set_shaderIndex(message['shaderIndex'], current_orientation)
    else:
        json_obj.set_shaderIndex(message['shaderIndex'], mounted_orientation)
        
@socketio.event
def restart():
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
@socketio.event
def take_snapshot():
    timestr = '/images/img_' + time.strftime("%Y%m%d%H%M%S") + '.jpg'
    os.system('rm static/images/img_*.jpg' )
    os.system('curl http://localhost/snapshot > static' + timestr )
    socketio.emit('finished_take_snapshot', { 'data' : timestr})
@socketio.event
def get_settings():
    socketio.emit('get_settings_response', json_obj.data)
@socketio.event
def set_settings(msg):
    json_obj.set_fragment_shaders( msg['fragmentShaders'] )
    json_obj.set_refresh_rate( msg['refreshRate'])
    
    if msg['motorSpeed'] != json_obj.get_motor_speed():
        set_motor_speed(msg['motorSpeed'])
    
    json_obj.set_motor_speed( msg['motorSpeed'])
    
    

@socketio.event
def get_networks():
    ssid = check_network_connection()
    process = subprocess.Popen(['sudo','iwlist','wlan1','scan'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    if out.decode("utf-8") == '':
        socketio.emit('get_networks_response', { 'data': ''})
    else: 
        results = out.decode("utf-8").replace('\\','').split('Cell')
        wifi_list = []
        wifi_array = []
        for x in results:
            SSID = ""
            Encryption = 0
            Quality = 0
            skip = False
            for y in x.split('\n'):
                if y.find("Quality") != -1:
                    try:
                        tmp = y.split('Quality=')
                        tmp = tmp[1].split('S')
                        tmp = tmp[0].split('/')
                        Quality = int(float(tmp[0]) / float(tmp[1]) * 100.0)
                    except:
                        print("Skipped quality")
                        Quality = 1
                if y.find("Encryption") != -1:
                    if y.split(':')[1].find("on") != -1:
                        Encryption = 0
                    else:
                        Encryption = 1
                if y.find("SSID") != -1:
                    SSID += y.split('ESSID:')[1] 
                    if SSID.find("magnibot") != -1:
                        skip = True
                        break
                    if len(SSID) == 2:
                        skip = True
                        print("",len(SSID))
                        break
            if not skip and len(SSID) > 2:
                wifi_array.append([SSID, Quality, Encryption]) 
        wifi_array.sort(key=lambda tup: tup[1],reverse=True)
        for w in wifi_array:
            if ssid in w[0]:
                print("Connected: ", ssid)
                connected = "1"
            else:
                connected = "0"
            wifi_string = "{\"SSID\": " + w[0] + ", " + "\"Quality\": \"" + str(w[1]) + "\", " + "\"Encryption\": \"" + str(w[2]) + "\", " + "\"Connected\": \"" + connected + "\"}"
            wifi_list.append(wifi_string)
        socketio.emit('get_networks_response', { 'data': wifi_list})
thread = None
thread_lock = Lock()
def background_thread():
    """Example of how to send server generated events to clients."""
    while True:
        socketio.sleep(5)
        getBatteryLevel()
thread2 = None
thread_lock2 = Lock()
current_orientation = 0
mounted_orientation = MOUNTED_NEAR
orientation_changed = False
orientation_stabilized_counter = 0
first_run = True
old_orientation = current_orientation
auto_home_running = False
accel = None

import ArduinoReader as ArduinoReader
arduino_thread = None
def background_thread2():
    """Example of how to send server generated events to clients."""
    global current_orientation
    # rotationLib = InputBridgeLib.InputBridgeLib()
    global arduino_thread
    global current_zoom
    global thread2
    global orientation_stabilized_counter
    global orientation_changed
    global first_run
    global old_orientation
    global auto_home_running
    global accel
    global horizontal_direction
    global vMotor
    global changing_orientation
    while True:
        socketio.sleep(0.05)
        if arduino_thread==None:
            continue
        accel = arduino_thread.get_value()
        if accel==None or accel['result'] == 0:
            continue
        
        if changing_orientation:
            continue
       
        if accel['x'] <= 0.85:
            new_orientation = MOUNTED_NEAR
        else:
            new_orientation = UNMOUNTED_FAR
            
        
        if new_orientation==8: # Skip dead zone
            new_orientation=None
            with thread_lock2:
                arduino_thread = None
                thread2 = None
                print("Arduino disconnected, refreshing window")
                socketio.emit('refresh_window')
                break
            
        if new_orientation!=None:
            if new_orientation!=current_orientation:
                if orientation_changed==False:
                    old_orientation = current_orientation
                    orientation_changed = True
                orientation_stabilized_counter = 0
            else:
                if orientation_changed:
                    orientation_stabilized_counter = orientation_stabilized_counter + 1
                    if orientation_stabilized_counter > STEP_COUNTER:
                        if new_orientation!=old_orientation or first_run:
                            start_orientation_change(new_orientation)
                            set_focus_mode(new_orientation)
                            set_rotation_zoom(new_orientation)
                            if new_orientation==UNMOUNTED_FAR:
                                vMotor.set_steps_range(0,0)
                                hMotor.set_steps_range(0,0)
                            elif new_orientation==MOUNTED_NEAR:
                                auto_home()
                            elif new_orientation==MOUNTED_FAR:
                                print("MOUNTED_FAR")
                            end_orientation_change()
                        else:
                            print("Same orientation as starting...skip")
                        first_run = False          
                        orientation_changed = False
                    # else:
            current_orientation = new_orientation
def start_arduino_thread():
    global thread2
    global arduino_thread
    with thread_lock2:
        if thread2==None:
            arduino_thread = ArduinoReader.ArduinoReader() # replace '/dev/ttyACM0' with your port and 9600 with your baud rate
            arduino_thread.startService()
            thread2 = socketio.start_background_task(background_thread2)
def clean_logs():
    process = subprocess.Popen(['bash','-c','./clean_space.sh'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    print("", out, err)
def set_motor_speed(pSpeed = 0):
    global STEP_TYPE
    global STEP_COUNTER
    if pSpeed==0:
        STEP_TYPE = "half"
        # STEP_COUNTER = 14
        STEP_COUNTER = 7
    else:
        STEP_TYPE = "full"
        STEP_COUNTER = 7
        
@socketio.event
def test_connect():
    print("No internet")
    stop_motors()
    set_motor_speed(json_obj.get_motor_speed())
    socketio.emit(
            'first_connect',
            {
                'current_orientation' : current_orientation,
                'magnibotSettings' : json_obj.data,
                }) 
    global thread
    getBatteryLevel()
    with thread_lock:
        if thread is None:
            thread = socketio.start_background_task(background_thread)
    update_wifi()
    start_arduino_thread()
    end_orientation_change()
def set_rotation_zoom(p_new_orientation):
    global current_orientation
    global current_zoom
    start_time = time.time()
    current_zoom = cameraZoom.zoomGet()
    if current_zoom > 30:
        current_zoom = 30
    elif current_zoom < 1:
        current_zoom = 1
    tmp_zoom = json_obj.get_zoomIndex(int(p_new_orientation))
    print("current_zoom: ",current_zoom,", new_zoom: ",tmp_zoom)
    if current_zoom < tmp_zoom:
        cameraZoom.zoomIn()
        while True:
            time.sleep(0.1)
            c_zoom = cameraZoom.zoomGet()
            if c_zoom >= tmp_zoom :
                tmp_zoom = cameraZoom.zoomStop()
                break
            else:
                current_time = time.time()
                elapsed_time = current_time - start_time
                if elapsed_time >= 15:
                    start_time = time.time()
                    break
    elif current_zoom > tmp_zoom:
        cameraZoom.zoomOut()
        while True:
            time.sleep(0.1)
            c_zoom = cameraZoom.zoomGet()
            if c_zoom <= tmp_zoom :
                tmp_zoom = cameraZoom.zoomStop()
                break
            else:
                current_time = time.time()
                elapsed_time = current_time - start_time
                if elapsed_time >= 15:
                    start_time = time.time()
                    break
    current_zoom = tmp_zoom
def set_focus_mode(p_new_orientation):
    global cameraZoom
    if p_new_orientation == UNMOUNTED_FAR or p_new_orientation == MOUNTED_FAR:
        cameraZoom.zoomFocusInfinity()
    elif p_new_orientation==2:
        cameraZoom.zoomFocusThirty()
def stop_motors():
    global  horizontal_direction
    global vertical_direction
    hMotor.motor_stop()
    vMotor.motor_stop()
    horizontal_direction = 0
    vertical_direction = 0
def start_orientation_change(p_new_orientation):
    global changing_orientation
    changing_orientation = True
    stop_motors()
    socketio.emit(
        'update_orientation', 
        { 
         'orientation' : p_new_orientation, 
         'color' : json_obj.get_shaderIndex(int(p_new_orientation)),
         'rotation' : json_obj.get_rotation()
         })
def end_orientation_change():
    socketio.emit('finished_orientation')
    global changing_orientation
    changing_orientation = False
if __name__ == '__main__':
    clean_logs()
    change_ssid()
    socketio.run(app, host='127.0.0.1', port=5000, debug=True)
