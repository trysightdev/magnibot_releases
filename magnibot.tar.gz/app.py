from threading import Lock
from flask import Flask, Response, render_template, session, request, \
    copy_current_request_context
from flask_socketio import SocketIO, emit, join_room, leave_room, \
    close_room, rooms, disconnect
import socket
import time 
import os
from datetime import datetime
import ZoomLib as ZoomLib
import WifiLib as WifiLib
import subprocess 
import json
import jinja2
from flask import send_file
import shutil

DEBUG=False
UNMOUNTED_FAR=1
MOUNTED_NEAR=2
MOUNTED_FAR=4
MOUNTED_DEADZONE=8

# Set this to "library" or "binary" to use a Python C wrapped .so  or a binary file (.bin)
if not os.path.exists('config.py'):
    shutil.copy('config_default.py', 'config.py')



app = Flask(__name__)
app.config.from_pyfile('config.py')

MIN_ZOOM = 1
MAX_ZOOM = 31

if app.config['DISABLE_HTML_LOGGING']:
    import logging
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.ERROR)
if app.config['ENABLE_MOTORS']:
    import RPi.GPIO as GPIO
    import RpiMotorLib as RpiMotorLib
    cameraZoom = ZoomLib.ZoomLib("binary")
    try:
        current_zoom = cameraZoom.zoomStop()
    except:
        print("Can't access camera!")
        current_zoom = 1
    
    if current_zoom > 30:
        current_zoom = 30
    elif current_zoom < 1:
        current_zoom = 1

    print( type(cameraZoom) )

wifi_lib = WifiLib.WifiLib()



host = socket.gethostname()
port = 8080                   # The same port as used by the server

# Set this variable to "threading", "eventlet" or "gevent" to test the
# different async modes, or leave it set to None for the application to choose
# the best option based on installed packages.
#async_mode = None
async_mode = 'threading'


current_distance = 0
horizontal_direction = 0
no_movement_x = 0
vertical_direction = 0
MAX_DISTANCE = 200
MIN_DISTANCE = 5
MAX_SPEED = 0.005
MIN_SPEED = 0.03
MAX_SPEED_HORIZONTAL = 0.002
MIN_SPEED_HORIZONTAL = 0.02

socketio = SocketIO(app, async_mode=async_mode, logger = False)
thread = None
thread_lock = Lock()

import JSONLib as JSONLib
import check_for_update as UpdateChecker

json_obj = JSONLib.JSONLib()
tmpUpdater=UpdateChecker.UpdaterLib()




print('Started')

if app.config['ENABLE_MOTORS']:
    hMotor = RpiMotorLib.BYJMotor("HorizontalMotor", "28BYJ")
    vMotor = RpiMotorLib.BYJMotor("VerticalMotor", "28BYJ")
    hGpioPins = [29,31,33,35]
    vGpioPins = [8,10,12,16]

@app.route('/')
def index():
    if json_obj.get_video_mode()==0:
        return render_template('index.html', async_mode=socketio.async_mode, is_video_h264=1)      
    else:
        return render_template('index.html', async_mode=socketio.async_mode, is_video_h264=0)      


#socket.emit('pan_setarea', {box_bounds: MAX_FINGER_AREA });
@socketio.event
def pan_setarea(message):
    global MAX_DISTANCE
    global MIN_DISTANCE
    # Divide whole rect to get distance from origin
    MIN_DISTANCE = message['min_distance']  
    MAX_DISTANCE = message['box_bounds'] / 2 

@socketio.event
def check_for_update():
    print("Checking for update")
    if DEBUG:
        socketio.emit("check_for_update_response",{'data': False})    
    else:
        socketio.emit("check_for_update_response",{'data': tmpUpdater.check_for_update()})

    
@socketio.event
def update_app():
    print("Updating")
    subprocess.Popen(['rm','/home/pi/magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    subprocess.Popen(['rm','magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # process = subprocess.Popen(['./download_from_github.sh','-v',tmpUpdater.get_latest_tag()],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # process = subprocess.Popen(['wget','https://trysight.com/downloads/magnibot/magnibot.tar.gz','/home/pi/magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    process = subprocess.Popen(['wget', 'https://github.com/trysightdev/magnibot_releases/raw/main/magnibot.tar.gz' ],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    file_stats = os.stat('magnibot.tar.gz')
    if file_stats.st_size==tmpUpdater.get_file_size():
        print("Filesize: " , file_stats.st_size, " ", tmpUpdater.get_file_size())
        subprocess.Popen(['mv','magnibot.tar.gz','/home/pi/magnibot.tar.gz'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        subprocess.Popen(['touch','/home/pi/FINISHED_DOWNLOADING'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    else:
        socketio.emit('refresh_window')
        print("Updating failed")

@socketio.event
def toggle_h264(message):
    json_obj.set_video_mode(message['format'])
    json_obj.set_video_resolution(message['resolution'])
    video_format=""
    video_resolution=""
    if json_obj.get_video_mode()==0:
        video_format="H264"
    elif json_obj.get_video_mode()==1:
        video_format="MJPEG"

    if json_obj.get_video_resolution()==0:
        video_resolution="1920x1080"
    elif json_obj.get_video_resolution()==1:
        video_resolution="1280x720"
    elif json_obj.get_video_resolution()==2:
        video_resolution="640x480"

    process = subprocess.Popen(['./change_resolution.sh','-m',video_format,'-r',video_resolution, '-f', '30'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    ssid = "";
    print("", out, err)
    if DEBUG:
        subprocess.Popen(['sudo','systemctl','restart','ustreamer.service'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        time.sleep(10)
        socketio.emit('refresh_window')
    else:
        subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE) 
    


@socketio.event
def pan_event(message):
    global current_zoom
    global horizontal_direction
    global vertical_direction
    global no_movement_x
    rspText = message['data']
    distanceFromOrigin = message['distanceFromOrigin']
    dAngle = message['angle_degrees']
    deltaXY = max(min(abs(distanceFromOrigin) , MAX_DISTANCE), 0)
    session['receive_count'] = session.get('receive_count', 0) + 1
    # Lower everything by a step or increase by a step so that when at the lowest level it will be the minimum speed and max speed.
    pctZoom = current_zoom/MAX_ZOOM
    pctDistanceXY = abs(deltaXY) / MAX_DISTANCE
    SPEED_RANGE = abs(MAX_SPEED - MIN_SPEED)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    ZOOM_ADJUSTMENT = pctZoom * 0.05
    speedXY = max( MIN_SPEED - ( 0.06 * pctDistanceXY ) + ZOOM_ADJUSTMENT, MAX_SPEED)
    SPEED_RANGE_HORIZONTAL = abs(MAX_SPEED_HORIZONTAL - MIN_SPEED_HORIZONTAL)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    speedXY_horizontal = max( MIN_SPEED_HORIZONTAL - ( 0.06 * pctDistanceXY ) + ZOOM_ADJUSTMENT, MAX_SPEED_HORIZONTAL)
    ANGLE_THRESHOLD = 30
    if rspText == "pan":
        # Only switch directions if there is a change of 10px of distance within the last 100ms
        if abs(deltaXY) > MIN_DISTANCE:
            if current_orientation == MOUNTED_NEAR or current_orientation == MOUNTED_FAR:
                if( dAngle > 90 - ANGLE_THRESHOLD and dAngle < 90 + ANGLE_THRESHOLD ):
                    if horizontal_direction == 0:
                        horizontal_direction = 1
                        hMotor.motor_run(hGpioPins, speedXY_horizontal,False,False,"half", .00)
                    elif horizontal_direction == 2:
                        hMotor.motor_stop()
                        horizontal_direction = 0
                    elif horizontal_direction == 1:
                        hMotor.motor_speed(speedXY_horizontal)
                elif( dAngle > 270 - ANGLE_THRESHOLD and dAngle < 270 + ANGLE_THRESHOLD ):
                    if horizontal_direction == 0:
                        horizontal_direction = 2
                        hMotor.motor_run(hGpioPins, speedXY_horizontal,True,False,"half", .00)
                    elif horizontal_direction == 1:
                        hMotor.motor_stop()
                        horizontal_direction = 0
                    elif horizontal_direction == 2:
                        hMotor.motor_speed(speedXY_horizontal)
                else:
                    hMotor.motor_stop()
                    horizontal_direction = 0

                if( dAngle > 180 - ANGLE_THRESHOLD and dAngle < 180 + ANGLE_THRESHOLD):
                    if vertical_direction == 0:
                        vertical_direction = 1
                        vMotor.motor_run(vGpioPins, speedXY,True,False,"half", .00)
                    elif vertical_direction == 2:
                        vMotor.motor_stop()
                        vertical_direction = 0
                    elif vertical_direction == 1:
                        vMotor.motor_speed(speedXY)
                elif( dAngle > 360 - ANGLE_THRESHOLD or dAngle < 0 + ANGLE_THRESHOLD  ):
                    if vertical_direction == 0:
                        vertical_direction = 2
                        vMotor.motor_run(vGpioPins, speedXY,False,False,"half", .00)
                    elif vertical_direction == 1:
                        vMotor.motor_stop()
                        vertical_direction = 0
                    elif vertical_direction == 2:
                        vMotor.motor_speed(speedXY)
                else:
                    vMotor.motor_stop()
                    vertical_direction = 0
            else:
                if( dAngle > 180 - ANGLE_THRESHOLD and dAngle < 180 + ANGLE_THRESHOLD):
                    if horizontal_direction == 0:
                        horizontal_direction = 1
                        hMotor.motor_run(hGpioPins, speedXY_horizontal,False,False,"half", .00)
                    elif horizontal_direction == 2:
                        hMotor.motor_stop()
                        horizontal_direction = 0
                    elif horizontal_direction == 1:
                        hMotor.motor_speed(speedXY_horizontal)
                elif( dAngle > 360 - ANGLE_THRESHOLD or dAngle < 0 + ANGLE_THRESHOLD ):
                    if horizontal_direction == 0:
                        horizontal_direction = 2
                        hMotor.motor_run(hGpioPins, speedXY_horizontal,True,False,"half", .00)
                    elif horizontal_direction == 1:
                        hMotor.motor_stop()
                        horizontal_direction = 0
                    elif horizontal_direction == 2:
                        hMotor.motor_speed(speedXY_horizontal)
                else:
                    hMotor.motor_stop()
                    horizontal_direction = 0

                if( dAngle > 270 - ANGLE_THRESHOLD and dAngle < 270 + ANGLE_THRESHOLD):
                    if vertical_direction == 0:
                        vertical_direction = 1
                        vMotor.motor_run(vGpioPins, speedXY,True,False,"half", .00)
                    elif vertical_direction == 2:
                        vMotor.motor_stop()
                        vertical_direction = 0
                    elif vertical_direction == 1:
                        vMotor.motor_speed(speedXY)
                elif( dAngle > 90 - ANGLE_THRESHOLD and dAngle < 90 + ANGLE_THRESHOLD ):
                    if vertical_direction == 0:
                        vertical_direction = 2
                        vMotor.motor_run(vGpioPins, speedXY,False,False,"half", .00)
                    elif vertical_direction == 1:
                        vMotor.motor_stop()
                        vertical_direction = 0
                    elif vertical_direction == 2:
                        vMotor.motor_speed(speedXY)
                else:
                    vMotor.motor_stop()
                    vertical_direction = 0

        else:
            if vertical_direction != 0:
                no_movement_x+=1
                if no_movement_x > 2:
                    vMotor.motor_stop()
                    vertical_direction = 0
            if horizontal_direction != 0:
                no_movement_x+=1
                if no_movement_x > 2:
                    hMotor.motor_stop()
                    horizontal_direction = 0
    elif rspText == "panend":
        stop_motors()


def toggle_camera():
    MAX_STEPS=1000
    
    stop_motors()
    if current_orientation == MOUNTED_FAR:
        hMotor.motor_run(hGpioPins, 0.002,False,False,"half", .00)
    elif current_orientation == MOUNTED_NEAR:
        hMotor.motor_run(hGpioPins, 0.002,True,False,"half", .00)

@socketio.event
def my_event(message):
    global current_zoom
    rspText = message['data']
    session['receive_count'] = session.get('receive_count', 0) + 1
    # Lower everything by a step or increase by a step so that when at the lowest level it will be the minimum speed and max speed.
    pctZoom = current_zoom/MAX_ZOOM
    SPEED_RANGE = abs(MAX_SPEED - MIN_SPEED)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    speed = MAX_SPEED + ( SPEED_RANGE * pctZoom )
    SPEED_RANGE_HORIZONTAL = abs(MAX_SPEED_HORIZONTAL - 0.01)
    # Higher zoom will cause slower motor movement (increases delay between steps)  and low zoom will increase speed (lower delay between steps)
    speed_horizontal = MAX_SPEED_HORIZONTAL + ( SPEED_RANGE_HORIZONTAL * pctZoom )

    if app.config['ENABLE_MOTORS']:
        # If mounted switch direction of motors buttons
        if current_orientation == MOUNTED_NEAR or current_orientation == MOUNTED_FAR:
            if rspText == "down":
                hMotor.motor_run(hGpioPins, speed_horizontal,False,False,"half", .00)
            elif rspText=="up":
                hMotor.motor_run(hGpioPins, speed_horizontal,True,False,"half", .00)
            elif rspText=="right":
                vMotor.motor_run(vGpioPins,speed,True,False,"half", .00)
            elif rspText=="left":
                vMotor.motor_run(vGpioPins,speed,False,False,"half", .00)
            elif rspText=="toggle_camera":
                print("speed_horizontal: ",speed_horizontal)
                toggle_camera()

            elif rspText=="stopVertical":
                hMotor.motor_stop()
            elif rspText=="stopHorizontal":
                vMotor.motor_stop()
        else:
            if rspText=="right":
                hMotor.motor_run(hGpioPins, speed_horizontal,False,False,"half", .00)
                print("speed_horizontal: ",speed_horizontal)
            elif rspText=="left":
                hMotor.motor_run(hGpioPins, speed_horizontal,True,False,"half", .00)
                print("speed_horizontal: ",speed_horizontal)
            elif rspText=="up":
                vMotor.motor_run(vGpioPins,speed,True,False,"half", .00)
            elif rspText == "down":
                vMotor.motor_run(vGpioPins,speed,False,False,"half", .00)
            elif rspText=="stopHorizontal":
                hMotor.motor_stop()
            elif rspText=="stopVertical":
                vMotor.motor_stop()
                
    else:
        print("Motors disabled")
    if rspText.find("zoomin") != -1:
        cameraZoom.zoomIn()
    elif rspText.find("zoomout") != -1:
        cameraZoom.zoomOut()
    elif rspText.find("zoomstop") != -1:
        current_zoom = cameraZoom.zoomStop()
        json_obj.set_zoomIndex(current_zoom,int(current_orientation))
        print("current_zoom: ", current_zoom)
    
def getBatteryLevel():
#    battery_level =  core.get_battery_percent()
#    process = subprocess.Popen(['./pisugar-poweroff'],cwd = './lib', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p1 = subprocess.Popen(["echo","get battery"], stdout=subprocess.PIPE)
    p2 = subprocess.Popen(["nc","-q","0","127.0.0.1","8423"], stdin=p1.stdout, stdout=subprocess.PIPE)
    out_level, err = p2.communicate()
    p3 = subprocess.Popen(["echo","get battery_power_plugged"], stdout=subprocess.PIPE)    
    p4 = subprocess.Popen(["nc","-q","0","127.0.0.1","8423"], stdin=p3.stdout, stdout=subprocess.PIPE)
    out_plugged, err = p4.communicate()
    if out_level.decode("utf-8") == '':
        socketio.emit('update_batterylevel', {'data':  0 , "is_plugged": 0 })
    else: 
        results = out_level.decode("utf-8").replace('\n','').split(' ')
        battery_level = int(results[1].split('.')[0])
        results = out_plugged.decode("utf-8").replace('\n','').split(' ')
        is_plugged = results[1]
        if is_plugged.find("true")!=-1:
            plugged = 1
        else:
            plugged = 0
        socketio.emit('update_batterylevel',
            {'data':  battery_level , "is_plugged": plugged })
def check_network_connection():
    process = subprocess.Popen(['iw','dev'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    
    
    ssid = ""
    ip_address = ""
#    print("", out, err)
    if err == '':
        try:
            results = out.split("Interface")[1].split('\n')
        except:
            print("USB Wifi is not connected!")
            return
 #       print("", results)
        for x in results:
            if x.find("ssid") != -1:
                s_pos = x.find(" ") + 1
                ssid = x[s_pos:].replace('"','')
                print("SSID: ", ssid)

    if not ssid == "":
        process = subprocess.Popen(['hostname','-I'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = process.communicate()
        out = out.decode("utf-8")
        err = err.decode("utf-8")
        ip_address = out
        print("ip_address: ", ssid)
    socketio.emit('network_connected_to', {'ssid': ssid, 'ip_address': ip_address})


def update_wifi():
    check_network_connection()
    process = subprocess.Popen(['sudo','iwlist','wlan1','scan'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()

#    print("",out.decode("utf-8"), err) 
    if out.decode("utf-8") == '':
        socketio.emit('update_wifi', { 'data': ''})
    else: 
        results = out.decode("utf-8").replace('\\','').split('Cell')
        wifi_list = []
        wifi_array = []
        
        for x in results:
            SSID = ""
            Encryption = 0
            Quality = 0
            
            skip = False
            for y in x.split('\n'):
                if y.find("Quality") != -1:
                    try:
                        tmp = y.split('Quality=')
                        tmp = tmp[1].split('S')
                        tmp = tmp[0].split('/')
                        Quality = int(float(tmp[0]) / float(tmp[1]) * 100.0)
                    except:
                        print("Skipped quality")
                        Quality = 1
                if y.find("Encryption") != -1:
                    if y.split(':')[1].find("on") != -1:
                        Encryption = 0
                    else:
                        Encryption = 1
                if y.find("SSID") != -1:
                    SSID += y.split('ESSID:')[1] 
                    if SSID.find("magnibot") != -1:
                        skip = True
                        break
                    if len(SSID) == 2:
                        skip = True
                        print("",len(SSID))
                        break

            if not skip and len(SSID) > 2:
                wifi_array.append([SSID, Quality, Encryption]) 

        # print(wifi_array)
        wifi_array.sort(key=lambda tup: tup[1],reverse=True)
        for w in wifi_array:
            wifi_string = "{\"SSID\": " + w[0] + ", " + "\"Quality\": \"" + str(w[1]) + "\", " + "\"Encryption\": \"" + str(w[2]) + "\"}"
            # print(wifi_string)
            wifi_list.append(wifi_string)
        socketio.emit('update_wifi', { 'data': wifi_list})

def change_ssid():
    process = subprocess.Popen(['bash','-c','./change_ssid.sh'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    ssid = ""
    print("", out, err)

@socketio.event
def connect_wifi(message):
    print("",message)
    wifi_lib.connect( message['SSID'], message['NO_PWD'], message['PWD'] )
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

@socketio.event
def advanced_connect_wifi(message):
    print("",message)
    wifi_lib.advanced_connect( message['SSID'], message['USERNAME'], message['PWD'] )
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

@socketio.event
def my_ping():
    emit('my_pong')
    

@socketio.event
def disconnect_wifi():
    print("Disconnect wifi")
    wifi_lib.disconnect()
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

@socketio.event
def set_rotation(message):
    print("set_rotation: ",message)
    global json_obj
    json_obj.set_rotation(message['rotation_value'])
    print('updated: ',json_obj.get_rotation())

@socketio.event
def set_brightness(message):
    print("",message)
    global json_obj
    json_obj.set_brightness(message['brightness_value'])
    print('updated: ',json_obj.get_brightness())

@socketio.event
def set_brightnessC(message):
    print("",message)
    global json_obj
    json_obj.set_brightnessC(message['brightness_value'])
    print('updated: ',json_obj.get_brightnessC())

@socketio.event
def set_contrast(message):
    print("",message)
    global json_obj
    json_obj.set_contrast(message['contrast_value'])
    print('updated: ',json_obj.get_contrast())

@socketio.event
def set_shaderIndex(message):
    print("",message)
    global json_obj
    
    json_obj.set_shaderIndex(message['shaderIndex'], current_orientation)
    print('updated: ',json_obj.get_shaderIndex(current_orientation))

@socketio.event
def restart():
    print("Reboot")
    #wifi_lib.disconnect()
    subprocess.Popen(['sudo','reboot'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

@socketio.event
def take_snapshot():
    print("take_snapshot")
    timestr = '/images/img_' + time.strftime("%Y%m%d%H%M%S") + '.jpg'
    os.system('rm static/images/img_*.jpg' )
    os.system('curl http://localhost/snapshot > static' + timestr )
    socketio.emit('finished_take_snapshot', { 'data' : timestr})

thread = None
thread_lock = Lock()
def background_thread():
    """Example of how to send server generated events to clients."""
    while True:
        socketio.sleep(5)
        getBatteryLevel()


thread2 = None
thread_lock2 = Lock()
current_orientation = 0
orientation_changed = False
orientation_stabilized_counter = 0
first_run = True
old_orientation = current_orientation

# import ArduinoReaderThread as ArduinoReaderThread
import ArduinoReader as ArduinoReader
arduino_thread = None

def background_thread2():
    """Example of how to send server generated events to clients."""
    global current_orientation
    # rotationLib = InputBridgeLib.InputBridgeLib()
    global arduino_thread
    global current_zoom
    global thread2
    global orientation_stabilized_counter
    global orientation_changed
    global first_run
    global old_orientation
    
    while True:
        socketio.sleep(0.05)
       
        if arduino_thread==None:
            continue
        new_orientation = arduino_thread.get_value()
        


        if new_orientation==None:
            continue
        
        try:
            new_orientation = int(new_orientation)    
        except TypeError:
            continue
        
        if new_orientation==8: # Skip dead zone
            new_orientation=None
            with thread_lock2:
                arduino_thread = None
                thread2 = None
                print("Arduino disconnected, refreshing window")
                socketio.emit('refresh_window')
                break

        if new_orientation!=None:
            if new_orientation!=current_orientation:
                if orientation_changed==False:
                    old_orientation = current_orientation
                    orientation_changed = True
                orientation_stabilized_counter = 0
            else:
                if orientation_changed:
                    orientation_stabilized_counter = orientation_stabilized_counter + 1
                    
                    if orientation_stabilized_counter > 13:
                        if new_orientation!=old_orientation or first_run:
                            
                            # json_obj.set_zoomIndex(current_zoom,int(current_orientation))
                            
                            start_orientation_change(new_orientation)
                            set_focus_mode(new_orientation)
                            print("set_focus_mode_finished")
                            set_rotation_zoom(new_orientation)
                            print("set_rotation_zoom_finished")
                            if new_orientation==UNMOUNTED_FAR:
                                print("UNMOUNTED_FAR")
                            elif new_orientation==MOUNTED_NEAR:
                                print("MOUNTED_NEAR")
                            elif new_orientation==MOUNTED_FAR:
                                print("MOUNTED_FAR")
                            end_orientation_change()
                        else:
                            print("Same orientation as starting...skip")
                        first_run = False          
                        orientation_changed = False
                    # else:
                    #     print("Waiting to stabilize: ", orientation_stabilized_counter)
                
            current_orientation = new_orientation

def start_arduino_thread():
    global thread2
    global arduino_thread
    with thread_lock2:
        if thread2==None:
            arduino_thread = ArduinoReader.ArduinoReader() # replace '/dev/ttyACM0' with your port and 9600 with your baud rate
            # arduino_thread.start()
            thread2 = socketio.start_background_task(background_thread2)


def clean_logs():
    process = subprocess.Popen(['bash','-c','./clean_space.sh'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()
    out = out.decode("utf-8")
    err = err.decode("utf-8")
    print("", out, err)
    
@socketio.event
def test_connect():
    print("No internet")
    stop_motors()
    socketio.emit(
            'first_connect',
            {
                'calibrated_rotation': json_obj.get_rotation() ,
                'calibrated_brightness': json_obj.get_brightness() , 
                'calibrated_brightnessC': json_obj.get_brightnessC() , 
                'calibrated_contrast': json_obj.get_contrast() ,
                'shaderIndex': json_obj.get_shaderIndex(current_orientation) ,
                'video_format': json_obj.get_video_mode() ,
                'video_resolution': json_obj.get_video_resolution() ,
                'verson_code': json_obj.get_version_code() ,
                'current_orientation' : current_orientation,
                }) 
    global thread
    getBatteryLevel()
    with thread_lock:
        if thread is None:
            thread = socketio.start_background_task(background_thread)

    update_wifi()
    start_arduino_thread()
    end_orientation_change()
    
def set_rotation_zoom(p_new_orientation):
    global current_orientation
    global current_zoom
    start_time = time.time()
    
    current_zoom = cameraZoom.zoomGet()
    
    if current_zoom > 30:
        current_zoom = 30
    elif current_zoom < 1:
        current_zoom = 1
    
    tmp_zoom = json_obj.get_zoomIndex(int(p_new_orientation))

    print("current_zoom: ",current_zoom,", new_zoom: ",tmp_zoom)
    if current_zoom < tmp_zoom:
        cameraZoom.zoomIn()
        while True:
            time.sleep(0.1)
            c_zoom = cameraZoom.zoomGet()
            # print("cameraZoom.zoomGet(): ", c_zoom, ", new_zoom",tmp_zoom)
            if c_zoom >= tmp_zoom :
                tmp_zoom = cameraZoom.zoomStop()
                break
            else:
                current_time = time.time()
                elapsed_time = current_time - start_time
                if elapsed_time >= 15:
                    start_time = time.time()
                    break
            
            
    elif current_zoom > tmp_zoom:
        cameraZoom.zoomOut()
        while True:
            time.sleep(0.1)
            c_zoom = cameraZoom.zoomGet()
            # print("cameraZoom.zoomGet(): ", c_zoom, ", new_zoom",tmp_zoom)
            if c_zoom <= tmp_zoom :
                tmp_zoom = cameraZoom.zoomStop()
                break
            else:
                current_time = time.time()
                elapsed_time = current_time - start_time
                if elapsed_time >= 15:
                    start_time = time.time()
                    break
            
        
    current_zoom = tmp_zoom

def set_focus_mode(p_new_orientation):
    global current_orientation
    global cameraZoom
    if p_new_orientation == UNMOUNTED_FAR or p_new_orientation == MOUNTED_FAR:
        cameraZoom.zoomFocusInfinity()
    elif p_new_orientation==2:
        cameraZoom.zoomFocusThirty()
def stop_motors():
    global  horizontal_direction
    global vertical_direction
    hMotor.motor_stop()
    vMotor.motor_stop()
    horizontal_direction = 0
    vertical_direction = 0
        
def start_orientation_change(p_new_orientation):
    stop_motors()
    socketio.emit(
        'update_orientation', 
        { 
         'orientation' : p_new_orientation, 
         'color' : json_obj.get_shaderIndex(int(p_new_orientation)),
         'rotation' : json_obj.get_rotation()
         
         })

def end_orientation_change():
    socketio.emit('finished_orientation')
        
    
if __name__ == '__main__':
    clean_logs()
    change_ssid()
    socketio.run(app, host='127.0.0.1', port=5000, debug=True)
    
    
