#!/usr/bin/bash
# Install janus and janus-dev
sudo apt update
if  grep -q "bullseye-backports" /etc/apt/sources.list ; then
    echo 'the backports exists' ; 
else
    echo 'the backports does not exist' ; 
	echo "deb http://deb.debian.org/debian bullseye-backports main contrib non-free" | sudo tee -a /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian bullseye-backports main contrib non-free" | sudo tee -a /etc/apt/sources.list
	wget https://ftp-master.debian.org/keys/archive-key-11.asc
	sudo apt-key add archive-key-11.asc
	rm archive-key-11.asc
fi

sudo apt update
sudo apt install janus -t bullseye-backports -y
sudo apt install janus-dev -t bullseye-backports -y
cd ~/magnibot
sudo cp -rf configs/etc_janus/*.jcfg /etc/janus/
# Build ustreamer with janus enabled
cd ~/
rm -rf ustreamer/
sudo apt install libasound2-dev libspeex-dev libspeexdsp-dev libopus-dev -y
sudo sed \
	  --in-place \
	    --expression 's|^#include "refcount.h"$|#include "../refcount.h"|g' \
	      /usr/include/janus/plugins/plugin.h
git clone --depth=1 https://github.com/trysightdev/ustreamer.git
cd ustreamer
make WITH_JANUS=1
sudo systemctl stop ustreamer.service
sudo mv src/ustreamer.bin /usr/bin/ustreamer
sudo mv janus/libjanus_ustreamer.so /usr/lib/arm-linux-gnueabihf/janus/plugins/
cd ~/magnibot
sudo cp configs/etc_systemd_system/ustreamer.default.service /etc/systemd/system/ustreamer.service
sudo systemctl daemon-reload
sudo systemctl restart ustreamer.service
sudo systemctl restart janus.service
sudo rm -rf /etc/nginx/sites-enabled/*
sudo cp configs/etc_nginx_sites-available/magnibot.conf /etc/nginx/sites-enabled/magnibot.conf
sudo systemctl restart nginx.service
cp settings.json.default settings.json
exit
