# get file size in python
import os
import json
import subprocess

subprocess.run(['rm','-rf','output'])
subprocess.run(['mkdir','output'])
cmd="tar --exclude='./output' --exclude='./__pycache__' --exclude='./.github' --exclude='./.git' --exclude='./venv' -cvzf output/magnibot.tar.gz ./"
subprocess.run(cmd,shell=True)

file_name = "output/magnibot.tar.gz"

file_stats = os.stat(file_name)

print(f'File Size in Bytes is {file_stats.st_size}')
with open( 'settings.default.json', 'r') as f:
    settings_data = json.load(f)

del settings_data['calibrated_rotation']
del settings_data['calibrated_brightness']
del settings_data['calibrated_contrast']
del settings_data['video_mode']
del settings_data['video_resolution']

settings_data['file_size_bytes']=file_stats.st_size
with open( 'version.json', 'w') as f:
    json.dump(settings_data, f)

if file_stats.st_size == settings_data['file_size_bytes']:
    print("File size correct")

subprocess.run(['mv','version.json','output/version.json'])

# print(f'File Size in MegaBytes is {file_stats.st_size / (1024 * 1024)}')