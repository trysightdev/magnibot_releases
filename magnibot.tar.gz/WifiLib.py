import subprocess
# Program to show various ways to read and
# write data in a file.
#SSID = "Acanac_05374"
#NO_PWD = True
#PWD = "9057824004"
class WifiLib(object):
    def __init__(self, debug = False):
        self.debug = debug
        self.filename = "wpa_supplicant.conf"
        self.source_dir = "./"
        self.dest_dir = "/etc/wpa_supplicant/"


    def zoomStop(self):
        result = 0
        if self.access_type == "library":
            result = self.my_functions.zoomStop()
            print("zoomStop: " + str(result))
        elif self.access_type == "binary":
            self.process.stdin.write(b's\n')
            self.process.stdin.flush()
            output = self.process.stdout.readline().decode("utf-8").strip().split() 
            result = int(output[1])
            print("zoomStop: " + str(result))
        self.isZooming = False
        return result
    def disconnect(self):
        file1 = open(self.source_dir + self.filename,"w")
        L = ["ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\n",
                "update_config=1\n",
                "country=US\n",
                "network={\n",
                "}",
                ] 
        file1.writelines(L)
        file1.close() #to change file access modes
        subprocess.run(['sudo', 'cp', '-rf', self.source_dir + self.filename, self.dest_dir + self.filename])
#        subprocess.run(['sudo', 'wpa_cli', '-i', 'wlan0', 'reconfigure'])
    def connect(self, SSID = "", NO_PWD = 0, PWD = ""):
        file1 = open(self.source_dir + self.filename,"w")
        L = ["ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\n",
                "update_config=1\n",
                "country=US\n",
                "network={\n",
                "\tssid=\"" + SSID + "\"\n",
                ] 
        if NO_PWD == 1:
            L.append("\tkey_mgmt=NONE\n")
        else:
            L.append("\tpsk=\"" + PWD + "\"\n")
        L.append("}")
        
        file1.writelines(L)
        file1.close() #to change file access modes
        subprocess.run(['sudo', 'cp', '-rf', self.source_dir + self.filename, self.dest_dir + self.filename])
#        subprocess.run(['sudo', 'wpa_cli', '-i', 'wlan0', 'reconfigure'])
    def advanced_connect(self, SSID = "", USERNAME = "", PWD = ""):
        file1 = open(self.source_dir + self.filename,"w")
        L = ["ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\n",
                "update_config=1\n",
                "country=US\n",
                "network={\n",
                "\tssid=\"" + SSID + "\"\n",
                ] 
        L.append("\tkey_mgmt=WPA-EAP\n")
        L.append("\tidentity=\"" + USERNAME+"\"\n")
        L.append("\tpassword=\"" + PWD + "\"\n")
        L.append("}")
        
        file1.writelines(L)
        file1.close() #to change file access modes
        subprocess.run(['sudo', 'cp', '-rf', self.source_dir + self.filename, self.dest_dir + self.filename])
