class VideoRecorder {
    recordedChunks = [];
    recording = false;
    paused = false;
    startTime = Date.now();
    toggleInterval;
    constructor(canvas, videoButton) {
        this.videoButton = videoButton;

        let stream = canvas.captureStream();
        this.createMediaStream(stream);

        if (navigator.mediaDevices != undefined) {
            navigator.mediaDevices.getUserMedia({ audio: true })
                .then((audioStream) => {
                    stream.addTrack(audioStream);
                    this.createMediaStream(stream);
                })
        }
    }

    createMediaStream(stream) {
        this.mediaRecorder = new MediaRecorder(stream);
        this.mediaRecorder.ondataavailable = (e) => this.handleDataAvailable(e);
    }

    toggleRecording() {
        if( this.paused )
            return;

        if (!this.recording) {
            this.startRecording();
        } else {
            this.stopRecording();
        }
    }

    startRecording() {
        this.startTime = Date.now();
        this.recordedChunks = [];
        this.recording = true;
        this.mediaRecorder.start();
        videoButton.style.backgroundColor = "#ff000088";
        videoButton.classList.remove('record_video');
        videoButton.classList.add('stop_recording');
        

        // Create a new div element
        var div = document.createElement("div");

        // Add any desired content or styles to the div
        div.style.backgroundColor = "transparent";
        div.style.width = "15vh";
        div.style.height = "15vh";
        div.style.position = "fixed";
        div.style.bottom = "0";
        div.style.right = "0";

        var recordingImage = document.createElement("img");
        recordingImage.id = "recording-blink";
        recordingImage.src = "/images/recording.png";
        recordingImage.style.width = "100%";
        recordingImage.style.height = "100%";

        div.appendChild(recordingImage);


        // Find the element with the class name "overlay6"
        var overlay6Element = document.querySelector(".overlay6");
        overlay6Element.innerHTML = "";

        // Add the created div to the overlay6 element
        overlay6Element.appendChild(div);
        overlay6Element.style.display = "inline";
        overlay6Element.style.pointerEvents = "none";
        this.toggleInterval = setInterval(function(){
            var recordingBlink = document.getElementById('recording-blink');
            if( recordingBlink  )
            {
                recordingBlink.style.display = recordingBlink.style.display === "none" ? "block" : "none";
            }
        }, 500);
        
        
    }

    stopRecording() {
        this.recording = false;
        this.mediaRecorder.stop();
        videoButton.style.backgroundColor = "";
        videoButton.classList.remove('stop_recording');
        videoButton.classList.add('record_video');

        clearInterval(this.toggleInterval, 500);
        var overlay6Element = document.querySelector(".overlay6");
        overlay6Element.innerHTML = "";
        overlay6Element.style.pointerEvents = "auto";
        overlay6Element.style.display = "none";

        
    }

    freezeVideo() {
        this.paused = true;
        freezeButton.style.backgroundColor = "#00aaff";
        freezeButton.classList.remove('freeze');
        freezeButton.classList.add('stop_recording');

        // Create a new div element
        var div = document.createElement("div");

        // Add any desired content or styles to the div
        div.style.backgroundColor = "transparent";
        div.style.width = "15vh";
        div.style.height = "15vh";
        div.style.position = "fixed";
        div.style.top = "15vh";
        div.style.right = "0";

        var recordingImage = document.createElement("img");
        recordingImage.id = "recording-blink";
        recordingImage.src = "/images/freeze.png";
        recordingImage.style.width = "100%";
        recordingImage.style.height = "100%";

        div.appendChild(recordingImage);


        // Find the element with the class name "overlay6"
        var overlay6Element = document.querySelector(".overlay6");
        overlay6Element.innerHTML = "";

        // Add the created div to the overlay6 element
        overlay6Element.appendChild(div);
        overlay6Element.style.display = "inline";
        overlay6Element.style.pointerEvents = "none";
        this.toggleInterval = setInterval(function(){
            var recordingBlink = document.getElementById('recording-blink');
            if( recordingBlink  )
            {
                recordingBlink.style.display = recordingBlink.style.display === "none" ? "block" : "none";
            }
        }, 500);

        motor_controller.disable_motors();
    }

    unfreezeVideo() {
        this.paused = false;
        freezeButton.style.backgroundColor = "";
        freezeButton.classList.remove('stop_recording');
        freezeButton.classList.add('freeze');

        clearInterval(this.toggleInterval, 500);
        var overlay6Element = document.querySelector(".overlay6");
        overlay6Element.innerHTML = "";
        overlay6Element.style.pointerEvents = "auto";
        overlay6Element.style.display = "none";

        motor_controller.enable_motors();
    }

    toggleFreeze() {
        if( this.recording)
            return;

        if (!this.paused) {
            this.freezeVideo();
        } else {
            this.unfreezeVideo();
        }
    }



    handleDataAvailable(event) {
        console.log("data-available");
        if (event.data.size > 0) {
            console.log(this);
            this.recordedChunks.push(event.data);
            console.log(this.recordedChunks);
            this.download();
        } else {
            // …
        }
    }

    download() {
        const duration = Date.now() - this.startTime;

        const blob = new Blob(this.recordedChunks, {
            type: "video/webm",
        });
        //ysFixWebmDuration(blob, duration, function (fixedBlob) {
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            console.log(url, a);
            document.body.appendChild(a);
            a.style = "display: none";
            a.href = url;
            a.download = `Magnibot ${new Date().toLocaleTimeString()} ${new Date().toLocaleDateString()}.mp4`;
            a.click();
            window.URL.revokeObjectURL(url);
        //});

    }
}

const videoButton = document.getElementById("recordVideo");
const freezeButton = document.getElementById("button27");
const videoRecorder = new VideoRecorder(document.getElementById("renderTarget"), videoButton);

videoButton.addEventListener("click", () => {
    videoRecorder.toggleRecording();
});



freezeButton.addEventListener("click", () => {
    videoRecorder.toggleFreeze();
});
