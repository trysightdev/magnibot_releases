class VideoRecorder {
    recordedChunks = [];
    recording = false;
    startTime = Date.now();

    constructor(canvas, videoButton) {
        this.videoButton = videoButton;

        let stream = canvas.captureStream();
        this.createMediaStream(stream);

        if (navigator.mediaDevices != undefined) {
            navigator.mediaDevices.getUserMedia({ audio: true })
                .then((audioStream) => {
                    stream.addTrack(audioStream);
                    this.createMediaStream(stream);
                })
        }
    }

    createMediaStream(stream) {
        this.mediaRecorder = new MediaRecorder(stream);
        this.mediaRecorder.ondataavailable = (e) => this.handleDataAvailable(e);
    }

    toggleRecording() {
        if (!this.recording) {
            this.startRecording();
        } else {
            this.stopRecording();
        }
    }

    startRecording() {
        this.startTime = Date.now();
        this.recordedChunks = [];
        this.recording = true;
        this.mediaRecorder.start();
        videoButton.style.backgroundColor = "#ff000088";
    }

    stopRecording() {
        this.recording = false;
        this.mediaRecorder.stop();
        videoButton.style.backgroundColor = "";
    }

    handleDataAvailable(event) {
        console.log("data-available");
        if (event.data.size > 0) {
            console.log(this);
            this.recordedChunks.push(event.data);
            console.log(this.recordedChunks);
            this.download();
        } else {
            // …
        }
    }

    download() {
        const duration = Date.now() - this.startTime;

        const blob = new Blob(this.recordedChunks, {
            type: "video/webm",
        });
        //ysFixWebmDuration(blob, duration, function (fixedBlob) {
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            console.log(url, a);
            document.body.appendChild(a);
            a.style = "display: none";
            a.href = url;
            a.download = `Magnibot ${new Date().toLocaleTimeString()} ${new Date().toLocaleDateString()}.mp4`;
            a.click();
            window.URL.revokeObjectURL(url);
        //});

    }
}

const videoButton = document.getElementById("recordVideo");
const videoRecorder = new VideoRecorder(document.getElementById("renderTarget"), videoButton);

videoButton.addEventListener("click", () => {
    videoRecorder.toggleRecording();
});

