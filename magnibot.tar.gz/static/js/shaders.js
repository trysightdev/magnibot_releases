

const SC_HEADER = "precision mediump float;" + // Set the default precision to medium. 

    "uniform sampler2D u_Texture;" + // The contrast lookup table.

    "uniform float u_ContrastA;" + // Subtracted Value
    "uniform float u_ContrastB;" + // Multiplied Value
    "uniform float u_ContrastC;" + // Added Value
    "uniform float contrast;" +

    "varying vec2 vTextureCoord;" + // Interpolated texture coordinate per fragment.

    "void main()" + //The entry point for our fragment shader.
    "{" +
    "gl_FragColor = vec4(1.0, 1.0, 1.0, 1.0);" +
    "";


const CONTRAST = "tempColor.rgb = ((tempColor.rgb - 0.5) * max(contrast, 0.0)) + 0.5;";

//	private static final String SC_GRAYSCALE_FORMULA = "   "; //float grayScale = (tempColor.r);"; // float grayScale = min(tempColor.b,grayScale1);";
const SC_GRAYSCALE_FORMULA = "   float grayScale = (tempColor.r * 0.299) + (tempColor.g * 0.587) + (tempColor.b *  0.114) ; ";

const SC_BLUE_ON_YELLOW =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    SC_GRAYSCALE_FORMULA +
    "   float binarized = smoothstep(u_ContrastA,u_ContrastB,grayScale);" +
    "	gl_FragColor = vec4(1.0-binarized,1.0-binarized,binarized,1);" +
    "}" +
    "";

const SC_YELLOW_ON_BLUE =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    SC_GRAYSCALE_FORMULA +
    "   float binarized = smoothstep(u_ContrastA,u_ContrastB,grayScale);" +
    "	gl_FragColor = vec4(binarized,binarized,1.0-binarized,1);" + // R,G,B
    "}" +

    "";

const SC_BLACK_ON_WHITE =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    SC_GRAYSCALE_FORMULA +
    "   float binarized = smoothstep(u_ContrastA,u_ContrastB,grayScale);" +
    "	gl_FragColor = vec4(binarized,binarized,binarized,1);" + // R,G,B
    "}" +

    "";


const SC_BLACK_ON_YELLOW =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    SC_GRAYSCALE_FORMULA +
    "   float binarized = smoothstep(u_ContrastA,u_ContrastB,grayScale);" +
    "	gl_FragColor = vec4(binarized,binarized,0.0,1);" + // R,G,B
    "}" +

    "";



const SC_YELLOW_ON_BLACK =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    SC_GRAYSCALE_FORMULA +
    "   float binarized = smoothstep(u_ContrastA,u_ContrastB,grayScale);" +
    "	gl_FragColor = vec4(1.0-binarized,1.0-binarized,0.0,1);" + // R,G,B
    "}" +

    "";

const SC_WHITE_ON_BLACK =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    SC_GRAYSCALE_FORMULA +
    "   float binarized = smoothstep(u_ContrastA,u_ContrastB,grayScale);" +
    "	gl_FragColor = vec4(1.0-binarized,1.0-binarized,1.0-binarized,1);" + // R,G,B
    "}" +

    "";

const SC_BLACK_ON_GREEN =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    SC_GRAYSCALE_FORMULA +
    "   float binarized = smoothstep(u_ContrastA,u_ContrastB,grayScale);" +
    "	gl_FragColor = vec4(0.0,binarized,0.0,1);" + // R,G,B
    "}" +

    "";

const SC_GREEN_ON_BLACK =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    SC_GRAYSCALE_FORMULA +
    "   float binarized = smoothstep(u_ContrastA,u_ContrastB,grayScale);" +
    "	gl_FragColor = vec4(0.0,1.0-binarized,0.0,1);" + // R,G,B
    "}" +

    "";

const SC_GRAYSCALE =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    SC_GRAYSCALE_FORMULA +
    "	gl_FragColor = vec4(grayScale,grayScale,grayScale,1);" + // R,G,B
    "}" +

    "";

const SC_HIGH_CONTRAST =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    "	gl_FragColor.x = (tempColor.x - u_ContrastC) * 1.50 + u_ContrastC;" +	// Set Red   - Contrast Stretched Red
    "	gl_FragColor.y = (tempColor.y - u_ContrastC) * 1.50 + u_ContrastC;" +	// Set Green - Contrast Stretched Green
    "	gl_FragColor.z = (tempColor.z - u_ContrastC) * 1.50 + u_ContrastC;" +	// Set Blue  - Contrast Stretched Blue
    "}" +


    "";

const SC_ORIGINAL =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    "	gl_FragColor = tempColor;	" +
    "}" +


    "";


const SC_GRAYSCALESHADER =
    "	vec4 tempColor = texture2D(u_Texture, vTextureCoord);" + // Sample the texture value
    CONTRAST +
    SC_GRAYSCALE_FORMULA +
    "	gl_FragColor = vec4(grayScale,grayScale,grayScale,1);" + // R,G,B
    "	gl_FragColor.x = (gl_FragColor.x - u_ContrastC) * 1.50 + u_ContrastC;" +	// Set Red   - Contrast Stretched Red
    "	gl_FragColor.y = (gl_FragColor.y - u_ContrastC) * 1.50 + u_ContrastC;" +	// Set Green - Contrast Stretched Green
    "	gl_FragColor.z = (gl_FragColor.z - u_ContrastC) * 1.50 + u_ContrastC;" +	// Set Blue  - Contrast Stretched Blue
    "}" +

    "";


FRAGMENT_SHADERS = [
    //SC_HEADER + SC_ORIGINAL,
    { shader: SC_HEADER + SC_HIGH_CONTRAST, usesCAsBrightness: true },
    { shader: SC_HEADER + SC_BLACK_ON_WHITE },
    { shader: SC_HEADER + SC_WHITE_ON_BLACK },

    { shader: SC_HEADER + SC_BLACK_ON_YELLOW },
    { shader: SC_HEADER + SC_YELLOW_ON_BLACK },

    { shader: SC_HEADER + SC_BLACK_ON_GREEN },
    { shader: SC_HEADER + SC_GREEN_ON_BLACK },

    { shader: SC_HEADER + SC_BLUE_ON_YELLOW },
    { shader: SC_HEADER + SC_YELLOW_ON_BLUE },
    { shader: SC_HEADER + SC_GRAYSCALESHADER, usesCAsBrightness: true  },
];