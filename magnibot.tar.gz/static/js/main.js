var colorIndex = localStorage.getItem('color_index',0);
var button1 = $('#button1')[0];

var button2 = $('#button2')[0];
var button3 = $('#button3')[0];

var button4 = $('#button4')[0];
var button5 = $('#button5')[0];
var button6 = $('#button6')[0];
var button7 = $('#button7')[0];
var button8 = $('#button8')[0];
var button9 = $('#button9')[0];
var button10 = $('#button10')[0];
var button11 = $('#button11')[0];
var button12 = $('#button12')[0];
var button13 = $('#button13')[0];
var button14 = $('#button14')[0];
var button15 = $('#button15')[0];
var button16 = $('#button16')[0];
var button17 = $('#button17')[0];
var button18 = $('#button18')[0];
var button19 = $('#button19')[0];
var button20 = $('#button20')[0];
var button21 = $('#button21')[0];
var button22 = $('#button22')[0];
var button23 = $('#button23')[0];
var button24 = $('#button24')[0];

var overlay2 = $('.overlay2')[0];
var canvas = document.querySelector('#canvas');
var context = canvas.getContext('2d');

var videoFormatValue = 0;
var videoResolutionValue = 0;
var versionCode = "Version ";
var contrastValue = 100.0;
var brightnessValue = 120.0;
var colorString = ""
var rotationValue = 0;
var brightnessString = "contrast(" + contrastValue.toString() +"%) brightness(" + brightnessValue.toString() +"%) " + colorString;
var isContrastPanelVisible = false;
var isWifiPanelVisible = false;

let CONTRAST_INCREMENT = 1;
var breakLoop = false;
var socket = io();
var messageCounter = 0;
var domElement = $(".overlay2")[0];
var finger_area = $("#contact")[0];
	var panActive = false;
var pinchActive = false;
var animationFrameId = null;
var ticking = false;
var isButtonsVisible = false;
var options = {
  "supportedGestures" : [Pan, Pinch]
};
var lastScale = 0;
var startTime, endTime;
var noMovement = 0;
var startingDistance = 0;
var touchCounter = 0;
var scaling = true;
var direction = 0;
var lastDistance = [0,0];
var direction2 = 0;
var noMovement2 = 0;
var pointerListener = new PointerListener(domElement, options);
var MOVEMENT_THRESHOLD = 5;
var wifi_networks = [];
var connecting_to_wifi = false;
var first_run = true;
var connected_to = "";
var resolution_changed = false;
var updating_device = false;
function requestElementUpdate(transformString) {
	if(!ticking) {
		animationFrameId = requestAnimationFrame(function(timestamp){
			finger_area.style.transform = transformString;
								
			animationFrameId = null;
			ticking = false;
		
			//socket.emit('my_event', {data: 'zoomin'});
		});
		
		ticking = true;
	}

}
function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}
function isTouchDevice() {
  return (('ontouchstart' in window) ||
	 (navigator.maxTouchPoints > 0) ||
	 (navigator.msMaxTouchPoints > 0));
}
function updatePreview(){
	brightnessString = "contrast(" + contrastValue.toString() +"%) brightness(" + brightnessValue.toString() +"%) " + colorString;

		$("#video_preview").css("-webkit-filter", brightnessString );
		$("#video_preview").css("-ms-filter", brightnessString );
		$("#video_preview").css("-o-filter", brightnessString );
		$("#video_preview").css("filter", brightnessString );
var rotationString = "rotate("+rotationValue.toString() +"deg) scale(1.06)";
		$("#video_preview").css("-webkit-transform", rotationString );
		$("#video_preview").css("-ms-transform", rotationString );
		$("#video_preview").css("-o-transform", rotationString );
		$("#video_preview").css("transform", rotationString );
}
function updateWifi(){
	socket.emit('update_wifi');
}
function setBrightness(mode){
	
	if( mode == 1) 
		brightnessValue += CONTRAST_INCREMENT;
	else if( mode == 2)
		brightnessValue -= CONTRAST_INCREMENT;
	else if ( mode == 0)
		brightnessValue = 120;
	socket.emit('set_brightness', {brightness_value: brightnessValue });
	updatePreview();
}
function setContrast(mode){
	if( mode == 1) 
		contrastValue += CONTRAST_INCREMENT;
	else if( mode == 2)
		contrastValue -= CONTRAST_INCREMENT;
	else
		contrastValue = 100;
	socket.emit('set_contrast', {contrast_value: contrastValue });
	updatePreview();
}

function toggleMenu(){
	
	if( isButtonsVisible ){
		$(".inner").css("display", "none");		
		$(".overlay0").css("height", "15%");		
		$(".overlay2").css("top", "15%");	
		$(".overlay2").css("height", "85%");	
	
		$(".toggleMenu").css("background-image", "url(\"/images/down.png\")");
		$(".toggle_menu").css("height", "100%");

		isButtonsVisible = false;
		$(".overlay1").css("display", "none");	
		isContrastPanelVisible = false;
		$(".overlay4").css("display", "none");		
		isWifiPanelVisible = false;

	}else{
		$(".inner").css("display","table");
		$(".overlay0").css("height", "30%");		
		$(".overlay2").css("top", "30%");	
		$(".overlay2").css("height", "70%");	

		$(".toggleMenu").css("background-image", "url(\"/images/up.png\")");
		$(".toggle_menu").css("height", "50%");

		isButtonsVisible = true;
	}
}
function toggleContrastPanel(){
	
	if( isContrastPanelVisible ){
		$(".overlay1").css("display", "none");		
		isContrastPanelVisible = false;
	}else{
		$(".overlay1").css("display","inline");
		isContrastPanelVisible = true;
	}
}
function setHighlightByID(pButtonID)
{
	$(pButtonID).mousedown(function() {
		$(this).css('background-color', 'green');
	});
	$(pButtonID).mouseup(function() {
		$(this).css('background-color', 'white');
	});

	$(pButtonID).on('touchstart',function() {
		$(this).css('background-color', 'green');
	});
	$(pButtonID).on('touchend',function() {
		$(this).css('background-color', 'white');
	});

}
function toggleUpdate(pUpdateAvailable){
	
	if( isWifiPanelVisible ){
		$(".overlay6").css("display", "none");		
		isWifiPanelVisible = false;
	}else{
		if( pUpdateAvailable )
		{
			$(".overlay6").empty();		
			$(".overlay6").prepend('<table class="popup_panel"></table>');		
			var logDiv = $('.popup_panel')[0];
			logDiv.replaceChildren();
	
			$(".overlay6").css("height", "50%");	
	
			$(".popup_panel").append(`
						<tr>
						<td colspan="1" style="line-height: 1.25em;font-size: 5vmin;text-align: center;">
						Magnibot ${versionCode} is already the latest version.<br>
						</td>
						</tr>
						<tr>
						<td>
						<button id="update_cancel" class="button">Cancel</button>
						</td>
						</tr>
			`);
	

	
			setHighlightByID('#update_cancel');
	
			$("#update_cancel").on("pointerup", function(){
				$(".overlay6").css("display", "none");		
				isWifiPanelVisible = false;
	
			});
		}
		else
		{
			$(".overlay6").empty();		
			$(".overlay6").prepend('<table class="popup_panel"></table>');		
			var logDiv = $('.popup_panel')[0];
			logDiv.replaceChildren();
	
			$(".overlay6").css("height", "50%");	
	
			$(".popup_panel").append(`
						<tr>
						<td colspan="2" style="line-height: 1.25em;font-size: 5vmin;text-align: center;">
						
						Magnibot update is available.<br>
						Click Update to upgrade to the latest version.
						</td>
						</tr>
						<tr>
						<td>
						<button id="update_ok" class="button">Update</button>
						</td>
						<td>
						<button id="update_cancel" class="button">Cancel</button>
						</td>
						</tr>
			`);
	
	
			setHighlightByID('#update_ok');
			setHighlightByID('#update_cancel');
	
			$("#update_ok").on("pointerup", function(){
				$(".overlay6").css("display", "none");		
				isWifiPanelVisible = false;
				socket.emit('update_app');
				updating_device = true;
				$(".overlay2").empty();
				$(".overlay2").prepend(`
						<div class="popup_box" >
						Updating...		
						</div>
						`);
	
			});
			$("#update_cancel").on("pointerup", function(){
				$(".overlay6").css("display", "none");		
				isWifiPanelVisible = false;
	
			});
		}



		$(".overlay6").css("display","inline");
		isWifiPanelVisible = true;
	}
}

function toggleWifiPanel(){
	
	if( isWifiPanelVisible ){
		$(".overlay4").css("display", "none");		
		isWifiPanelVisible = false;
		//updateWifi();
	}else{
		$(".overlay4").empty();		
		$(".overlay4").prepend('<table class="wifi_panel"></table>');		
		var logDiv = $('.wifi_panel')[0];
		logDiv.replaceChildren();
		
		var rowIdx = 0;

		var tableHeightPct = 80;
		var rowHeightPct = 10;
		var tableHeight = Math.min(rowHeightPct * wifi_networks.length, tableHeightPct);
		$(".overlay4").css("height", tableHeight + "%");	

			  
		// jQuery button click event to add a row.

		var maxNetworksAllowed = Math.min( tableHeightPct / rowHeightPct , wifi_networks.length );
		for( let i = 0; i < maxNetworksAllowed; i++)
		{
			const myArr = wifi_networks[i];

			var no_password = Number(myArr.Encryption);
			var signal_strength = Number(myArr.Quality);
			var wifi_icon = "";
			var image_string = "/images/"
			var pwd_icon = "";
			var signal_icon = "";
			if( no_password == 1 )
				pwd_icon = "";
			else
				pwd_icon = "_pwd";

			var strong = 80;
			var medium = 60;
			if( signal_strength >= strong )
				signal_icon = "_strong";
			else if( signal_strength < strong && signal_strength >= medium )
				signal_icon = "_medium";
			else if( signal_strength < medium )
				signal_icon = "_weak";

			var connected_icon = "";
			var disconnect_icon = "";
			console.log(myArr.SSID);
			console.log(connected_to);
			if( myArr.SSID == connected_to )
			{
				connected_icon = image_string + "checkmark.png";
				disconnect_icon = image_string + "remove.png";
			}
			else
				connected_icon = "";

			wifi_icon = image_string + "wifi" + signal_icon + pwd_icon + ".png"
			var buttonHeight = heightInner * 0.05;
			$(".wifi_panel").append(`<tr>
					<td style="width: 15%;"><button id="R_${i}" class="button" style="background-image: url('${wifi_icon}')" ></button></td>
					<td style="width: 75%;"><button id="R_${i}" class="button b_wifi" style="font-size: ${buttonHeight}px;" >${myArr.SSID}</button></td>
					<td style="width: 5%;border:0px solid red;padding: 0 2vmin 0 0;"><button id="R_${i}" class="button" style="background-image: url('${connected_icon}')" ></button></td>
					<td style="width: 5%;border:0px solid red;padding: 0 2vmin 0 0;"><button id="R_${i}" class="button wifi_disconnect" style="background-image: url('${disconnect_icon}')" ></button></td>
					</tr>`);

			console.log( myArr.SSID );
		}

			$(".wifi_disconnect").on("click", function(){
				let text = "Press OK to disconnect Wifi or Cancel.";
				if( confirm(text) == true)
				{
					socket.emit('disconnect_wifi');
					connecting_to_wifi = true;
					$(".overlay2").append(`
							<div class="popup_box" >
							Restarting...		
							</div>
							`);
					$(".overlay4").css("display", "none");		
					isWifiPanelVisible = false;
	
				}
				else
				{
					console.log("Cancelled disconnect");
				}
		});
			$(".b_wifi").on("click", function(){
				var wifiIndex = Number($(this).attr("id").split("_")[1]);
				var selected = wifi_networks[wifiIndex];
				var no_pwd = Number(selected.Encryption);
				var pwd = "";
				if( no_pwd == 0 )
				{
					pwd = prompt('Password: ');
					if( pwd == null )
						alert("Password is empty");
					else
					{
						socket.emit('connect_wifi', {SSID: selected.SSID, NO_PWD: no_pwd, PWD: pwd });
						connecting_to_wifi = true;
						$(".overlay2").append(`
								<div class="popup_box" >
								Restarting...		
								</div>
								`);
					}				
				}
				else
				{
					socket.emit('connect_wifi', {SSID: selected.SSID, NO_PWD: no_pwd, PWD: pwd });
					console.log( "" +  pwd);
					connecting_to_wifi = true;
						$(".overlay2").append(`
								<div class="popup_box" >
								Restarting...		
								</div>
								`);
				}
				$(".overlay4").css("display", "none");		
				isWifiPanelVisible = false;

				});
		$(".overlay4").css("display","inline");
		isWifiPanelVisible = true;
	}
}
function takeSnapshot()
{
	console.log("Take snapshot");
	socket.emit('take_snapshot');
}
function togglePicturePanel(data){
	console.log(data);	
		$(".overlay5").empty();
//		$(".overlay5").prepend('<img id="theImg" src="'+ data +'" /><a id="downloadImg" href="'+ data +'" download>Download</a>');
		$(".overlay5").prepend('<a id="downloadImg" href="'+ data +'" download>Download</a>');
		$("#downloadImg")[0].click();				
		$(".overlay5").empty();		
}
function toggleColor(){
	
	colorIndex++;
	if( colorIndex > 2 )
		colorIndex = 0;

	if (colorIndex == 0) 
	{
		colorString = "";
	}
	else if (colorIndex == 1)
	{
		colorString = "grayscale(100%)"
	}
	else if (colorIndex == 2)
	{
		colorString = "invert(100%)"
	}
	updatePreview();

	localStorage.setItem('color_index',colorIndex);
}
function initColor(){

	if( colorIndex > 2 )
		colorIndex = 0;

	if (colorIndex == 0) 
	{
		colorString = "";
	}
	else if (colorIndex == 1)
	{
		colorString = "grayscale(100%)"
	}
	else if (colorIndex == 2)
	{
		colorString = "invert(100%)"
	}
	updatePreview();

}
function initHighlight(){
	$('.button').mousedown(function() {
		$(this).css('background-color', 'green');
	});
	$('.button').mouseup(function() {
		$(this).css('background-color', 'white');
	});
	$('.button').on('touchstart',function() {
		$(this).css('background-color', 'green');
	});
	$('.button').on('touchend',function() {
		$(this).css('background-color', 'white');
	});

}
var ping_pong_times = [];
var start_time;
var myInterval;
var popup_open = false;
function registerIncomingSocketEvents(){	

	

	socket.on('check_for_update_response', function(msg){
		var data = msg.data;
		console.log(data);

		$(".overlay2").empty();


		toggleUpdate(data);
			
			

	});

		socket.on('finished_take_snapshot', function(msg){
				
				console.log('picture_saved');
				var data = msg.data;
				console.log(data);

				togglePicturePanel(data);
			});

	// Event handler for new connections.
	socket.on('connect',function(){

			socket.emit('test_connect');
		});
	// Event handler for server sent data.
	socket.on('my_response', function(msg, cb) {
			
		var logDiv = $('#log')[0];
		logDiv.replaceChildren();
		logDiv.append($('<div/>').text('Received #' + msg.count + ': ' + msg.data).html());
		var tmpString = msg.data;
		if( tmpString != "" )
		{
			console.log(tmpString);
			connected_to = tmpString;
		}
		if( connecting_to_wifi == true )
		{
			setTimeout(function(){
					
			window.location.reload();
			console.log("connecting caused reload");
					}, 10000);
			connecting_to_wifi = false;
		}

		if (cb)
			cb();
	});

	socket.on('first_connect', function(msg){
		if( first_run == false && connecting_to_wifi == false )
		{
			console.log("Second run...restart");
		if( resolution_changed || updating_device)
			{
				setTimeout(function(){
					
				window.location.reload();
					console.log("Restarting in 6 secs");
					}, 6000);
				resolution_changed = false;
				console.log("Resolution changed OR Updating");
			}
			else
				window.location.reload();
		}

		if( first_run == true )
		{
			first_run = false;
			console.log("First run: " + msg.calibrated_rotation + ", " + msg.calibrated_brightness + ", " + msg.calibrated_contrast + ", " 
			+ msg.video_format + ", " + msg.video_resolution + ", " + msg.verson_code);

			
			rotationValue = parseFloat(msg.calibrated_rotation);
			brightnessValue = parseFloat(msg.calibrated_brightness);
			contrastValue = parseFloat(msg.calibrated_contrast);
			videoFormatValue = parseInt(msg.video_format);
			videoResolutionValue = parseInt(msg.video_resolution) ;
			versionCode += msg.verson_code ;

			button23.textContent = versionCode;

			if( videoFormatValue == 1 )
			{
				onVideoSelection(button20);
			}
			else
			{
				onVideoSelection(button19);
			}
				

			if( videoResolutionValue == 1 )
			{
				onVideoSelection(button22);
			}
			else
			{
				onVideoSelection(button21);
			}

			updatePreview();

						// Interval function that tests message latency by sending a "ping"
			// message. The server then responds with a "pong" message and the
			// round trip time is measured.
			if( videoFormatValue == 0 && videoResolutionValue == 1)
			{
				console.log("Already optimized");
				popup_open = true;
			}

			// Disable popup for now until I find a better way to get the FPS.
			popup_open = true;

//			myInterval = window.setInterval(function() {
//				start_time = (new Date).getTime();
//				socket.emit('my_ping');
//			}, 1000);		


		}
		});

	socket.on('refresh_window', function(){
			window.location.reload();
		});
	socket.on('update_batterylevel', function(msg) {

				//{'data': str( result[0] ) + "%", "is_plugged": result[1] })
		console.log(msg.is_plugged);
		var level = parseInt(msg.data);
		var plugged = parseInt(msg.is_plugged, 10);
		if( plugged == 1 )
		{
			$(".batteryLevel").css("background-image", "url(\"/images/full_battery_charging.png\")");
		}
		else
		{
			if( 100 >= level && level >= 70 ){
				$(".batteryLevel").css("background-image", "url(\"/images/full_battery.png\")");
			}
			else if( 70 > level && level >= 30 )
			{
				$(".batteryLevel").css("background-image", "url(\"/images/medium_battery.png\")");
			}
			else if( 30 > level && level >= 0 )
			{
				$(".batteryLevel").css("background-image", "url(\"/images/low_battery.png\")");
			}

		}
		if( plugged == 0 )		
			button16.textContent = msg.data + "%";
		else
			button16.textContent = "";

	});



			// Handler for the "pong" message. When the pong is received, the
			// time from the ping is stored, and the average of the last 30
			// samples is average and displayed.
//            socket.on('my_pong', function() {
//
//				
//                var latency = (new Date).getTime() - start_time;
//                ping_pong_times.push(latency);
//                ping_pong_times = ping_pong_times.slice(-30); // keep last 30 samples
//                var sum = 0;
//                for (var i = 0; i < ping_pong_times.length; i++)
//                    sum += ping_pong_times[i];
//				
//					if( ping_pong_times.length > 10 )
//					{
//						clearInterval(myInterval);
//						var avg_latency = Math.round(10 * sum / ping_pong_times.length) / 10;
//						
//						if( avg_latency > 200.0)
//						{
//							if( popup_open )
//							{
//								// console.log("Pop up already open.");
//							}
//							else
//							{
//								popup_open = true;
//								console.log("Bad Ping: " + avg_latency);
//								$(".overlay2").empty();
//								$(".overlay2").prepend(`
//										<div class="message" >
//										<table class="contrast_panel">
//										<tr>
//										<td style="line-height: 1.25em;">
//										Weak connection detected.<br>
//										For better performance switch to Efficent/720p in Settings.
//										</td>
//										</tr>
//										<tr>
//										<td>
//										<button id="performance_popup" class="button">Close</button>
//										</td>
//										</tr>
//										
//										</div>
//										`);
//					
//								$("#performance_popup")[0].addEventListener('pointerdown', function(e){
//									$(".overlay2").empty()
//									
//								});
//
//							}
//
//	
//						}
//						else{
//							console.log("Good Ping: " + avg_latency);
//						}
//						
//					}
//					else
//					{
//						console.log("Ping: " + Math.round(10 * sum / ping_pong_times.length) / 10);
//					}
//            });


	socket.on('update_wifi', function(msg) {

		var data = msg.data;
		wifi_networks = [];
		for( let i = 0; i < data.length; i++)
		{
			const myArr = JSON.parse(data[i]);
			wifi_networks.push( myArr );

			console.log( data[i]);
		}

		$(".toggleMenu").css("display", "inline");
		console.log("Show arrow");

	});

}
function onVideoSelection(video_button){
	video_button.style.fontWeight = "bold";
	video_button.style.textDecoration = "underline";
	video_button.setAttribute("disabled", "disabled");
}
function log(e){
		var logDiv = $('#log')[0];
		logDiv.replaceChildren();
		messageCounter++;
		logDiv.append($('<div/>').text('JS #' + messageCounter + ': ' + e).html());

}

async function loopFunction(cb, mode){

	breakLoop = false;
	for (let i = 0; i < 50000; i++) {
			if( breakLoop )
				break;
			
			if( cb )
				cb(mode);
			await sleep(10);
	}

}
function stopLoop(){
	breakLoop = true;
}

function initButtonEvents(btnDown,btnUp)
{
	button1.addEventListener(btnDown, function(e){
			socket.emit('my_event', {data: 'left'});
			
		});
	button1.addEventListener(btnUp, function(e){
			socket.emit('my_event', {data: 'stopHorizontal'});
			
			
		} );
	button2.addEventListener(btnDown, function(e){
			socket.emit('my_event', {data: 'right'});
			
		});
	button2.addEventListener(btnUp, function(e){
			socket.emit('my_event', {data: 'stopHorizontal'});
			
			
		} );
	button3.addEventListener(btnDown, function(e){
			socket.emit('my_event', {data: 'up'});
			
		});
	button3.addEventListener(btnUp, function(e){
			socket.emit('my_event', {data: 'stopVertical'});
			
			
		} );
	button4.addEventListener(btnDown, function(e){
			socket.emit('my_event', {data: 'down'});
			
		});
	button4.addEventListener(btnUp, function(e){
			socket.emit('my_event', {data: 'stopVertical'});
			

		} );
	button5.addEventListener(btnDown, function(e){
			socket.emit('my_event', {data: 'zoomin'});
			
		});
	button5.addEventListener(btnUp, function(e){
			socket.emit('my_event', {data: 'zoomstop'});
			
			
		} );
	button6.addEventListener(btnDown, function(e){
			socket.emit('my_event', {data: 'zoomout'});
			
		});
	button6.addEventListener(btnUp, function(e){
			socket.emit('my_event', {data: 'zoomstop'});
			

		} );
	button7.addEventListener(btnDown, function(e){
			
		});
	button7.addEventListener(btnUp, function(e){
			
			toggleColor(); 
		} );
	button8.addEventListener(btnDown, function(e){
			
		});
	button8.addEventListener(btnUp, function(e){
			
			toggleMenu(); 

		} );
	button9.addEventListener(btnDown, function(e){
			
		});
	button9.addEventListener(btnUp, function(e){
			
			toggleContrastPanel(); 

		} );
	button10.addEventListener(btnDown, function(e){
			
		});
	button10.addEventListener(btnUp, function(e){
			
			setBrightness(0);
		} );
	button11.addEventListener(btnDown, function(e){
			
			loopFunction( setBrightness, 1 );
				});
	button11.addEventListener(btnUp, function(e){
			
			stopLoop();
		} );

	button12.addEventListener(btnDown, function(e){
			
			loopFunction( setBrightness, 2 );

		});
	button12.addEventListener(btnUp, function(e){
			
			stopLoop();
		} );
	button13.addEventListener(btnDown, function(e){
			
		});
	button13.addEventListener(btnUp, function(e){
			
			setContrast(0);
		} );
	button14.addEventListener(btnDown, function(e){
			
			loopFunction( setContrast, 1);
		});
	button14.addEventListener(btnUp, function(e){
			
			stopLoop();
		} );

	button15.addEventListener(btnDown, function(e){
			
			loopFunction( setContrast, 2);
		});
	button15.addEventListener(btnUp, function(e){
			
			stopLoop();
		} );
	button17.addEventListener(btnDown, function(e){
		});
	button17.addEventListener(btnUp, function(e){
			toggleWifiPanel();
		} );

	button18.addEventListener(btnDown, function(e){
		});
	button18.addEventListener(btnUp, function(e){
			takeSnapshot();
	//		document.getElementById('save_picture').click();
		 } );
		 button19.addEventListener(btnDown, function(e){
				

			
		} );
		 button19.addEventListener(btnUp, function(e){
			videoFormatValue = 0;
			setToggleVideoOptions(videoFormatValue,videoResolutionValue);
		} );
		button20.addEventListener(btnUp, function(e){
			videoFormatValue = 1;
			setToggleVideoOptions(videoFormatValue,videoResolutionValue);
		} );
		button21.addEventListener(btnUp, function(e){
			videoResolutionValue = 0;
			setToggleVideoOptions(videoFormatValue,videoResolutionValue);
		} );
		button22.addEventListener(btnUp, function(e){
			videoResolutionValue = 1;
			setToggleVideoOptions(videoFormatValue,videoResolutionValue);
		} );

		button24.addEventListener(btnUp, function(e){
			checkForUpdate();
		} );
}
function checkForUpdate(){
	socket.emit('check_for_update');
	$(".overlay1").css("display", "none");		
	isContrastPanelVisible = false;
	resolution_changed == true;
			$(".overlay2").empty();
			$(".overlay2").prepend(`
					<div class="popup_box" >
					Checking for update...
					</div>
					`);
}
function setToggleVideoOptions(p_format,p_resolution){
	socket.emit('toggle_h264', {format: p_format, resolution: p_resolution});
	$(".overlay1").css("display", "none");		
	isContrastPanelVisible = false;
	resolution_changed = true;
			$(".overlay2").empty();
			$(".overlay2").prepend(`
					<div class="popup_box" >
					Restarting...		
					</div>
					`);
}
function initPinch()
{
	domElement.addEventListener('pinchstart', function(event){
		startPinchEvent = event;
		direction = 0;
		lastScale = 1;
		noMovement = 0;
		startTime = new Date();
		log("pinstart");
	});
	
	
	domElement.addEventListener('pinch', function(event){
		if (pinchActive == false){
			pinchActive = true;
		}
		endTime = new Date();
		var elapsedTime = endTime - startTime; //in ms
		if( elapsedTime < 100 )
			return;
		startTime = new Date();
		// transform	
		var scale = event.detail.global.scale;
		
		var transformString = "scale3d(" + scale + ", " + scale + ", 1)";
		var currentDelta = lastScale - scale;
		log("deltaScale: " + currentDelta);
		if( Math.abs(currentDelta) > 0.03) 
		{
			noMovement = 0;
			if ( currentDelta > 0 )
			{
				if( direction == 2 )
				{
					direction = 0;
			
				}
				if( direction == 0 )
					socket.emit('my_event', {data: 'zoomout'});
				direction = 1;
			}
			else if ( currentDelta < 0 )
			{
				if( direction == 1)
				{
					direction = 0;
				}
				if( direction == 0 )
					socket.emit('my_event', {data: 'zoomin'});
				direction = 2;
			}
		}
		else
		{
			noMovement++;
			if( direction != 0 && noMovement >= 3 )
			{
				noMovement = 0;	
				direction = 0;
				socket.emit('my_event', {data: 'zoomstop'});
			
			}
		}
		lastScale = scale;
	});
	
	domElement.addEventListener('pinchend', function(event){
		pinchActive = false;
		
		direction = 0;
		socket.emit('my_event', {data: 'zoomstop'});
			
		var transformString = 'scale3d(1, 1, 1)';
	});	
}

function drawLine(context, x1, y1, x2, y2) {
	context.beginPath();
	context.moveTo(x1, y1);
	context.lineTo(x2, y2);
	context.stroke();
}

function drawHead(context, x1, y1, x2, y2, filled) {
	var dx = x2 - x1;
	var dy = y2 - y1;
	context.beginPath();
	context.moveTo(x1 + 0.5 * dy, y1 - 0.5 * dx); // https://dirask.com/posts/jMqM0j
	context.lineTo(x1 - 0.5 * dy, y1 + 0.5 * dx); // https://dirask.com/posts/1GoW61
	context.lineTo(x2, y2);
	context.closePath();
	filled ? context.fill() : context.stroke();
}

// Draws arrow on the canvas.
//
// context - drawing context
// x1, y1  - arrow staring point
// x2, y2  - arrow ending point
// arrow   - (optional) arrow head size (from 0 to 1 - relatively measured to arrow size)
// filled  - (optional) if true, the arrow head should be filled with some color
//
function drawArrow(context, x1, y1, x2, y2, arrow, filled) {
	if (arrow == null) {
	arrow = 0.1;
	}
	var dx = x2 - x1;
	var dy = y2 - y1;
	var t = 1.0 - arrow;
	var middleX = dx * t + x1;
	var middleY = dy * t + y1;
	drawLine(context, x1, y1, middleX, middleY);
	drawHead(context, middleX, middleY, x2, y2, filled);
}
function drawFilledArrow(context, x1, y1, x2, y2, arrow, color, width) {
	context.lineWidth = width;
	context.fillStyle = color;
	context.strokeStyle = color;
	drawArrow(context, x1, y1, x2, y2, arrow, true);
}
function initKeys()
{
	document.addEventListener('keydown', function(event) {
				if (event.keyCode == 188) {
					rotationValue -= 0.1;
	socket.emit('set_rotation', {rotation_value: rotationValue });
						updatePreview();
						}
				else if (event.keyCode == 190) {
					   rotationValue += 0.1;
	socket.emit('set_rotation', {rotation_value: rotationValue });
						updatePreview();
						}
				else if (event.keyCode == 82) {
					console.log("R key");
				let text = "Press OK to disconnect Wifi or Cancel.";
				if( confirm(text) == true)
				{
					socket.emit('restart');
					connecting_to_wifi = true;
					$(".overlay2").append(`
							<div class="popup_box" >
							Restarting...		
							</div>
							`);
					$(".overlay4").css("display", "none");		
					isWifiPanelVisible = false;
	
				}
				else
				{
					console.log("Cancelled disconnect");
				}
					}
			else if(event.keyCode == 84){


			}
		}, true);
}
function favTutorial(){
	console.log("Called");
	var vid_format = document.getElementById("video_format");  
	console.log(vid_format.options[vid_format.selectedIndex].text);
	var vid_res = document.getElementById("video_resolution");  
	console.log(vid_res.options[vid_res.selectedIndex].text);
}
var startX = 0;
var startY = 0;
function initPan()
{
	socket.emit('pan_setarea', {box_bounds: MAX_FINGER_AREA, min_distance: MIN_DISTANCE });
	
	domElement.addEventListener('panstart', function(event){
		direction = 0;
		lastScale = 1;
		noMovement = 0;
		startTime = new Date();
		var x = event.detail.global.deltaX;
		var y = event.detail.global.deltaY
		lastDistance =  [x, y];
		finger_area.style.visibility = "visible";

		finger_area.style.position = "absolute";
		finger_area.style.left = event.detail.global.srcEvent.clientX + 'px';
		finger_area.style.top = event.detail.global.srcEvent.clientY + 'px';
		startX = event.detail.global.srcEvent.clientX; 
		startY = event.detail.global.srcEvent.clientY;
	});
	domElement.addEventListener('pan', function(event){
		if (panActive == false){
			panActive = true;
		}
		endTime = new Date();
		var elapsedTime = endTime - startTime; //in ms
		if( elapsedTime < 100 )
			return;
		startTime = new Date();
		
		// transform
		var x = event.detail.global.deltaX;
		var y = event.detail.global.deltaY
		var deltaX = lastDistance[0] - x;
		var deltaY = lastDistance[1] - y;
		var destX = event.detail.global.srcEvent.clientX - startX;
		var destY = event.detail.global.srcEvent.clientY - startY;

		var x1 = canvas.width/2;
		var y1 = canvas.height/2;
		var aspectRatio = canvas.width / canvas.height;
		var x2 = Math.max(0, Math.min(x1 + destX, canvas.width));
		var y2 = Math.max(0, Math.min(y1 + (destY / aspectRatio), canvas.height));
		context.clearRect(0, 0, canvas.width, canvas.height);
		// https://stackoverlow.com/questions/9614109/how-to-calculate-an-angle-from-points
		var distanceY = y2 - y1;
		var distanceX = x2 - x1;
		// https://www.mathsisfun.com/sine-cosine-tangent.html
		var theta = Math.atan2(distanceY, distanceX); // range (-PI, PI)
		theta *= 180 / Math.PI; // radians to degrees (-180,180)
		if( theta < 0) 
			theta = 360 + theta; // range [0, 360]
//		console.log("theta: " + theta);
	var distanceFromOrigin = Math.sqrt( (distanceX*distanceX) + (distanceY*distanceY) );
		if( isNaN( distanceFromOrigin ) )
			distanceFromOrigin = 0;

		socket.emit('pan_event', {data: 'pan', distanceFromOrigin: distanceFromOrigin, angle_degrees: theta });
		var cx=x1;
		var cy=y1;
		var radius=50;
		var colors=['red','blue','green','gold'];
		
		var color = 'red';
		var angle_threshold = 30;
		if( distanceFromOrigin > MIN_DISTANCE )
		{
			if( theta > 360 - angle_threshold || theta < 0 + angle_threshold )
				color = 'green';
			else if(theta > 90 - angle_threshold && theta < 90 + angle_threshold)
				color = 'green';
			else if(theta > 180 - angle_threshold && theta < 180 + angle_threshold)
				color = 'green';
			else if(theta > 270 - angle_threshold && theta < 270 + angle_threshold)
				color = 'green';
		}
		if( color === 'green' )
									 {
		var arrowWidth = MAX_FINGER_AREA *.02;
		drawFilledArrow(context,x1, y1, x2, y2, 0.35, color, arrowWidth);
		context.beginPath();
		context.arc(x1, y1, MIN_DISTANCE , 0, 2 * Math.PI);
		console.log( "width: " + canvas.width + ", height: " + canvas.height + ", " + distanceX + ", " + distanceY );
		console.log( "MIN_DISTANCE: " + MIN_DISTANCE + ", MAX_DISTANCE: " + MAX_FINGER_AREA + ", " + distanceFromOrigin );
		context.stroke();
		context.fill();
									 }
									 else
									 {

		var arrowWidth = MAX_FINGER_AREA *.02;
		drawFilledArrow(context,x1, y1, x1, y1, 0.35, color, arrowWidth);
		context.beginPath();
		context.arc(x1, y1, MIN_DISTANCE , 0, 2 * Math.PI);
		console.log( "width: " + canvas.width + ", height: " + canvas.height + ", " + distanceX + ", " + distanceY );
		console.log( "MIN_DISTANCE: " + MIN_DISTANCE + ", MAX_DISTANCE: " + MAX_FINGER_AREA + ", " + distanceFromOrigin );
		context.stroke();
		context.fill();
									 }
	});
	
	domElement.addEventListener('panend', function(event){
		panActive = false;
		direction = 0;
		direction2 = 0;
		socket.emit('pan_event', {data: 'panend', distanceFromOrigin: 0, angle_degrees: 0 });

		finger_area.style.visibility = "hidden";

	});
}
function startBatteryThread()
{
	socket.emit('test_connect');
}


var heightInner = window.innerHeight;
var MAX_FINGER_AREA = heightInner * 0.85;
var MIN_DISTANCE = MAX_FINGER_AREA * .04;
finger_area.width = MAX_FINGER_AREA;// + 'px'
finger_area.height = MAX_FINGER_AREA;// + 'px'
canvas.width = MAX_FINGER_AREA;// + 'px'
canvas.height = MAX_FINGER_AREA;// + 'px'
window.oncontextmenu = function() { return false; }

// Main
initHighlight();
registerIncomingSocketEvents();
initButtonEvents('pointerdown','pointerup');
initPinch();
initPan();
initColor();
initKeys();

