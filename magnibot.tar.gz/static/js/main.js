// Create a new PointerEvent of type 'pointerdown'
var eventPointerDown = new PointerEvent('pointerdown', {
	bubbles: true,
	cancelable: true,
	view: window
});
// Create a new PointerEvent of type 'pointerdown'
var eventPointerUp = new PointerEvent('pointerup', {
	bubbles: true,
	cancelable: true,
	view: window
});
var magnibotSettings = [];
var colorIndex = localStorage.getItem('color_index', 0);
var button1 = $('#button1')[0];
var button2 = $('#button2')[0];
var button3 = $('#button3')[0];
var button4 = $('#button4')[0];
var button5 = $('#button5')[0];
var button6 = $('#button6')[0];
var button7 = $('#button7')[0];
var button8 = $('#button8')[0];
var button9 = $('#button9')[0];
var button10 = $('#button10')[0];
var button11 = $('#button11')[0];
var button12 = $('#button12')[0];
var button13 = $('#button13')[0];
var button14 = $('#button14')[0];
var button15 = $('#button15')[0];
var button16 = $('#button16')[0];
var button17 = $('#button17')[0];
var button18 = $('#button18')[0];
var button19 = $('#button19')[0];
var button20 = $('#button20')[0];
var button21 = $('#button21')[0];
var button22 = $('#button22')[0];
var button23 = $('#button23')[0];
var button24 = $('#button24')[0];
var button26 = $('#button26')[0];
var button27 = $('#button27')[0];
var button28 = $('#button28')[0];
var overlay2 = $('.overlay2')[0];
var canvas = document.querySelector('#canvas');
var context = canvas.getContext('2d');
var videoFormatValue = 0;
var videoResolutionValue = 0;
var versionCode = "Version ";
var contrastValue = 100.0;
var brightnessValue = 120.0;
var colorString = ""
var rotationValue = 0;
var stand_rotation = 270.0;
var scaleValue = 1.06;
var brightnessString = "contrast(" + contrastValue.toString() + "%) brightness(" + brightnessValue.toString() + "%) " + colorString;
var isContrastPanelVisible = false;
var isWifiPanelVisible = false;
let CONTRAST_INCREMENT = 1;
var breakLoop = false;
var socket = io();
var messageCounter = 0;
var domElement = $(".overlay2")[0];
var finger_area = $("#contact")[0];
var panActive = false;
var pinchActive = false;
var animationFrameId = null;
var ticking = false;
var isButtonsVisible = false;
var options = {
	"supportedGestures": [Pan, Pinch]
};
var lastScale = 0;
var startTime, endTime;
var noMovement = 0;
var startingDistance = 0;
var touchCounter = 0;
var scaling = true;
var direction = 0;
var lastDistance = [0, 0];
var direction2 = 0;
var noMovement2 = 0;
var pointerListener = new PointerListener(domElement, options);
var MOVEMENT_THRESHOLD = 5;
var wifi_networks = [];
var first_run = true;
var connected_to = "";
var wifi_ip_address = "";
var manual_restart = false;
var ping_interval = 1000;
var wifi_advanced_checked = false;
var currentOrientation = 0;
var unmounted_rotation = 0.0;
var mounted_rotation = 0.0;
var battery_timer = null;
var batteryLevel = 100;
var is_charging = false;

class MotorController {
	motorsEnabled = true;
	constructor() {
		console.log("MotorController");
	}
	disable_motors() {
		this.motorsEnabled = false;
	}
	enable_motors() {
		this.motorsEnabled = true;
	}
	enabled() {
		return this.motorsEnabled;
	}
	left() {
		if (!this.motorsEnabled) return;
		socket.emit('my_event', { data: 'left' });
	}
	right() {
		if (!this.motorsEnabled) return;
		socket.emit('my_event', { data: 'right' });
	}
	up() {
		if (!this.motorsEnabled) return;
		socket.emit('my_event', { data: 'up' });
	}
	down() {
		if (!this.motorsEnabled) return;
		socket.emit('my_event', { data: 'down' });
	}
	stopHorizontal() {
		socket.emit('my_event', { data: 'stopHorizontal' });
	}
	stopVertical() {
		socket.emit('my_event', { data: 'stopVertical' });
	}
	pan_setarea(bounds, min_dist) {
		socket.emit('pan_setarea', { box_bounds: bounds, min_distance: min_dist });
	}
	pan_start(dfo, angleDegrees) {
		if (!this.motorsEnabled) return;
		socket.emit('pan_event', { data: 'pan', distanceFromOrigin: dfo, angle_degrees: angleDegrees });
	}
	pan_end() {
		socket.emit('pan_event', { data: 'panend', distanceFromOrigin: 0, angle_degrees: 0 });
	}
	toggle_camera() {
		socket.emit('my_event', { data: 'toggle_camera' });
	}
	focus_near() {
		socket.emit('my_event', { data: 'focus_near' });
	}
	focus_far() {
		socket.emit('my_event', { data: 'focus_far' });
	}
	debug_motors() {
		socket.emit('my_event', { data: 'debug_motors' });
	}
	zoom_in() {
		socket.emit('my_event', { data: 'zoomin' });
	}
	zoom_out() {
		socket.emit('my_event', { data: 'zoomout' });
	}
	zoom_stop() {
		socket.emit('my_event', { data: 'zoomstop' });
	}
}
var motor_controller = new MotorController();
var magnibotSettings = {
	calibrated_rotation: [0, 0],
	shaderIndex: [0, 0],
	zoomIndex: [1, 1],
	fragmentShaders: [1, 1, 1, 1, 1, 1, 1, 1, 1],
	calibrated_brightness: 0.7,
	calibrated_brightnessC: 0.2,
	calibrated_contrast: 1,
	video_mode: 1,
	video_resolution: 0,
	version_code: "3.85",
	motorSpeed: 1,
	mounted_rotation: 0,
	refreshRate: 0
};
var popup_obj = {
	init: function () {
		console.log("Popup initialized");
	},
	show_popup: function (str) {
		this.clear_popup();
		$(".overlay2").prepend(`
						<div class="popup_box" >
						${str}	
						</div>
						`);
	},
	clear_popup: function () {
		$(".overlay2").empty();
	}
}
var disconnect_monitor_obj = {
	init: function () {
		disconnect_monitor_obj.check_server_status();
	},
	check_server_status: function () {
		socket.emit('my_ping');
		if (socket_disconnected == true) {
			if (manual_restart) {
				console.log("Delay caused by restart");
			}
			else {
				popup_obj.show_popup("Wifi disconnected...");
			}
		}
		else {
			setTimeout(disconnect_monitor_obj.check_server_status, ping_interval);
		}
	}
}
var debuggerObject = {
	init: function () {
		debuggerObject.check_server_status();
	},
	check_server_status: function () {
		const pointerUpEvent = new PointerEvent("pointerup", {
			bubbles: true,
			cancelable: true,
			pointerType: "touch",
		});
		button17.dispatchEvent(pointerUpEvent);
		setTimeout(debuggerObject.check_server_status, 30000);
	}
}
function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}
function updatePreview() {
	brightnessString = "contrast(" + contrastValue.toString() + "%) brightness(" + brightnessValue.toString() + "%) " + colorString;
	var rotationString = "rotate(" + rotationValue.toString() + "deg) scale(" + scaleValue.toString() + ")";
	$("#renderTarget").css("-webkit-transform", rotationString);
	$("#renderTarget").css("-ms-transform", rotationString);
	$("#renderTarget").css("-o-transform", rotationString);
	$("#renderTarget").css("transform", rotationString);
}
function updateWifi() {
	socket.emit('update_wifi');
}
function setBrightness(mode) {
	if (mode == 1) {
		brightnessValue += CONTRAST_INCREMENT;
		increaseBrightness();
	} else if (mode == 2) {
		brightnessValue -= CONTRAST_INCREMENT;
		decreaseBrightness();
	} else if (mode == 0) {
		brightnessValue = 120;
		resetBrightness();
	}
	updatePreview();
}
function setContrast(mode) {
	if (mode == 1) {
		contrastValue += CONTRAST_INCREMENT;
		// console.log("contrastValue: ",contrastValue);
		increaseContrast();
	} else if (mode == 2) {
		contrastValue -= CONTRAST_INCREMENT;
		// console.log("contrastValue: ",contrastValue);
		decreaseContrast();
	} else {
		contrastValue = 100;
		// console.log("contrastValue: ",contrastValue);
		resetContrast();
	}
	updatePreview();
}
function toggleMenu() {
	if (isButtonsVisible) {
		$(".inner").css("display", "none");
		$(".overlay0").css("height", "15%");
		$(".overlay2").css("top", "15%");
		$(".overlay2").css("height", "85%");
		$(".toggleMenu").css("background-image", "url(\"/images/down.png\")");
		$(".toggle_menu").css("height", "100%");
		isButtonsVisible = false;
		$(".overlay1").css("display", "none");
		isContrastPanelVisible = false;
		$(".overlay4").css("display", "none");
		document.getElementById('camera-dropdown').style.display = 'none';
		isWifiPanelVisible = false;
	} else {
		$(".inner").css("display", "table");
		$(".overlay0").css("height", "30%");
		$(".overlay2").css("top", "30%");
		$(".overlay2").css("height", "70%");
		$(".toggleMenu").css("background-image", "url(\"/images/up.png\")");
		$(".toggle_menu").css("height", "50%");
		isButtonsVisible = true;
	}
}
function toggleContrastPanel() {
	document.getElementById('camera-dropdown').style.display = 'none';
	if (isWifiPanelVisible) {
		$(".overlay4").css("display", "none");
		isWifiPanelVisible = false;
	}
	if (isContrastPanelVisible) {
		$(".overlay1").css("display", "none");
		isContrastPanelVisible = false;
	} else {
		$(".overlay1").css("display", "inline");
		isContrastPanelVisible = true;
	}
}
function setHighlightByID(pButtonID) {
	$(pButtonID).mousedown(function () {
		$(this).css('background-color', 'green');
	});
	$(pButtonID).mouseup(function () {
		$(this).css('background-color', 'white');
	});
	$(pButtonID).on('touchstart', function () {
		$(this).css('background-color', 'green');
	});
	$(pButtonID).on('touchend', function () {
		$(this).css('background-color', 'white');
	});
}

function force_update(){
	// checkForUpdate();
	$(".overlay6").css("display", "none");
	isWifiPanelVisible = false;
	socket.emit('update_app');
	manual_restart = true;
	popup_obj.show_popup("Updating...");
}
function toggleUpdate(pUpdateAvailable) {
	if (isWifiPanelVisible) {
		$(".overlay6").css("display", "none");
		isWifiPanelVisible = false;
	} else {
		if (pUpdateAvailable) {
			$(".overlay6").empty();
			$(".overlay6").prepend('<table class="popup_panel"></table>');
			var logDiv = $('.popup_panel')[0];
			logDiv.replaceChildren();
			$(".overlay6").css("height", "50%");
			$(".popup_panel").append(`
						<tr>
						<td colspan="1" style="line-height: 1.25em;font-size: 5vmin;text-align: center;">
						Magnibot ${versionCode} is already the latest version.<br>
						</td>
						</tr>
						<tr>
						<td>
						<button id="update_cancel" class="button">Ok</button>
						</td>
						</tr>
			`);
			setHighlightByID('#update_cancel');
			$("#update_cancel").on("pointerup", function () {
				$(".overlay6").css("display", "none");
				isWifiPanelVisible = false;
			});
		}
		else {
			$(".overlay6").empty();
			$(".overlay6").prepend('<table class="popup_panel"></table>');
			var logDiv = $('.popup_panel')[0];
			logDiv.replaceChildren();
			$(".overlay6").css("height", "50%");
			$(".popup_panel").append(`
						<tr>
						<td colspan="2" style="line-height: 1.25em;font-size: 5vmin;text-align: center;">
						Magnibot update is available.<br>
						Click Update to upgrade to the latest version.
						</td>
						</tr>
						<tr>
						<td>
						<button id="update_ok" class="button">Update</button>
						</td>
						<td>
						<button id="update_cancel" class="button">Cancel</button>
						</td>
						</tr>
			`);
			setHighlightByID('#update_ok');
			setHighlightByID('#update_cancel');
			$("#update_ok").on("pointerup", function () {
				force_update();
			});
			$("#update_cancel").on("pointerup", function () {
				$(".overlay6").css("display", "none");
				isWifiPanelVisible = false;
			});
		}
		$(".overlay6").css("display", "inline");
		isWifiPanelVisible = true;
	}
}
let advanced_wifi_options = false;
function passwordPopUp(pSSID) {
	advanced_wifi_options = false;
	$(".overlay6").empty();
	$(".overlay6").prepend('<table class="popup_panel"></table>');
	var logDiv = $('.popup_panel')[0];
	logDiv.replaceChildren();
	$(".overlay6").css("height", "55%");
	$(".popup_panel").append(`
						<tr>
						<td colspan="2" style="line-height: 1.25em;font-size: 5vmin;text-align: center;">
						<label for="uname">${pSSID}</label>
						</td>
						</tr>
						<tr id="row_wusername" style="display: none;">
						<td colspan="2" style="line-height: 1.25em;font-size: 5vmin;text-align: center;">Username: 							
						<input
						type="text"
						id="wifi_username"
						name="wname"
						required
						size="20"
						maxlength="30"
						style="line-height: 1.25em;font-size: 5vmin;text-align: left;" 
						/>
					  <span class="validity"></span></td></tr>
					  <td colspan="2" style="line-height: 1.25em;font-size: 5vmin;text-align: center;">Password: 							
					  <input
					  type="text"
					  id="wifi_password"
					  name="wpassword"
					  required
					  size="20"
					  maxlength="30"
					  style="line-height: 1.25em;font-size: 5vmin;text-align: left;"
					   />
					<span class="validity"></span></td></tr>
					</td>
					<tr ><td colspan="2" style="text-align: center;">
					<button id="wifi_advanced" class="button">Advanced</button></td></tr>
						<tr style="height:15vmin;">
						<td>
						<button id="update_ok" class="button">Connect</button>
						</td>
						<td>
						<button id="update_cancel" class="button">Cancel</button>
						</td>
						</tr>
			`);
	setHighlightByID('#update_ok');
	setHighlightByID('#update_cancel');
	setHighlightByID('#wifi_advanced');
	$("#wifi_advanced").on("pointerup", function () {
		advanced_wifi_options = !advanced_wifi_options;
		if (advanced_wifi_options) {
			$('#row_wusername').css("display", "table-row");
		}
		else {
			$('#row_wusername').css("display", "none");
		}
	});
	$("#update_ok").on("pointerup", function () {
		var passwordValue = jQuery.trim($('#wifi_password').val());
		if (passwordValue.length == 0) {
			alert("Pasword is Empty");
			return;
		}
		var isChecked = advanced_wifi_options;
		if (isChecked) {
			var usernameValue = jQuery.trim($('#wifi_username').val());
			if (usernameValue.length == 0) {
				alert("Username is Empty");
				return;
			}
			$(".overlay6").css("display", "none");
			console.log("%s, %s, %s", pSSID, usernameValue, passwordValue);
			socket.emit('advanced_connect_wifi', { SSID: pSSID, USERNAME: usernameValue, PWD: passwordValue });
			manual_restart = true;
			$(".overlay2").append(`
					<div class="popup_box" >
					Restarting...		
					</div>
					`);
		}
		else {
			$(".overlay6").css("display", "none");
			socket.emit('connect_wifi', { SSID: pSSID, NO_PWD: 0, PWD: passwordValue });
			manual_restart = true;
			$(".overlay2").append(`
					<div class="popup_box" >
					Restarting...		
					</div>
					`);
		}
		isWifiPanelVisible = false;
	});
	$("#update_cancel").on("pointerup", function () {
		$(".overlay6").css("display", "none");
		isWifiPanelVisible = false;
	});
	$(".overlay6").css("display", "inline");
	isWifiPanelVisible = true;
}
function toggleWifiPanel() {
	if (isContrastPanelVisible) {
		$(".overlay1").css("display", "none");
		isContrastPanelVisible = false;
	}
	if (isWifiPanelVisible) {
		$(".overlay4").css("display", "none");
		isWifiPanelVisible = false;
	} else {
		$(".overlay4").css("display", "inline");
		isWifiPanelVisible = true;
	}
}
function updateWifiOptions() {
	$("#wifiPanel").empty();
	let getOption = (id) => {
		let name = wifi_networks[id].SSID;
		let signal_strength = Number(wifi_networks[id].Quality);
		let no_password = Number(wifi_networks[id].Encryption);
		const connected = name == connected_to;
		var strong = 80;
		var medium = 60;
		let icon = "wifi";
		if (signal_strength >= strong) {
			icon += "_strong";
		} else if (signal_strength < strong && signal_strength >= medium) {
			icon += "_medium";
		} else if (signal_strength < medium) {
			icon += "_weak";
		}
		if (no_password == 1) {
			icon += "";
		} else {
			icon += "_pwd";
		}
		return `<div id="R_${id}" class="wifiOption ${connected ? 'connected' : ''}">
			<div class="wifiImage"><img src="/images/${icon + ".png"}" width="64" height="64"/></div>
			<div class="wifiName" style="font-size: ${heightInner * 0.05}px;">${name}</div>
			<div class="wifiDisconnect">${connected ? '<img src="/images/remove.png" width="54" height="54"/>' : ''}</div>
		</div>`;
	}
	let rows = "";
	for (let i = 0; i < wifi_networks.length; i++) {
		rows += getOption(i);
	}
	$("#wifiPanel").append(rows);
	$(".wifiOption").on("click", function () {
		console.log("click");
		var wifiIndex = Number($(this).attr("id").split("_")[1]);
		var selected = wifi_networks[wifiIndex];
		var no_pwd = Number(selected.Encryption);
		var pwd = "";
		if (no_pwd == 0) {
			passwordPopUp(selected.SSID);
		}
		else {
			socket.emit('connect_wifi', { SSID: selected.SSID, NO_PWD: no_pwd, PWD: pwd });
			console.log("" + pwd);
			manual_restart = true;
			$(".overlay2").append(`
						<div class="popup_box" >
						Restarting...		
						</div>
						`);
		}
		$(".overlay4").css("display", "none");
		isWifiPanelVisible = false;
	});
	$(".wifiDisconnect").on("click", function (e) {
		e.stopPropagation();
		let text = "Press OK to disconnect Wifi or Cancel.";
		if (confirm(text) == true) {
			socket.emit('disconnect_wifi');
			manual_restart = true;
			$(".overlay2").append(`
					<div class="popup_box" >
					Restarting...		
					</div>
					`);
			$(".overlay4").css("display", "none");
			isWifiPanelVisible = false;
		}
		else {
			console.log("Cancelled disconnect");
		}
	});
}
function takeSnapshot() {
	console.log("Take snapshot");
	socket.emit('take_snapshot');
}
function savePicture(data) {
	console.log(data);
	$(".overlay5").empty();
	$(".overlay5").prepend('<a id="downloadImg" href="' + data + '" download>Download</a>');
	$("#downloadImg")[0].click();
	$(".overlay5").empty();
}
function toggleColor() {
	colorIndex++;
	if (colorIndex > 2)
		colorIndex = 0;
	if (colorIndex == 0) {
		colorString = "";
	}
	else if (colorIndex == 1) {
		colorString = "grayscale(100%)"
	}
	else if (colorIndex == 2) {
		colorString = "invert(100%)"
	}
	updatePreview();
	localStorage.setItem('color_index', colorIndex);
}
function initHighlight() {
	$('.button').mousedown(function () {
		$(this).css('background-color', 'green');
	});
	$('.button').mouseup(function () {
		$(this).css('background-color', 'white');
	});
	$('.button').on('touchstart', function () {
		$(this).css('background-color', 'green');
	});
	$('.button').on('touchend', function () {
		$(this).css('background-color', 'white');
	});
}

function set_battery_level(pBatteryValue)
{
	if (100 >= pBatteryValue && pBatteryValue >= 70) {
		$(".batteryLevel").css("background-image", "url(\"/images/full_battery.png\")");
	} else if (70 > pBatteryValue && pBatteryValue >= 30) {
		$(".batteryLevel").css("background-image", "url(\"/images/medium_battery.png\")");
	} else if (30 > pBatteryValue && pBatteryValue >= 0) {
		$(".batteryLevel").css("background-image", "url(\"/images/low_battery.png\")");
	}

	button16.textContent = batteryLevel.toString() + "%";
}
function registerIncomingSocketEvents() {
	socket.on('my_pong', function () {
		// console.log("pong");
	});
	socket.on('check_for_update_response', function (msg) {
		var data = msg.data;
		console.log(data);
		popup_obj.clear_popup();
		toggleUpdate(data);
	});
	socket.on('finished_take_snapshot', function (msg) {
		console.log('picture_saved');
		var data = msg.data;
		console.log(data);
		savePicture(data);
	});
	socket.on('connect', function () {
		socket.emit('test_connect');
	});
	socket.on('network_connected_to', function (msg) {
		console.log(msg);
		var tmpString = msg.ssid;
		var tmpString2 = msg.ip_address;
		if (tmpString !== "") {
			console.log(tmpString + ", " + msg.ip_address);
			connected_to = tmpString;
			wifi_ip_address = tmpString2;
			$('#button25')[0].textContent = "Wifi IP: " + wifi_ip_address.split(' ')[1];
		}
	});
	socket.on('first_connect', function (msg) {
		console.log("first_connect: called");
		if (!first_run) {
			console.log("Second run...restart");
			if (manual_restart) {
				setTimeout(function () {
					window.location.reload();
					console.log("Restarting in 6 secs");
				}, 10000);
				manual_restart = false;
				console.log("Resolution changed OR Updating");
			} else {
				window.location.reload();
			}
		}
		if (first_run) {
			first_run = false;
			magnibotSettings = msg.magnibotSettings;
			unmounted_rotation = parseFloat(magnibotSettings.calibrated_rotation[0]);
			mounted_rotation = parseFloat(magnibotSettings.calibrated_rotation[1]);
			var tmpRotation = parseInt(magnibotSettings.mounted_rotation);
			if (tmpRotation == 0)
				stand_rotation = 270.0;
			else
				stand_rotation = 180.0;
			brightnessValue = parseFloat(magnibotSettings.calibrated_brightness);
			contrastValue = parseFloat(magnibotSettings.calibrated_contrast);
			videoFormatValue = parseInt(magnibotSettings.video_mode);
			videoResolutionValue = parseInt(magnibotSettings.video_resolution);
			var tmpOrientation = parseInt(msg.current_orientation);
			if (tmpOrientation !== 0)
				setOrientation(currentShaderIndex, tmpOrientation, false);
			else
				setOrientation(currentShaderIndex, 1, false);
			versionCode += magnibotSettings.version_code;
			button23.textContent = versionCode;
			if (videoFormatValue == 1) {
				onVideoSelection(button20);
			} else {
				onVideoSelection(button19);
			}
			if (videoResolutionValue == 1) {
				onVideoSelection(button22);
			} else {
				onVideoSelection(button21);
			}
			updateUI(magnibotSettings);
			updatePreview();
		}
	});
	socket.on('refresh_window', function () {
		window.location.reload();
	});
	socket.on('update_batterylevel', function (msg) {
		console.log("update_batterylevel: %d", msg.is_plugged);
		var level = parseInt(msg.data);
		var plugged = parseInt(msg.is_plugged, 10);
		var lastPlugged = is_charging;
		is_charging = plugged;
		if (plugged == 1) {
			$(".batteryLevel").css("background-image", "url(\"/images/full_battery_charging.png\")");
			button16.textContent = "";
		} else {


			batteryLevel = Math.ceil(level / 10) * 10;
			if( battery_timer == null)
			{
				set_battery_level(batteryLevel);

				battery_timer = setInterval(function(){
					if( is_charging == 0)
					{
						set_battery_level(batteryLevel);
					}

				
				}, 120000);
			}
			// Bypass timer on disconnect and last state was charging
			else if( lastPlugged == 1 &&  is_charging == 0)
			{
				set_battery_level(batteryLevel);
			}

		}

	});
	socket.on('update_wifi', function (msg) {
		var data = msg.data;
		wifi_networks = [];
		console.log(msg);
		for (let i = 0; i < data.length; i++) {
			const myArr = JSON.parse(data[i]);
			wifi_networks.push(myArr);
			console.log(data[i]);
		}
		updateWifiOptions();
	});
	socket.on('update_orientation', function (msg) {
		if (first_run)
			return;
		var t_orientation = msg.orientation;
		var t_color = msg.color;
		console.log("rotation: " + msg.rotation);
		unmounted_rotation = parseFloat(msg.rotation[0]);
		mounted_rotation = parseFloat(msg.rotation[1]);
		setOrientation(t_color, t_orientation);
	});
	socket.on('finished_orientation', function () {
		finishedOrientation();
	});

	socket.on('reconnecting_camera', function (msg) {
		var popup_message =msg.popup_message;
		console.log("popup_message: " + msg.popup_message);
		reconnectingCamera(popup_message);
	});
}
function finishedOrientation() {
	popup_obj.clear_popup();
}
function reconnectingCamera(popup_message="") {
	popup_obj.show_popup(popup_message);
}
function setOrientation(t_color, t_orientation, updateShader = true, show_popup = true) {
	console.log("update_orientation: " + t_orientation);
	if( show_popup )
		popup_obj.show_popup("Please Wait...");


	let current_orientation = Number(t_orientation);
	currentOrientation = current_orientation;
	var canvas = document.getElementById("renderTarget");
	var scaleAdj = 0.06;
	switch (current_orientation) {
		case 1: // Unmounted
			rotationValue = unmounted_rotation;
			scaleValue = 1.00 + scaleAdj;
			currentShaderIndex = parseInt(t_color);
			$(".toggle_camera").css("display", "none");
			break;
		case 2: case 4: // Mounted front and down
			$(".toggle_camera").css("display", "inline");
			// rotationValue = 270.0 - mounted_rotation;
			if (stand_rotation == 270.0) {
				rotationValue = stand_rotation - mounted_rotation;
				var scaleCanvasHeightToScreenWidth = window.innerWidth / window.innerHeight;
				var adjScale = scaleAdj * (window.innerHeight / window.innerWidth);
				scaleValue = scaleCanvasHeightToScreenWidth + adjScale;
			}
			else {
				rotationValue = stand_rotation - mounted_rotation;
				scaleValue = 1.00 + scaleAdj;
			}
			console.log("Window: %d, %d", window.innerWidth, window.innerHeight);
			console.log("scaleCanvasHeightToScreenWidth: %f", scaleCanvasHeightToScreenWidth);
			console.log("estimatedHeight: %d", (scaleCanvasHeightToScreenWidth * window.innerHeight));
			console.log("scaleAdjustment: %f", adjScale);
			console.log("scaleValue: %f", scaleValue);
			currentShaderIndex = parseInt(t_color);
			button26.setAttribute("display", "inline");
			break;
	}
	updatePreview();
	if (updateShader)
		updateOpenGLCanvas();
}
function onVideoSelection(video_button) {
	video_button.style.fontWeight = "bold";
	video_button.style.textDecoration = "underline";
	video_button.setAttribute("disabled", "disabled");
}
function log(e) {
	var logDiv = $('#log')[0];
	logDiv.replaceChildren();
	messageCounter++;
	logDiv.append($('<div/>').text('JS #' + messageCounter + ': ' + e).html());
}
async function loopFunction(cb, mode) {
	breakLoop = false;
	for (let i = 0; i < 50000; i++) {
		if (breakLoop)
			break;
		if (cb)
			cb(mode);
		await sleep(10);
	}
}
function stopLoop() {
	breakLoop = true;
}
function initButtonEvents(btnDown, btnUp) {
	button1.addEventListener(btnDown, function (e) {
		motor_controller.left();
	});
	button1.addEventListener(btnUp, function (e) {
		motor_controller.stopHorizontal();
	});
	button2.addEventListener(btnDown, function (e) {
		motor_controller.right();
	});
	button2.addEventListener(btnUp, function (e) {
		motor_controller.stopHorizontal();
	});
	button3.addEventListener(btnDown, function (e) {
		motor_controller.up();
	});
	button3.addEventListener(btnUp, function (e) {
		motor_controller.stopVertical();
	});
	button4.addEventListener(btnDown, function (e) {
		motor_controller.down();
	});
	button4.addEventListener(btnUp, function (e) {
		motor_controller.stopVertical();
	});
	button5.addEventListener(btnDown, function (e) {
		motor_controller.zoom_in();
	});
	button5.addEventListener(btnUp, function (e) {
		motor_controller.zoom_stop();
	});
	button6.addEventListener(btnDown, function (e) {
		motor_controller.zoom_out();
	});
	button6.addEventListener(btnUp, function (e) {
		motor_controller.zoom_stop();
	});
	button7.addEventListener(btnDown, function (e) {
	});
	button7.addEventListener(btnUp, function (e) {
		cycleShaders();
	});
	button8.addEventListener(btnDown, function (e) {
	});
	button8.addEventListener(btnUp, function (e) {
		toggleMenu();
	});
	button9.addEventListener(btnDown, function (e) {
	});
	button9.addEventListener(btnUp, function (e) {
		toggleContrastPanel();
	});
	button10.addEventListener(btnDown, function (e) {
	});
	button10.addEventListener(btnUp, function (e) {
		setBrightness(0);
	});
	button11.addEventListener(btnDown, function (e) {
		loopFunction(setBrightness, 1);
	});
	button11.addEventListener(btnUp, function (e) {
		stopLoop();
	});
	button12.addEventListener(btnDown, function (e) {
		loopFunction(setBrightness, 2);
	});
	button12.addEventListener(btnUp, function (e) {
		stopLoop();
	});
	button13.addEventListener(btnDown, function (e) {
	});
	button13.addEventListener(btnUp, function (e) {
		setContrast(0);
	});
	button14.addEventListener(btnDown, function (e) {
		loopFunction(setContrast, 1);
	});
	button14.addEventListener(btnUp, function (e) {
		stopLoop();
	});
	button15.addEventListener(btnDown, function (e) {
		loopFunction(setContrast, 2);
	});
	button15.addEventListener(btnUp, function (e) {
		stopLoop();
	});
	button17.addEventListener(btnDown, function (e) {
	});
	button17.addEventListener(btnUp, function (e) {
		motor_controller.toggle_camera();
		// setInterval(function(){
		// 	motor_controller.toggle_camera();
		// },10000);
	});
	button18.addEventListener(btnDown, function (e) {
	});
	button18.addEventListener(btnUp, function (e) {
		var camDropdown = document.getElementById('camera-dropdown');
		if (camDropdown.style.display == 'inline') {
			camDropdown.style.display = 'none';
		}
		else {
			var btn18 = document.getElementById('button18');
			var btn18Rect = btn18.getBoundingClientRect();
			var btn18Width = btn18Rect.left;
			console.log("btn18 width:", btn18Width);
			camDropdown.style.backgroundColor = 'white';
			camDropdown.style.position = 'absolute';
			camDropdown.style.display = 'inline';
			camDropdown.style.left = btn18Rect.left + 'px';
			camDropdown.style.width = btn18Rect.width + 'px';
			camDropdown.style.height = (btn18Rect.height * 3) + 'px';
		}
	});
	button19.addEventListener(btnDown, function (e) {
	});
	button19.addEventListener(btnUp, function (e) {
		videoFormatValue = 0;
		setToggleVideoOptions(videoFormatValue, videoResolutionValue);
	});
	button20.addEventListener(btnUp, function (e) {
		videoFormatValue = 1;
		setToggleVideoOptions(videoFormatValue, videoResolutionValue);
	});
	button21.addEventListener(btnUp, function (e) {
		videoResolutionValue = 0;
		setToggleVideoOptions(videoFormatValue, videoResolutionValue);
	});
	button22.addEventListener(btnUp, function (e) {
		videoResolutionValue = 1;
		setToggleVideoOptions(videoFormatValue, videoResolutionValue);
	});
	button24.addEventListener(btnUp, function (e) {
		checkForUpdate();
	});
	button26.addEventListener(btnDown, function (e) {
	});
	button26.addEventListener(btnUp, function (e) {
		toggleWifiPanel();
	});
	button27.addEventListener(btnDown, function (e) {
	});
	button27.addEventListener(btnUp, function (e) {
	});
	button28.addEventListener(btnDown, function (e) {
	});
	button28.addEventListener(btnUp, function (e) {
		takeSnapshot();
	});
}
function checkForUpdate() {
	socket.emit('check_for_update');
	$(".overlay1").css("display", "none");
	isContrastPanelVisible = false;
	manual_restart == true;
	popup_obj.show_popup("Checking for update...");
}
function setToggleVideoOptions(p_format, p_resolution) {
	socket.emit('toggle_h264', { format: p_format, resolution: p_resolution });
	$(".overlay1").css("display", "none");
	isContrastPanelVisible = false;
	manual_restart = true;
	popup_obj.show_popup("Restarting...");
}
function initPinch() {
	domElement.addEventListener('pinchstart', function (event) {
		startPinchEvent = event;
		direction = 0;
		lastScale = 1;
		noMovement = 0;
		startTime = new Date();
		log("pinstart");
	});
	domElement.addEventListener('pinch', function (event) {
		if (pinchActive == false) {
			pinchActive = true;
		}
		endTime = new Date();
		var elapsedTime = endTime - startTime; //in ms
		if (elapsedTime < 100)
			return;
		startTime = new Date();
		var scale = event.detail.global.scale;
		var transformString = "scale3d(" + scale + ", " + scale + ", 1)";
		var currentDelta = lastScale - scale;
		log("deltaScale: " + currentDelta);
		if (Math.abs(currentDelta) > 0.03) {
			noMovement = 0;
			if (currentDelta > 0) {
				if (direction == 2) {
					direction = 0;
				}
				if (direction == 0)
					motor_controller.zoom_out();
				direction = 1;
			}
			else if (currentDelta < 0) {
				if (direction == 1) {
					direction = 0;
				}
				if (direction == 0)
					motor_controller.zoom_in();
				direction = 2;
			}
		}
		else {
			noMovement++;
			if (direction != 0 && noMovement >= 3) {
				noMovement = 0;
				direction = 0;
				motor_controller.zoom_stop();
			}
		}
		lastScale = scale;
	});
	domElement.addEventListener('pinchend', function (event) {
		pinchActive = false;
		direction = 0;
		motor_controller.zoom_stop();
		var transformString = 'scale3d(1, 1, 1)';
	});
}
function drawLine(context, x1, y1, x2, y2) {
	context.beginPath();
	context.moveTo(x1, y1);
	context.lineTo(x2, y2);
	context.stroke();
}
function drawHead(context, x1, y1, x2, y2, filled) {
	var dx = x2 - x1;
	var dy = y2 - y1;
	context.beginPath();
	context.moveTo(x1 + 0.5 * dy, y1 - 0.5 * dx); // https://dirask.com/posts/jMqM0j
	context.lineTo(x1 - 0.5 * dy, y1 + 0.5 * dx); // https://dirask.com/posts/1GoW61
	context.lineTo(x2, y2);
	context.closePath();
	filled ? context.fill() : context.stroke();
}
function drawArrow(context, x1, y1, x2, y2, arrow, filled) {
	if (arrow == null) {
		arrow = 0.1;
	}
	var dx = x2 - x1;
	var dy = y2 - y1;
	var t = 1.0 - arrow;
	var middleX = dx * t + x1;
	var middleY = dy * t + y1;
	drawLine(context, x1, y1, middleX, middleY);
	drawHead(context, middleX, middleY, x2, y2, filled);
}
function drawFilledArrow(context, x1, y1, x2, y2, arrow, color, width) {
	context.lineWidth = width;
	context.fillStyle = color;
	context.strokeStyle = color;
	drawArrow(context, x1, y1, x2, y2, arrow, true);
}
let horizontalDirection = null;
let verticalDirection = null;
function initKeys() {
	document.addEventListener('keydown', function (event) {
		if (currentOrientation === 0) {
			return;
		}
		const overlayDiv = document.querySelector('.overlay6');
		if (overlayDiv && window.getComputedStyle(overlayDiv).display !== 'none') {
			console.log('The div with class name "overlay6" is visible.');
			return;
		}
		switch (event.key) {
			case 'ArrowLeft':
				if (horizontalDirection !== 'left') {
					horizontalDirection = 'left';
					motor_controller.right();
				}
				break;
			case 'ArrowRight':
				if (horizontalDirection !== 'right') {
					horizontalDirection = 'right';
					motor_controller.left();
				}
				break;
			case 'ArrowUp':
				if (verticalDirection !== 'up') {
					verticalDirection = 'up';
					motor_controller.up();
				}
				break;
			case 'ArrowDown':
				if (verticalDirection !== 'down') {
					verticalDirection = 'down';
					motor_controller.down();
				}
				break;
			case '-':
				motor_controller.zoom_out();
				break;
			case '=':
				motor_controller.zoom_in();
				break;
			case ',':
				handleRotation(-0.1);
				break;
			case '.':
				handleRotation(0.1);
				break;

			case 'c':
				cycleShaders();
				break;
			case ' ': // Toggle Menu
				button8.dispatchEvent(eventPointerUp);
				break;
			case 's': // Save Photo
				button28.dispatchEvent(eventPointerUp);
				break;
			case 'q': // Increase Brightness
				button11.dispatchEvent(eventPointerDown);
				break;
			case 'w': // Decrease Brightness
				button12.dispatchEvent(eventPointerDown);
				break;
			case 'z': // Increase Contrast
				button14.dispatchEvent(eventPointerDown);
				break;
			case 'x': // Decrease Contrast
				button15.dispatchEvent(eventPointerDown);
				break;
			case 'd':
				button10.dispatchEvent(eventPointerUp);
				button13.dispatchEvent(eventPointerUp);
				break;
		}
	}, true);
	document.addEventListener('keyup', function (event) {
		if (currentOrientation === 0) {
			return;
		}
		switch (event.key) {
			case 'ArrowLeft':
			case 'ArrowRight':
				horizontalDirection = null;
				motor_controller.stopHorizontal();
				break;
			case 'ArrowUp':
			case 'ArrowDown':
				verticalDirection = null;
				motor_controller.stopVertical();
				break;
			case '-':
			case '=':
				motor_controller.zoom_stop();
				break;
			case 'q': // Increase Brightness
				button11.dispatchEvent(eventPointerUp);
				break;
			case 'w': // Decrease Brightness
				button12.dispatchEvent(eventPointerUp);
				break;
			case 'z': // Increase Contrast
				button14.dispatchEvent(eventPointerUp);
				break;
			case 'x': // Decrease Contrast
				button15.dispatchEvent(eventPointerUp);
				break;

		}
	}, true);
}
function handleRotation(rotation) {
	if (currentOrientation === 1) {
		unmounted_rotation += rotation;
		unmounted_rotation = Math.max(unmounted_rotation, -5.0);
		unmounted_rotation = Math.min(unmounted_rotation, 5.0);
		rotationValue = unmounted_rotation;
	} else {
		mounted_rotation += rotation;
		mounted_rotation = Math.max(mounted_rotation, -5.0);
		mounted_rotation = Math.min(mounted_rotation, 5.0);
		rotationValue = stand_rotation - mounted_rotation;
	}
	socket.emit('set_rotation', { rotation_value: [unmounted_rotation, mounted_rotation] });
	updatePreview();
}
var startX = 0;
var startY = 0;
function initPan() {
	motor_controller.pan_setarea(MAX_FINGER_AREA, MIN_DISTANCE);
	domElement.addEventListener('panstart', function (event) {
		direction = 0;
		lastScale = 1;
		noMovement = 0;
		startTime = new Date();
		var x = event.detail.global.deltaX;
		var y = event.detail.global.deltaY
		lastDistance = [x, y];
		finger_area.style.visibility = "visible";
		finger_area.style.position = "absolute";
		finger_area.style.left = event.detail.global.srcEvent.clientX + 'px';
		finger_area.style.top = event.detail.global.srcEvent.clientY + 'px';
		startX = event.detail.global.srcEvent.clientX;
		startY = event.detail.global.srcEvent.clientY;
	});
	domElement.addEventListener('pan', function (event) {
		if (panActive == false) {
			panActive = true;
		}
		endTime = new Date();
		var elapsedTime = endTime - startTime; //in ms
		if (elapsedTime < 100)
			return;
		startTime = new Date();
		var x = event.detail.global.deltaX;
		var y = event.detail.global.deltaY
		var deltaX = lastDistance[0] - x;
		var deltaY = lastDistance[1] - y;
		var destX = event.detail.global.srcEvent.clientX - startX;
		var destY = event.detail.global.srcEvent.clientY - startY;
		var x1 = canvas.width / 2;
		var y1 = canvas.height / 2;
		var aspectRatio = canvas.width / canvas.height;
		var x2 = Math.max(0, Math.min(x1 + destX, canvas.width));
		var y2 = Math.max(0, Math.min(y1 + (destY / aspectRatio), canvas.height));
		context.clearRect(0, 0, canvas.width, canvas.height);
		var distanceY = y2 - y1;
		var distanceX = x2 - x1;
		var theta = Math.atan2(distanceY, distanceX); // range (-PI, PI)
		theta *= 180 / Math.PI; // radians to degrees (-180,180)
		if (theta < 0)
			theta = 360 + theta; // range [0, 360]
		var distanceFromOrigin = Math.sqrt((distanceX * distanceX) + (distanceY * distanceY));
		if (isNaN(distanceFromOrigin))
			distanceFromOrigin = 0;
		motor_controller.pan_start(distanceFromOrigin, theta);
		var cx = x1;
		var cy = y1;
		var radius = 50;
		var colors = ['red', 'blue', 'green', 'gold'];
		var color = 'red';
		var angle_threshold = 30;
		if (distanceFromOrigin > MIN_DISTANCE) {
			if (theta > 360 - angle_threshold || theta < 0 + angle_threshold)
				color = 'green';
			else if (theta > 90 - angle_threshold && theta < 90 + angle_threshold)
				color = 'green';
			else if (theta > 180 - angle_threshold && theta < 180 + angle_threshold)
				color = 'green';
			else if (theta > 270 - angle_threshold && theta < 270 + angle_threshold)
				color = 'green';
		}
		if (color === 'green') {
			var arrowWidth = MAX_FINGER_AREA * .02;
			drawFilledArrow(context, x1, y1, x2, y2, 0.35, color, arrowWidth);
			context.beginPath();
			context.arc(x1, y1, MIN_DISTANCE, 0, 2 * Math.PI);
			console.log("width: " + canvas.width + ", height: " + canvas.height + ", " + distanceX + ", " + distanceY);
			console.log("MIN_DISTANCE: " + MIN_DISTANCE + ", MAX_DISTANCE: " + MAX_FINGER_AREA + ", " + distanceFromOrigin);
			context.stroke();
			context.fill();
		}
		else {
			var arrowWidth = MAX_FINGER_AREA * .02;
			drawFilledArrow(context, x1, y1, x1, y1, 0.35, color, arrowWidth);
			context.beginPath();
			context.arc(x1, y1, MIN_DISTANCE, 0, 2 * Math.PI);
			console.log("width: " + canvas.width + ", height: " + canvas.height + ", " + distanceX + ", " + distanceY);
			console.log("MIN_DISTANCE: " + MIN_DISTANCE + ", MAX_DISTANCE: " + MAX_FINGER_AREA + ", " + distanceFromOrigin);
			context.stroke();
			context.fill();
		}
	});
	domElement.addEventListener('panend', function (event) {
		panActive = false;
		direction = 0;
		direction2 = 0;
		motor_controller.pan_end();
		finger_area.style.visibility = "hidden";
	});
}
function startBatteryThread() {
	socket.emit('test_connect');
}
function startMonitorThread() {
	setTimeout(function () {
		disconnect_monitor_obj.check_server_status();
	}, ping_interval);
}
function saveUISettings() {
	socket.emit('set_settings', magnibotSettings);
}
function initEventListeners() {
	var fragmentShaders = document.getElementsByName("fragmentShaders");
	fragmentShaders.forEach(function (checkbox, index) {
		checkbox.addEventListener("change", function () {
			if (checkbox.checked) {
				FRAGMENT_SHADERS[index].enabled = true;
				magnibotSettings.fragmentShaders[index] = 1;
				console.log("Checked: " + FRAGMENT_SHADERS[index].enabled);
			}
			else {
				FRAGMENT_SHADERS[index].enabled = false;
				magnibotSettings.fragmentShaders[index] = 0;
				console.log("Unchecked: " + FRAGMENT_SHADERS[index].enabled);
			}
			var checkedCount = 0;
			for (var j = 0; j < fragmentShaders.length; j++) {
				if (fragmentShaders[j].checked) {
					checkedCount++;
				}
			}
			if (checkedCount === 0) {
				this.checked = true;
				FRAGMENT_SHADERS[index].enabled = true;
				magnibotSettings.fragmentShaders[index] = 1;
			}
			saveUISettings();
		});
	});
	fragmentShaders = document.getElementsByName("frequency");
	fragmentShaders.forEach(function (radiobox, index) {
		radiobox.addEventListener("change", function () {
			console.log("" + index + ", " + radiobox.id);
			magnibotSettings.refreshRate = index;
			if (radiobox.checked) {
				socket.emit('my_event', { data: radiobox.id });
			}
			saveUISettings();
		});
	});
	fragmentShaders = document.getElementsByName("motorSpeed");
	fragmentShaders.forEach(function (radiobox, index) {
		radiobox.addEventListener("change", function () {
			console.log("" + index + ", " + radiobox.id);
			magnibotSettings.motorSpeed = index;
			saveUISettings();
		});
	});
	fragmentShaders = document.getElementsByName("mounted_rotation");
	fragmentShaders.forEach(function (radiobox, index) {
		radiobox.addEventListener("change", function () {
			console.log("" + index + ", " + radiobox.id);
			magnibotSettings.mounted_rotation = index;
			if (magnibotSettings.mounted_rotation == 0) {
				if (stand_rotation != 270.0) {
					stand_rotation = 270.0;
					setOrientation(currentShaderIndex, currentOrientation, false, false);
				}
			}
			else {
				if (stand_rotation != 180.0) {
					stand_rotation = 180.0;
					setOrientation(currentShaderIndex, currentOrientation, false, false);
				}
			}
			saveUISettings();
		});
	});
}
function updateUI(pSettings) {
	console.log("Update UI");
	var colorThemeOptions = document.getElementsByName('fragmentShaders');
	for (var i = 0; i < pSettings.fragmentShaders.length; i++) {
		if (pSettings.fragmentShaders[i] == 1) {
			colorThemeOptions[i].checked = true;
		}
		else {
			colorThemeOptions[i].checked = false;
		}
	}
	colorThemeOptions = document.getElementsByName('frequency');
	colorThemeOptions[pSettings.refreshRate].checked = true;
	socket.emit('my_event', { data: colorThemeOptions[pSettings.refreshRate].id });
	colorThemeOptions = document.getElementsByName('motorSpeed');
	colorThemeOptions[pSettings.motorSpeed].checked = true;

	try {
        colorThemeOptions = document.getElementsByName('mounted_rotation');
        colorThemeOptions[pSettings.mounted_rotation].checked = true;
    } catch (error) {
        console.error("Error setting mounted_rotation:", error);
		pSettings['mounted_rotation'] = 0;
		colorThemeOptions[pSettings.mounted_rotation].checked = true;
    }

}
var heightInner = window.innerHeight;
var widthInner = window.innerWidth;
var MAX_FINGER_AREA = heightInner * 0.85;
var MIN_DISTANCE = MAX_FINGER_AREA * .04;
finger_area.width = MAX_FINGER_AREA;// + 'px'
finger_area.height = MAX_FINGER_AREA;// + 'px'
canvas.width = MAX_FINGER_AREA;// + 'px'
canvas.height = MAX_FINGER_AREA;// + 'px'
window.oncontextmenu = function () { return false; }
initHighlight();
registerIncomingSocketEvents();
initButtonEvents('pointerdown', 'pointerup');
initPinch();
initPan();
initKeys();
initEventListeners();
startMonitorThread();
