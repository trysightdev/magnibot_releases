import subprocess
import re
import threading
from enum import Enum
import time

class USBVideoDeviceMonitor:
    class MODE(Enum):
        RELEASE = 1,
        DEBUG = 2
    def __init__(self, on_reconnect_callback=None, on_disconnect_callback=None, on_timeout_callback=None, mode=MODE.RELEASE):
        self.mode = mode
        self.monitoring_thread = None
        self.running = False
        self.on_reconnect_callback = on_reconnect_callback
        self.on_disconnect_callback = on_disconnect_callback
        self.on_timeout_callback = on_timeout_callback
        self.disconnect_timer = None
        

    @staticmethod
    def supports_required_resolutions(device_path):
        try:
            output = subprocess.check_output(['v4l2-ctl', '--list-formats-ext', '-d', device_path]).decode('utf-8')

            if 'MJPG' in output:
                print(f"Available resolutions for MJPG on {device_path}:")
                in_mjpg_block = False
                for line in output.splitlines():
                    if 'MJPG' in line:
                        in_mjpg_block = True
                    elif in_mjpg_block and 'Size: Discrete' in line:
                        resolution = line.split()[2]
                        print(resolution)
                    elif in_mjpg_block and 'Size: Stepwise' in line:
                        pass
                    elif in_mjpg_block and not line.startswith('\t'):
                        break

            return '1280x720' in output and '1920x1080' in output
        except subprocess.CalledProcessError:
            return False

    @staticmethod
    def update_ustreamer_service(device_path):
        service_file = '/etc/systemd/system/ustreamer.service'
        try:
            with open(service_file, 'r') as file:
                contents = file.read()

            if re.search(r'/dev/video[0-9]+', contents):
                # Replace the existing device path
                subprocess.call(['sudo', 'sed', '-i', f's|/dev/video[0-9]\\+|{device_path}|', service_file])
            else:
                # Insert the new device path
                subprocess.call(['sudo', 'sed', '-i', f'/ustreamer /s|$| --device={device_path}|', service_file])

            # Stop the ustreamer service before reloading the daemon
            subprocess.call(['sudo', 'systemctl', 'stop', 'ustreamer.service'])

            # Reload systemd daemon
            subprocess.call(['sudo', 'systemctl', 'daemon-reload'])

            # Restart the ustreamer service
            subprocess.call(['sudo', 'systemctl', 'restart', 'ustreamer.service'])
        except Exception as e:
            print(f"Error updating ustreamer service: {e}")

    def start_monitoring(self):
        if not self.running:
            self.running = True
            self.monitoring_thread = threading.Thread(target=self.monitor_usb_video_devices)
            self.monitoring_thread.start()

    def stop_monitoring(self):
        if self.running:
            self.running = False
            self.monitoring_thread.join()

    def monitor_usb_video_devices(self):
        process = subprocess.Popen(['udevadm', 'monitor', '--udev', '--subsystem-match=video4linux'], stdout=subprocess.PIPE)

        while self.running:
            line = process.stdout.readline()
            
            if not line:
                break
            line = line.decode('utf-8').strip()

            print(f'{line}')

            match = re.search(r'(add|remove)\s+/devices/(.*)/video4linux/(video\d+)', line)
            if match:
                device_action, device_path, device_name = match.groups()
                full_device_path = f"/dev/{device_name}"

                if device_action == 'add' and self.supports_required_resolutions(full_device_path):
                    print(f"Video device with required resolutions connected: {full_device_path}")
                    if self.disconnect_timer:
                        print(f'Reconnected timer canceled')
                        self.disconnect_timer.cancel()
                    if self.on_reconnect_callback:
                        self.on_reconnect_callback(full_device_path)
                elif device_action == 'remove':
                    print(f"Video device disconnected: {full_device_path}")
                    if self.on_disconnect_callback:
                        self.on_disconnect_callback(full_device_path)
                            # Start or restart the timer
                    if self.disconnect_timer:
                        self.disconnect_timer.cancel()
                    self.disconnect_timer = threading.Timer(5.0, self.on_timeout_callback)
                    self.disconnect_timer.start()

        process.terminate()

    def monitor_usb_video_devices_2(self):
        while self.running:
            process = subprocess.Popen(['v4l2-ctl', '--list-devices'], stdout=subprocess.PIPE)


    def check_and_connect_existing_devices(self):
        process = subprocess.Popen(['v4l2-ctl', '--list-devices'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = process.communicate()
        output = out.decode('utf-8')
                
    
        devices = re.findall(r'/dev/video\d+', output)

        for device in devices:
            try:
                if self.supports_required_resolutions(device):
                    print(f"Found existing video device with required resolutions: {device}")
                    self.update_ustreamer_service(device)
                    if self.on_reconnect_callback:
                        self.on_reconnect_callback(device)
                    break
            except Exception as e:
                print(f"Error with device {device}: {e}")
                # Continue to the next device


# # Example callback functions
# def on_reconnect(device_path):
#     print(f"Reconnected device: {device_path}")
#     USBVideoDeviceMonitor.update_ustreamer_service(device_path)
    

# def on_disconnect(device_path):
#     print(f"Disconnected device: {device_path}")
    
# def on_timeout():
#     print(f"Timeout occurred device: ")

# # Usage
# if __name__ == "__main__":
#     try:
#         video_monitor = USBVideoDeviceMonitor(on_reconnect_callback=on_reconnect, on_disconnect_callback=on_disconnect,on_timeout_callback=on_timeout)
#         video_monitor.start_monitoring()
#         input("Press Enter to stop monitoring...\n")
#         video_monitor.stop_monitoring()
#     except KeyboardInterrupt:
#         print("Stopped monitoring")