#!/bin/bash
FILE=~/WAP_INITIALIZED.txt
if [ -f "$FILE" ]; then
	echo "$FILE exists"
else
	ID_NUMBER=$[RANDOM%99999+10000]
	echo $ID_NUMBER > $FILE
	sudo rm -rf /etc/hostapd/hostapd.conf
	sudo touch /etc/hostapd/hostapd.conf
	echo "country_code=US" | sudo tee /etc/hostapd/hostapd.conf
	sudo sed -i -e '$a\' -e "interface=wlan0\nssid=magnibot_$ID_NUMBER\nhw_mode=g\nchannel=2\nmacaddr_acl=0\nauth_algs=1\nignore_broadcast_ssid=0\n" /etc/hostapd/hostapd.conf
	echo "Renamed SSID at /etc/hostapd/hostapd.conf"
	rm settings.json
	rm -rf ~/.vscode-server/
	sudo cp configs/etc_systemd_system/ustreamer.default.service /etc/systemd/system/ustreamer.service
	sudo cp configs/etc_systemd_system/magnibot.default.service /etc/systemd/system/magnibot.service
	sudo systemctl daemon-reload
	sudo reboot
fi
exit 0
#sudo sed -i "s/magnibot/magnibot_$ID_NUMBER/g" /etc/hostapd/hostapd.conf

