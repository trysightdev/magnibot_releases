#!/bin/bash
FILE=~/WAP_INITIALIZED.txt
if [ -f "$FILE" ]; then
	echo "$FILE exists"
else
	ID_NUMBER=$[RANDOM%99999+10000]
	echo $ID_NUMBER > $FILE
	sudo sed -i "s/^ssid.*/ssid=magnibot_$ID_NUMBER/g" /etc/hostapd/hostapd.conf
	rm settings.json
	rm -rf ~/.vscode-server/
	sudo cp configs/etc_systemd_system/ustreamer.default.service /etc/systemd/system/ustreamer.service
	sudo cp configs/etc_systemd_system/magnibot.default.service /etc/systemd/system/magnibot.service
	sudo systemctl daemon-reload
	sudo reboot
fi
exit 0

