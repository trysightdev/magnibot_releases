#!/bin/bash
function GetHDNum {
#       echo `sudo blkid | grep 'vfat' | awk '{print substr($1,1,9)}'`
        local TEMP_STR=`sudo lsblk | grep '/media/trysight/boot' | awk '{print substr($1, 7,3)}'`
        echo "$TEMP_STR"
}

DEV_PATH='/dev/'$(GetHDNum)
OUTPUT_PATH=img_$(date +'%Y_%m_%d_%H_%M_%S')
sudo dd bs=4M conv=fsync if=$DEV_PATH of=$OUTPUT_PATH.img status=progress
wget https://raw.githubusercontent.com/Drewsif/PiShrink/master/pishrink.sh
chmod +x pishrink.sh
sudo mv pishrink.sh /usr/local/sbin/pishrink
sudo pishrink $OUTPUT_PATH.img
tar -czf $OUTPUT_PATH.tar.gz $OUTPUT_PATH.img
