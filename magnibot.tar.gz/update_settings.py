import json

def update_version_code(default_settings_path, settings_path):
    try:
        # Read default settings from the provided file path
        with open(default_settings_path, 'r') as file:
            default_settings = json.load(file)
        default_version_code = default_settings.get('version_code')

        if default_version_code is None:
            print("version_code not found in the default settings file.")
            return

        # Read settings from the provided file path
        with open(settings_path, 'r') as file:
            settings = json.load(file)

        # Update version_code in settings
        settings['version_code'] = default_version_code

        # Check if settings.json has all keys from default settings
        default_keys = set(default_settings.keys())
        settings_keys = set(settings.keys())

        missing_keys = default_keys - settings_keys
        if missing_keys:
            print("Warning: settings.json is missing the following keys and will be copied from default settings:")
            for key in missing_keys:
                print(key)
                settings[key] = default_settings[key]

        # Write updated settings back to the file
        with open(settings_path, 'w') as file:
            json.dump(settings, file, indent=4)

        print("Version code updated successfully.")

    except FileNotFoundError as e:
        print(f"Error: {e}")
    except json.JSONDecodeError as e:
        print(f"Invalid JSON format: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage
default_settings_file = 'settings.default.json'
settings_file = 'settings.json'

update_version_code(default_settings_file, settings_file)
