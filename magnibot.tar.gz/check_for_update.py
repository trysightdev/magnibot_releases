import subprocess
import requests
import os.path
import JSONLib

class UpdaterLib(object):
    def __init__(self):
        self.debug = False
        self.internt_on = False
        self.commit_id = ""
        self.latest_tag = ""
        self.current_tag = ""
        print("UpdaterLib: Initialized")
    def internet_on(self):
        try:
            request = requests.get("https://github.com/", timeout=2)
            return True
        except (requests.ConnectionError, requests.Timeout) as exception:
            return False
        
    
    def get_current_tag(self):
        settings=JSONLib.JSONLib()
        return settings.get_version_code()
    def get_latest_tag(self):
        if self.latest_tag=="":
            subprocess.Popen(['rm','latest.txt'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            process = subprocess.Popen(['wget','https://trysight.com/downloads/magnibot/latest.txt'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = process.communicate()
            out = out.decode("utf-8")
            err = err.decode("utf-8")
            print("", out, err)
            f = open('latest.txt', 'r')
            self.latest_tag=f.read().strip()
            print(f.read())
            f.close()
            subprocess.Popen(['rm','latest.txt'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return self.latest_tag
    def check_for_update(self):
        print("current: ",self.get_current_tag())
        print("latest: ",self.get_latest_tag())
        if self.get_current_tag()==self.get_latest_tag():
            return True
        else:
            return False

print("hello")

# tmpUpdater=UpdaterLib()

# if( tmpUpdater.internet_on() ):
#     print("",tmpUpdater.get_commit_id())
#     print("",tmpUpdater.get_latest_tag())
#     print("",tmpUpdater.get_current_tag())
#     print("",tmpUpdater.check_for_update())
# else:
#     print("",tmpUpdater.get_current_tag())
#     print("No internet")

