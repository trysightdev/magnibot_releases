#!/usr/bin/env python3
import sys
import time
import RPi.GPIO as GPIO
from ArduinoReader import ArduinoReader

class StopMotorInterrupt(Exception):
    """ Stop the motor """
    pass

class BYJMotor(object):
    def __init__(self, name="BYJmotor_location", motor_type="28BYJ"):
        self.name = name
        self.motor_type = motor_type
        GPIO.setmode(GPIO.BOARD)
        GPIO.setwarnings(False)
        self.stop_motor = False
        self.wait = 0.001
        self.last_direction = False 
        self.first_run = True
        self.command_counter = 0
        self.step_counter = 0
        self.step_range = [0,0]
        self.disable_range = True
        self.adjustment_steps = 8

    def motor_stop(self):
        self.stop_motor = True
    def reset_steps(self):
        self.step_counter = 0
    
    def get_steps(self):
        return self.step_counter
    def set_steps(self, pSteps):
        self.step_counter = pSteps

    def get_adjustment_steps(self):
        return self.adjustment_steps
    def set_adjustment_steps(self, pSteps):
        self.adjustment_steps = pSteps

    def set_steps_range(self, pMin,pMax):
        if pMin == 0 and pMax == 0:
            self.disable_range = True
        else:
            self.disable_range = False   
        print(f"self.disable_range {self.disable_range}")
        self.step_range = [pMin, pMax]
        
    def get_steps_range(self):
        return self.step_range       

    def motor_speed(self, wait = .001):
        self.wait = wait
    def fire_pins(self,gpiopins,step_sequence, ccwise, delay, ignore_range = True, ignore_steps = False):
        if not ignore_range and not self.disable_range:
            if ccwise:
                if (self.step_counter - 1) < self.step_range[0] :
                    print(f"Outside Range: {self.step_counter} {self.step_range}")
                    self.stop_motor = True
            else:
                if (self.step_counter + 1) > self.step_range[1]:
                    print(f"Outside Range: {self.step_counter} {self.step_range}")
                    self.stop_motor = True
                    
            
        
        for idx,pin_list in enumerate(step_sequence):
            for pin in gpiopins:
                if self.stop_motor:
                    raise StopMotorInterrupt
                else:
                    if pin in pin_list:
                        GPIO.output(pin, True)
                    else:
                        GPIO.output(pin, False)
            time.sleep(delay)
        # Increment/decrement counter on every step
        if not ignore_steps:
            if ccwise:
                self.step_counter=self.step_counter-1
            else:
                self.step_counter=self.step_counter+1
        # print(f"name: {self.name} steps: {self.step_counter} speed: {delay}")
    def motor_run(self, gpiopins, wait=.001, ccwise=False,
                  verbose=False, steptype="half", initdelay=.001):
        try:
            self.wait = wait
            self.stop_motor = False
            for pin in gpiopins:
                GPIO.setup(pin, GPIO.OUT)
                GPIO.output(pin, False)
            time.sleep(initdelay)

            # select step based on user input
            # Each step_sequence is a list containing GPIO pins that should be set to High
            if steptype == "half":  # half stepping.
                step_sequence = list(range(0, 8))
                step_sequence[0] = [gpiopins[0]]
                step_sequence[1] = [gpiopins[0], gpiopins[1]]
                step_sequence[2] = [gpiopins[1]]
                step_sequence[3] = [gpiopins[1], gpiopins[2]]
                step_sequence[4] = [gpiopins[2]]
                step_sequence[5] = [gpiopins[2], gpiopins[3]]
                step_sequence[6] = [gpiopins[3]]
                step_sequence[7] = [gpiopins[3], gpiopins[0]]
            elif steptype == "full":  # full stepping.
                step_sequence = list(range(0, 4))
                step_sequence[0] = [gpiopins[0], gpiopins[1]]
                step_sequence[1] = [gpiopins[1], gpiopins[2]]
                step_sequence[2] = [gpiopins[2], gpiopins[3]]
                step_sequence[3] = [gpiopins[0], gpiopins[3]]
            elif steptype == "wave":  # wave driving
                step_sequence = list(range(0, 4))
                step_sequence[0] = [gpiopins[0]]
                step_sequence[1] = [gpiopins[1]]
                step_sequence[2] = [gpiopins[2]]
                step_sequence[3] = [gpiopins[3]]
            else:
                #print("Error: unknown step type ; half, full or wave")
                quit()

            #  To run motor in reverse we flip the sequence order.
            if ccwise:
                step_sequence.reverse()

            def display_degree():
                """ display the degree value at end of run if verbose"""
                if self.motor_type == "28BYJ":
                    degree = 1.422222
                    print("Size of turn in degrees = {}".format(round(steps/degree, 2)))
                elif self.motor_type == "Nema":
                    degree = 7.2
                    print("Size of turn in degrees = {}".format(round(steps*degree, 2)))
                else:
                    # Unknown Motor type
                    print("Size of turn in degrees = N/A Motor: {}".format(self.motor_type))

            def print_status(enabled_pins):
                """   Print status of pins."""
                if verbose:
                    print("Next Step: Step sequence remaining : {} ".format(steps_remaining))
                    for pin_print in gpiopins:
                        if pin_print in enabled_pins:
                            print("GPIO pin on {}".format(pin_print))
                        else:
                            print("GPIO pin off {}".format(pin_print))

            # First run, run adjustment
            if self.first_run:
                self.last_direction = not ccwise
                self.first_run = False
            
            
            # Motors need a certain amount of rotations when spinning in the opposite direction.
            # When changing directions, spin the motors nth amount of times at the fastest speed before using the calculated speed                            
            if self.last_direction != ccwise:
                i = 0
                while i < self.adjustment_steps:
                    self.fire_pins(gpiopins,step_sequence,ccwise,.003, False, True)
                    i += 1
                    # print(f"adjustment: {i} name: {self.name}")

            while True:
                self.fire_pins(gpiopins,step_sequence,ccwise,self.wait, False)

        except KeyboardInterrupt:
            print("User Keyboard Interrupt : RpiMotorLib: ")
        except StopMotorInterrupt:
            self.last_direction = ccwise
#            pass
#            print("Stop Motor Interrupt : RpiMotorLib: ")
        except Exception as motor_error:
            print(sys.exc_info()[0])
            print(motor_error)
            print("RpiMotorLib  : Unexpected error:")
        else:
            # print report status if everything went well
            if verbose:
                print("\nRpiMotorLib, Motor Run finished, Details:.\n")
                print("Motor type = {}".format(self.motor_type))
                print("Initial delay = {}".format(initdelay))
                print("GPIO pins = {}".format(gpiopins))
                print("Wait time = {}".format(wait))
                print("Number of step sequences = {}".format(steps))
                print("Size of step sequence = {}".format(len(step_sequence)))
                print("Number of steps = {}".format(steps*len(step_sequence)))
                display_degree()
                print("Counter clockwise = {}".format(ccwise))
                print("Verbose  = {}".format(verbose))
                print("Steptype = {}".format(steptype))
        finally:
            # switch off pins at end
            for pin in gpiopins:
                GPIO.output(pin, False)




    def motor_test(self, gpiopins, wait=.001, ccwise=False,
                  verbose=False, steptype="half", initdelay=.001, steps=512):
        """motor_run,  moves stepper motor based on 7 inputs

         (1) GPIOPins, type=list of ints 4 long, help="list of
         4 GPIO pins to connect to motor controller
         These are the four GPIO pins we will
         use to drive the stepper motor, in the order
         they are plugged into the controller board. So,
         GPIO 18 is plugged into Pin 1 on the stepper motor.
         (2) wait, type=float, default=0.001, help=Time to wait
         (in seconds) between steps.
         (3) steps, type=int, default=512, help=Number of steps sequence's
         to execute. Default is one revolution , 512 (for a 28BYJ-48)
         (4) counterclockwise, type=bool default=False
         help="Turn stepper counterclockwise"
         (5) verbose, type=bool  type=bool default=False
         help="Write pin actions",
         (6) steptype, type=string , default=half help= type of drive to
         step motor 3 options full step half step or wave drive
         where full = fullstep , half = half step , wave = wave drive.
         (7) initdelay, type=float, default=1mS, help= Intial delay after
         GPIO pins initialized but before motor is moved.

        """
        try:
            self.wait = wait
            self.stop_motor = False
            for pin in gpiopins:
                GPIO.setup(pin, GPIO.OUT)
                GPIO.output(pin, False)
            time.sleep(initdelay)

            # select step based on user input
            # Each step_sequence is a list containing GPIO pins that should be set to High
            if steptype == "half":  # half stepping.
                step_sequence = list(range(0, 8))
                step_sequence[0] = [gpiopins[0]]
                step_sequence[1] = [gpiopins[0], gpiopins[1]]
                step_sequence[2] = [gpiopins[1]]
                step_sequence[3] = [gpiopins[1], gpiopins[2]]
                step_sequence[4] = [gpiopins[2]]
                step_sequence[5] = [gpiopins[2], gpiopins[3]]
                step_sequence[6] = [gpiopins[3]]
                step_sequence[7] = [gpiopins[3], gpiopins[0]]
            elif steptype == "full":  # full stepping.
                step_sequence = list(range(0, 4))
                step_sequence[0] = [gpiopins[0], gpiopins[1]]
                step_sequence[1] = [gpiopins[1], gpiopins[2]]
                step_sequence[2] = [gpiopins[2], gpiopins[3]]
                step_sequence[3] = [gpiopins[0], gpiopins[3]]
            elif steptype == "wave":  # wave driving
                step_sequence = list(range(0, 4))
                step_sequence[0] = [gpiopins[0]]
                step_sequence[1] = [gpiopins[1]]
                step_sequence[2] = [gpiopins[2]]
                step_sequence[3] = [gpiopins[3]]
            else:
                #print("Error: unknown step type ; half, full or wave")
                quit()

            #  To run motor in reverse we flip the sequence order.
            if ccwise:
                step_sequence.reverse()

            def display_degree():
                """ display the degree value at end of run if verbose"""
                if self.motor_type == "28BYJ":
                    degree = 1.422222
                    print("Size of turn in degrees = {}".format(round(steps/degree, 2)))
                elif self.motor_type == "Nema":
                    degree = 7.2
                    print("Size of turn in degrees = {}".format(round(steps*degree, 2)))
                else:
                    # Unknown Motor type
                    print("Size of turn in degrees = N/A Motor: {}".format(self.motor_type))

            def print_status(enabled_pins):
                """   Print status of pins."""
                if verbose:
                    print("Next Step: Step sequence remaining : {} ".format(steps_remaining))
                    for pin_print in gpiopins:
                        if pin_print in enabled_pins:
                            print("GPIO pin on {}".format(pin_print))
                        else:
                            print("GPIO pin off {}".format(pin_print))

            # First run, run adjustment
            if self.first_run:
                self.last_direction = not ccwise
                self.first_run = False

            if self.last_direction != ccwise:
                i = 0
                while i < self.adjustment_steps:
                    self.fire_pins(gpiopins,step_sequence,ccwise,.003, ignore_steps=True)
                    i += 1
                    
            
            steps_remaining = int(steps)

            while True:
                if steps_remaining == 0:
                    break
                self.fire_pins(gpiopins,step_sequence,ccwise,self.wait)
                steps_remaining -= 1
                # if self.name == "HorizontalMotor":
                #     print(f"steps_remaining {steps_remaining}")

        except KeyboardInterrupt:
            print("User Keyboard Interrupt : RpiMotorLib: ")
        except StopMotorInterrupt:
            self.last_direction = ccwise
#            pass
#            print("Stop Motor Interrupt : RpiMotorLib: ")
        except Exception as motor_error:
            print(sys.exc_info()[0])
            print(motor_error)
            print("RpiMotorLib  : Unexpected error:")
        else:
            # print report status if everything went well
            if verbose:
                print("\nRpiMotorLib, Motor Run finished, Details:.\n")
                print("Motor type = {}".format(self.motor_type))
                print("Initial delay = {}".format(initdelay))
                print("GPIO pins = {}".format(gpiopins))
                print("Wait time = {}".format(wait))
                print("Number of step sequences = {}".format(steps))
                print("Size of step sequence = {}".format(len(step_sequence)))
                print("Number of steps = {}".format(steps*len(step_sequence)))
                display_degree()
                print("Counter clockwise = {}".format(ccwise))
                print("Verbose  = {}".format(verbose))
                print("Steptype = {}".format(steptype))
        finally:
            # switch off pins at end
            for pin in gpiopins:
                GPIO.output(pin, False)

def degree_calc(steps, steptype):
    """ calculate and returns size of turn in degree
    , passed number of steps and steptype"""
    degree_value = {'Full': 1.8,
                    'Half': 0.9,
                    '1/4': .45,
                    '1/8': .225,
                    '1/16': 0.1125,
                    '1/32': 0.05625,
                    '1/64': 0.028125,
                    '1/128': 0.0140625}
    degree_value = (steps*degree_value[steptype])
    return degree_value


def importtest(text):
    """ testing import """
    # #print(text)
    text = " "

# ===================== MAIN ===============================


if __name__ == '__main__':
    importtest("main")
else:
    importtest("Imported {}".format(__name__))


# ===================== END ===============================
