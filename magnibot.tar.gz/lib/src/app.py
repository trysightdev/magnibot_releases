from subprocess import Popen, PIPE
import time
# Run "cat", which is a simple Linux program that prints it's input.
process = Popen(['./zoom.bin'], stdin=PIPE, stdout=PIPE)
process.stdin.write(b'i\n')
process.stdin.flush()
time.sleep(3)

process.stdin.write(b'o\n')
process.stdin.flush()
time.sleep(3)

# "cat" will exit when you close stdin.  (Not all programs do this!)
process.stdin.close()
print('Waiting for cat to exit')
process.wait()
print('cat finished with return code %d' % process.returncode)       
