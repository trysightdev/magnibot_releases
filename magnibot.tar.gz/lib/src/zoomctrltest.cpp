
///
/// g++ zoomctrltest.cpp -o zoomctrltest -lzoomctrl
///

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "zoomctrl.h"

#define _DEBUG
#ifdef _DEBUG
	#include <iostream>
	#include <unistd.h>
#endif


using namespace std;
int gLastZoom = -1;
int zoomCounter = 0;
int zoomIn()
{
	int cmd;
	sscanf("1","%d", &cmd);
	
	unsigned char pdat[5] = {0x07,0x02,0x00,0x00,0x00};
	pdat[1] = (unsigned char)(cmd&0xff);    
	int result = zoomctrl_dsp_write_buf(0xc7df, pdat, 5);
	
//	printf("send command %d\n", pdat[1]);
	return result;
}
int zoomOut()
{
	int cmd;
	sscanf("2","%d", &cmd);
	
	unsigned char pdat[5] = {0x07,0x02,0x00,0x00,0x00};
	pdat[1] = (unsigned char)(cmd&0xff);    
	int result = zoomctrl_dsp_write_buf(0xc7df, pdat, 5);
//	printf("send command %d\n", pdat[1]);
	return result;
}
int zoomStop(){
		
	int cmd;
	sscanf("5","%d", &cmd);
	
	unsigned char pdat[5] = {0x07,0x02,0x00,0x00,0x00};
	pdat[1] = (unsigned char)(cmd&0xff);    
	int result = zoomctrl_dsp_write_buf(0xc7df, pdat, 5);
	unsigned char val = 0;
	zoomctrl_dsp_read_buf(0xc7df+8, &val, 1);
//	printf("zoom_value: %d\n", val);

	return val;
}
int zoomOpen(int devID)
{
	char dev[256];
	char append[2];
        strcpy(dev,  "/dev/video");
	sprintf(append, "%d", devID);
	strcat(dev, append);
	const char* device = dev;
	return zoomctrl_open(device);

}
void zoomClose()
{
	zoomctrl_close();
}


int zoomGet(){
		
	unsigned char val = 0;
	zoomctrl_dsp_read_buf(0xc7df+8, &val, 1);
	return val;
}


void zoomInfinity()
{

	// unsigned char pdat[5] = {0x07,0x07,0x00,0x00,0x00};
	unsigned char pdat[5] = {0x07,0x0c,0x00,0x00,0x00};
	
	int result = zoomctrl_dsp_write_buf(0xc7df, pdat, 5);
	// printf("result: %d", result);
}

void zoomThirtyCm()
{

	// unsigned char pdat[5] = {0x07,0x06,0x00,0x00,0x00};
	unsigned char pdat[5] = {0x07,0x0b,0x00,0x00,0x00};
	
	int result = zoomctrl_dsp_write_buf(0xc7df, pdat, 5);
	// printf("result: %d", result);
	
}

// If mode == 1, 50hz else 60hz
void setRefreshRate(int pMode){
	if( pMode == 1)
		system("v4l2-ctl --device=/dev/video0 --set-ctrl=power_line_frequency=1");
	else
		system("v4l2-ctl --device=/dev/video0 --set-ctrl=power_line_frequency=2");
}

#ifdef _DEBUG
int main(int argc, char *argv[])
{
	zoomOpen(0);
	while(true)
	{
		char tChar;
		cin.get(tChar);
		if( tChar == 'q' )
			break;
		else if( tChar == 'i' )
		{
			zoomIn();
		}
		else if( tChar == 'o' )
		{
			zoomOut();
		}
		else if( tChar == 't' )
		{
			zoomThirtyCm();
			int result = -1;
			zoomCounter = 0;
			
			while(true)
			{
				result = zoomGet();
				// cout <<  result << endl;
				// cout << "zoomCounter: " << zoomCounter << endl;
				if( result == gLastZoom )
					zoomCounter++;
				else
					zoomCounter = 0;
				
				if( zoomCounter > 100)
					break;
					
				gLastZoom = result;
				sleep(0.1);
				
			}

			// sleep(2);
			cout << "finished" << endl;
		}
		else if( tChar == 'f' )
		{
			zoomInfinity();
			int result = -1;
			zoomCounter = 0;
			
			while(true)
			{
				result = zoomGet();
				// cout << result << endl;
				// cout << "zoomCounter: " << zoomCounter << endl;
				if( result == gLastZoom )
					zoomCounter++;
				else
					zoomCounter = 0;

				if( zoomCounter > 100)
					break;

				gLastZoom = result;

				sleep(0.1);
				
			}
		
			// sleep(2);
			

			cout << "finished" << endl;
		}
		else if( tChar == 's' )
		{
			int result = zoomStop();
			cout << "zoom: " << result << endl;
		}
		else if( tChar == 'g' )
		{
			int result = zoomGet();
			cout << "zoom: " << result << endl;
		}
		else if( tChar == 'z' )
		{
			setRefreshRate(1);
		}
		else if( tChar == 'x' )
		{
			setRefreshRate(0);
		}
	}

	return 0;
}
#endif
