
///
/// g++ zoomctrltest.cpp -o zoomctrltest -lzoomctrl
///

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "zoomctrl.h"

#define _DEBUG
#ifdef _DEBUG
	#include <iostream>
	#include <unistd.h>
#endif
using namespace std;
int zoomIn()
{
	int cmd;
	sscanf("1","%d", &cmd);
	
	unsigned char pdat[5] = {0x07,0x02,0x00,0x00,0x00};
	pdat[1] = (unsigned char)(cmd&0xff);    
	int result = zoomctrl_dsp_write_buf(0xc7df, pdat, 5);
	
//	printf("send command %d\n", pdat[1]);
	return result;
}
int zoomOut()
{
	int cmd;
	sscanf("2","%d", &cmd);
	
	unsigned char pdat[5] = {0x07,0x02,0x00,0x00,0x00};
	pdat[1] = (unsigned char)(cmd&0xff);    
	int result = zoomctrl_dsp_write_buf(0xc7df, pdat, 5);
//	printf("send command %d\n", pdat[1]);
	return result;
}
int zoomStop(){
		
	int cmd;
	sscanf("5","%d", &cmd);
	
	unsigned char pdat[5] = {0x07,0x02,0x00,0x00,0x00};
	pdat[1] = (unsigned char)(cmd&0xff);    
	int result = zoomctrl_dsp_write_buf(0xc7df, pdat, 5);
	unsigned char val = 0;
	zoomctrl_dsp_read_buf(0xc7df+8, &val, 1);
//	printf("zoom_value: %d\n", val);

	return val;
}
int zoomOpen(int devID)
{
	char dev[256];
	char append[2];
        strcpy(dev,  "/dev/video");
	sprintf(append, "%d", devID);
	strcat(dev, append);
	const char* device = dev;
	return zoomctrl_open(device);

}
void zoomClose()
{
	zoomctrl_close();
}

#ifdef _DEBUG
int main(int argc, char *argv[])
{
//	if (argc < 2) {
//		printf("argument error\n");
//		return -1;
//	}

//	zoomctrl_open("/dev/video0");
//	
//	int cmd;
//	sscanf(argv[1],"%d", &cmd);
//	
//	unsigned char pdat[5] = {0x07,0x02,0x00,0x00,0x00};
//	pdat[1] = (unsigned char)(cmd&0xff);    
//	zoomctrl_dsp_write_buf(0xc7df, pdat, 5);
//	
//	zoomctrl_close();
//		
//	printf("send command %d\n", pdat[1]);
//	zoomIn();
//	zoomOut();
	zoomOpen(0);
	while(true)
	{
		char tChar;
		cin.get(tChar);
		if( tChar == 'q' )
			break;
		else if( tChar == 'i' )
		{
			zoomIn();
		}
		else if( tChar == 'o' )
		{
			zoomOut();
		}
		else if( tChar == 's' )
		{
			int result = zoomStop();
			cout << "zoom: " << result << endl;
		}
		
	}

	return 0;
}
#endif
