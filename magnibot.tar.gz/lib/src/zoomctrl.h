

#ifndef __ZOOMCTRL_H__
#define __ZOOMCTRL_H__
	
int zoomctrl_open(const char* devName);
void zoomctrl_close();
int zoomctrl_dsp_read_buf(unsigned short adr, unsigned char *pval, int vallen);
int zoomctrl_dsp_write_buf(unsigned short adr, unsigned char *pval, int vallen);

 
extern "C" int zoomIn();
extern "C" int zoomOut();
extern "C" int zoomStop();
extern "C" int zoomOpen(int devID);
extern "C" void zoomClose();

#endif	// __ZOOMCTRL_H__
