#!/bin/bash

{ # Prevent the script from executing until the client downloads the full file.

# Exit on first error.
set -e

# Echo commands to stdout.
set -x
sudo systemctl stop magnibot.service

#  Go to tmp folder
cd ~/tmp

# Install Magnibot
python3 -m venv venv
. venv/bin/activate

# pip 20.3.4 from /home/pi/magnibot/venv/lib/python3.9/site-packages/pip (python 3.9)
pip install pip==20.3.4
pip install -r requirements.txt
cp config_default.py config.py
cp settings.default.json settings.json
sudo cp configs/etc_systemd_system/ustreamer.default.service /etc/systemd/system/ustreamer.service
cp -rf ~/magnibot/settings.json ~/tmp/settings.json
python ~/tmp/update_settings.py

# Check if /boot is set to mount as read-only in /etc/fstab
if grep "/boot" "/etc/fstab" | grep -q "ro"; then
    echo "/boot is set to mount with read-write permissions in /etc/fstab."

else
    echo "/boot is not set to mount with read-write permissions in /etc/fstab."
    sudo sed -i '/\/boot/ s/defaults/defaults,ro/' "/etc/fstab"
fi

# Check if the specific ifconfig command is already in /etc/rc.local
if ! grep -q "ifconfig eth0 169.254.4.1" /etc/rc.local; then
    # It's not found, so insert it before the 'exit 0' line
    sudo sed -i '/^exit 0/i\ifconfig eth0 169.254.4.1' /etc/rc.local
else 
    echo 'eth0 static already set to 169.254.4.1'
fi

cd ~/

rm -rf ~/magnibot
mv ~/tmp/ ~/magnibot/
#cp -rf tmp magnibot

sudo leonardoUploader.bin /dev/ttyACM0 ~/magnibot/magnibotpositionreader/MagnibotPositionReader.ino.hex
sudo systemctl daemon-reload

} # Prevent the script from executing until the client downloads the full file.


