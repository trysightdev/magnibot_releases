#!/bin/bash

{ # Prevent the script from executing until the client downloads the full file.

# Exit on first error.
set -e

# Echo commands to stdout.
set -x
sudo systemctl stop magnibot.service

#  Go to tmp folder
cd ~/tmp

# Install Magnibot
python3 -m venv venv
. venv/bin/activate

# pip 20.3.4 from /home/pi/magnibot/venv/lib/python3.9/site-packages/pip (python 3.9)
pip install pip==20.3.4
pip install -r requirements.txt
cp config_default.py config.py
cp settings.default.json settings.json
sudo cp configs/etc_systemd_system/ustreamer.default.service /etc/systemd/system/ustreamer.service



cd ~/

rm -rf ~/magnibot
mv ~/tmp/ ~/magnibot/
sudo leonardoUploader.bin /dev/ttyACM0 ~/magnibot/magnibotpositionreader/MagnibotPositionReader.ino.hex
sudo systemctl daemon-reload

} # Prevent the script from executing until the client downloads the full file.


