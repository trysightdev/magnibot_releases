import serial
import serial.tools.list_ports
import queue
import threading
import time
import json

class ArduinoReader:
    def __init__(self):
        self.started = False
    def startService(self):
        arduino_port = None
        while True:
            arduino_port = self.get_arduino_port()

            if arduino_port!=None:
                break
            
            print('No port found')
            time.sleep(5)
        
        self.ser = serial.Serial(arduino_port, 9600)
        self.value = None
        self.queue = queue.Queue()
        self.thread = threading.Thread(target=self.read_from_arduino)
        self.thread.start()

        
    def read_from_arduino(self):
        while True:
            # read from Arduino
            try:
                tmp_value = self.ser.readline().strip()
                self.ser.flush()
                # Parse the JSON string
                data = json.loads(tmp_value.decode('utf-8'))
                
                data['result'] = 1

                self.value = data
            except TypeError as e:
                print("An exception occurred: ", e)
                data = {
                    'output': 0,
                    'x': 0,
                    'y': 0,
                    'z': 0,
                    'result': 0
                }
                self.value = data
                self.queue.put(self.value)
                self.ser.close()
                break
            except serial.SerialException as e:
                print("An exception occurred: ", e)
                data = {
                    'output': 0,
                    'x': 0,
                    'y': 0,
                    'z': 0,
                    'result': 0
                }
                self.value = data
                self.queue.put(self.value)
                self.ser.close()
                break
            except ValueError:
                pass
            
                
            # put value into queue
            self.queue.put(self.value)
            
    def get_value(self):
        return self.queue.get()
    
    
    def get_arduino_port(self):
        ports = serial.tools.list_ports.comports()
        for port in ports:
            if 'Arduino' in port.description:
                return port.device
        return None
