import serial
import serial.tools.list_ports
import queue
import threading
import time

class ArduinoReader:
    def __init__(self):
        arduino_port = None
        while True:
            arduino_port = self.get_arduino_port()

            if arduino_port!=None:
                break
            
            print('No port found')
            time.sleep(5)
        
        self.ser = serial.Serial(arduino_port, 9600)
        self.value = 0
        self.queue = queue.Queue()
        self.thread = threading.Thread(target=self.read_from_arduino)
        self.thread.start()
        
    def read_from_arduino(self):
        while True:
            # read from Arduino
            try:
                tmp_value = self.ser.readline().strip()
                # print("",tmp_value.decode('utf-8'))
                self.value = int(tmp_value)
            except serial.SerialException as e:
                print("An exception occurred: ", e)
                self.value = 8
                self.queue.put(self.value)
                self.ser.close()
                break
            except ValueError:
                pass
            
                
            # put value into queue
            self.queue.put(self.value)
            
    def get_value(self):
        return self.queue.get()
    
    
    def get_arduino_port(self):
        ports = serial.tools.list_ports.comports()
        for port in ports:
            if 'Arduino' in port.description:
                return port.device
        return None