#!/bin/bash
rm -rf build/
mkdir build
MAGNIBOT_VERSION=magnibot-`cat settings.default.json | grep version_code | awk '{print $2}' | tr -d '\"' | tr -d '\n'`.tar.gz
tar --exclude='./output' --exclude='./__pycache__' --exclude='./.github' --exclude='./.git' --exclude='./venv' --exclude='./.vscode' -cvzf build/$MAGNIBOT_VERSION ./
cd build
ftp -n ftp.trysight.com <<END_SCRIPT
quote USER 'brian@trysight.com'
quote PASS Magsalansan!48
binary 
cd magnibot
put $MAGNIBOT_VERSION
quit
END_SCRIPT
cd ~/magnibot
exit 0