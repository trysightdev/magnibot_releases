#!/bin/bash
mkdir output
tar --exclude='./output' --exclude='./__pycache__' --exclude='./.github' --exclude='./.git' --exclude='./venv' -cvzf output/magnibot.tar.gz ./