#!/bin/sh
CYAN='\033[0;36m'
NC='\033[0m'
GRE='\033[0;32m'
echo "\n${CYAN}########## Welcome! This script will turn your Raspberry Pi into  ##########"
echo          "########## a WiFi Access Point that will forward traffic through  ##########"
echo          "########## the ethernet port. Simply plug an ethernet cable into  ##########"
echo          "########## your Raspberry Pi, run this script, enter your desired ##########"
echo          "########## name and password, then reboot! Your network will then ##########"
echo          "########## be visible. Connect as you would to other networks!    ##########"



echo "\n${GRE}Setting up WiFi Access Point...${NC}"


sudo raspi-config nonint do_wifi_country US
cat << EOF > wpa_supplicant.conf
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1
country=US
network={
ssid="Acanac_05374"
psk="9057824004"
}
EOF
sudo cp wpa_supplicant.conf /etc/wpa_supplicant/

sudo apt-get install dnsmasq hostapd -y
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y netfilter-persistent iptables-persistent
sudo sed -i '$ainterface wlan0\nstatic ip_address=192.168.4.1/24\nnohook wpa_supplicant' /etc/dhcpcd.conf
sudo touch /etc/sysctl.d/routed-ap.conf
echo "net.ipv4.ip_forward=1" | sudo tee /etc/sysctl.d/routed-ap.conf
sudo mv /etc/dnsmasq.conf /etc/dnsmasq.conf.orig
sudo touch /etc/dnsmasq.conf
echo "interface=wlan0" | sudo tee /etc/dnsmasq.conf
sudo sed -i '$adhcp-range=192.168.4.5,192.168.4.100,255.255.255.0,24\ndomain=ap\naddress=/rpi.ap/192.168.4.1' /etc/dnsmasq.conf
sudo touch /etc/hostapd/hostapd.conf
echo "country_code=US" | sudo tee /etc/hostapd/hostapd.conf
sudo sed -i -e '$a\' -e "interface=wlan0\nssid=magnibot\nhw_mode=g\nchannel=2\nmacaddr_acl=0\nauth_algs=1\nignore_broadcast_ssid=0\n" /etc/hostapd/hostapd.conf
sudo systemctl unmask hostapd.service
sudo systemctl enable hostapd.service
sudo sed -i -e '$a\' -e "net.ipv4.ip_forward=1\n" /etc/sysctl.conf
sudo iptables -t nat -A  POSTROUTING -o wlan1 -j MASQUERADE
sudo netfilter-persistent save

echo "\n\n\n"
echo          "########## All Done! The RPi IP Address is 192.168.4.1 ##########"
echo          "########## You can also access your RPi at rpi.ap    ##########"
echo          "########## Please reboot for changes to take effect  ##########"
echo "\n\n\n"

