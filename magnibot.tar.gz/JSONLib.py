import json
import os
class JSONLib(object):
    _instance = None
    _debug = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(JSONLib, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        self.json_file = 'settings.json'
        if not os.path.exists(self.json_file):
            with open( 'settings.default.json', 'r') as f:
                self.data = json.load(f)
            with open( self.json_file , 'w') as f:
                json.dump(self.data, f)

        with open( self.json_file, 'r') as f:
            self.data = json.load(f)
        if self._debug:
            print(self.data)

        
    def set_version_code(self, version_code_value = "1.0"):
        self.data['version_code'] = version_code_value
        with open( self.json_file, 'w') as f:
            json.dump(self.data, f)

    def get_version_code(self):
        if self._debug:
            print(self.data['version_code'])
        return self.data['version_code'] 

    def set_rotation(self, rotation_value = 0):
        self.data['calibrated_rotation'] = rotation_value
        with open( self.json_file, 'w') as f:
            json.dump(self.data, f)

    def get_rotation(self):
        if self._debug:
            print(self.data['calibrated_rotation'])
        return self.data['calibrated_rotation'] 
    
    def set_brightness(self, brightness_value = 0):
        self.data['calibrated_brightness'] = brightness_value
        with open( self.json_file, 'w') as f:
            json.dump(self.data, f)

    def set_brightnessC(self, brightness_value = 0):
        self.data['calibrated_brightnessC'] = brightness_value
        with open( self.json_file, 'w') as f:
            json.dump(self.data, f)

    def get_brightness(self):
        if self._debug:
            print(self.data['calibrated_brightness'])
        return self.data['calibrated_brightness'] 
    
    def get_brightnessC(self):
        if self._debug:
            print(self.data['calibrated_brightnessC'])
        return self.data['calibrated_brightnessC'] 

    def set_contrast(self, contrast_value = 0):
        self.data['calibrated_contrast'] = contrast_value
        with open( self.json_file, 'w') as f:
            json.dump(self.data, f)

    def set_shaderIndex(self, shaderIndex = 0):
        self.data['shaderIndex'] = shaderIndex
        with open( self.json_file, 'w') as f:
            json.dump(self.data, f)

    def get_contrast(self):
        if self._debug:
            print(self.data['calibrated_contrast'])
        return self.data['calibrated_contrast']
    
    def get_shaderIndex(self):
        if self._debug:
            print(self.data['shaderIndex'])
        return self.data['shaderIndex'] 
    
    def set_video_mode(self, video_mode_value = 0):
        self.data['video_mode'] = video_mode_value
        with open( self.json_file, 'w') as f:
            json.dump(self.data, f)

    def get_video_mode(self):
        if self._debug:
            print(self.data['video_mode'])
        return self.data['video_mode'] 
    def set_video_resolution(self, video_resolution_value = 0):
        self.data['video_resolution'] = video_resolution_value
        with open( self.json_file, 'w') as f:
            json.dump(self.data, f)

    def get_video_resolution(self):
        if self._debug:
            print(self.data['video_resolution'])
        return self.data['video_resolution'] 
    def debug(self):
        with open( self.json_file, 'r') as f:
            self.data = json.load(f)
        if self._debug:
            print(self.data)


