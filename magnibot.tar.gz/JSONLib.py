import json
import os
import shutil
import threading
class JSONLib(object):
    _instance = None
    _debug = False
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(JSONLib, cls).__new__(cls)
        return cls._instance
    def __init__(self):
        self.json_file = 'settings.json'
        self.lock = threading.Lock()
        try:
            with open(self.json_file, 'r') as f:
                self.data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            shutil.copy('settings.default.json', 'settings.json')
            with open('settings.json', 'r') as f:
                self.data = json.load(f)
    def set_version_code(self, version_code_value="1.0"):
        with self.lock:
            self.data['version_code'] = version_code_value
            with open(self.json_file, 'w') as f:
                json.dump(self.data, f, indent=4)
    def get_version_code(self):
        with self.lock:
            return self.data['version_code']
    def set_rotation(self, rotation_value):
        with self.lock:
            self.data['calibrated_rotation'] = rotation_value
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
    def get_rotation(self):
        with self.lock:
            return self.data['calibrated_rotation']
    def set_brightness(self, brightness_value=0):
        with self.lock:
            self.data['calibrated_brightness'] = brightness_value
            with open(self.json_file, 'w') as f:
                json.dump(self.data, f, indent=4)
    def set_brightnessC(self, brightness_value=0):
        with self.lock:
            self.data['calibrated_brightnessC'] = brightness_value
            with open(self.json_file, 'w') as f:
                json.dump(self.data, f, indent=4)
    def get_brightness(self):
        with self.lock:
            return self.data['calibrated_brightness']
    def get_brightnessC(self):
        with self.lock:
            return self.data['calibrated_brightnessC']
    def set_shaderIndex(self, shaderIndex, p_orientation):
        with self.lock:
            tmp_index = self.parse_orientation_to_index(p_orientation)
            self.data['shaderIndex'][tmp_index] = shaderIndex
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
    def get_shaderIndex(self,p_orientation ):
        with self.lock:
            tmp_index = self.parse_orientation_to_index(p_orientation)
            return self.data['shaderIndex'][tmp_index]
    def set_contrast(self, contrast_value = 0):
        with self.lock:
            self.data['calibrated_contrast'] = contrast_value
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
    def get_contrast(self):
        with self.lock:
            return self.data['calibrated_contrast']
    def set_video_mode(self, video_mode_value = 0):
        with self.lock:
            self.data['video_mode'] = video_mode_value
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
    def get_video_mode(self):
        with self.lock:
            return self.data['video_mode'] 
    def set_video_resolution(self, video_resolution_value = 0):
        with self.lock:
            self.data['video_resolution'] = video_resolution_value
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
    def get_video_resolution(self):
        with self.lock:
            return self.data['video_resolution'] 
    def set_zoomIndex(self, zoomIndex, p_orientation):
        with self.lock:
            tmp_index = self.parse_orientation_to_index(p_orientation)
            self.data['zoomIndex'][tmp_index] = zoomIndex
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
    def get_zoomIndex(self,p_orientation ):
        with self.lock:
            tmp_index = self.parse_orientation_to_index(p_orientation)
            tmp_zoom = self.data['zoomIndex'][tmp_index]
            if tmp_zoom > 30:
                tmp_zoom = 30
            elif tmp_zoom < 1:
                tmp_zoom = 1
            return tmp_zoom
    def get_fragment_shaders(self):
        with self.lock:
            tShaders = self.data['fragmentShaders']
            return tShaders
    def set_fragment_shaders(self, pShaders):
        with self.lock:
            self.data['fragmentShaders'] = pShaders
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
    def get_refresh_rate(self):
        with self.lock:
            tShaders = self.data['refreshRate']
            return tShaders
    def set_refresh_rate(self, pShaders):
        with self.lock:
            self.data['refreshRate'] = pShaders
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
    def get_motor_speed(self):
        with self.lock:
            tShaders = self.data['motorSpeed']
            return tShaders
    def set_motor_speed(self, pShaders):
        with self.lock:
            self.data['motorSpeed'] = pShaders
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
                
    def get_mounted_rotation(self):
        with self.lock:
            tShaders = self.data['mounted_rotation']
            return tShaders
    def set_mounted_rotation(self, pShaders):
        with self.lock:
            self.data['mounted_rotation'] = pShaders
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)
                
    def get_motor_location_near(self):
        with self.lock:
            tShaders = self.data['motor_location_near']
            return tShaders
    def set_motor_location_near(self, pShaders):
        with self.lock:
            self.data['motor_location_near'] = pShaders
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)

    def get_motor_location_far(self):
        with self.lock:
            tShaders = self.data['motor_location_far']
            return tShaders
    def set_motor_location_far(self, pShaders):
        with self.lock:
            self.data['motor_location_far'] = pShaders
            with open( self.json_file, 'w') as f:
                json.dump(self.data, f,indent=4)


    def parse_orientation_to_index(self, p_orientation):
        tmp_index=0
        UNMOUNTED_FAR=p_orientation==1
        MOUNTED_NEAR=p_orientation==2
        MOUNTED_FAR=p_orientation==4
        # MOUNTED_DEADZONE=p_orientation==8
        # Mounted forward, deadzone and unmounted share the same color index
        if UNMOUNTED_FAR or MOUNTED_FAR:
            tmp_index=0
        elif MOUNTED_NEAR: # Change color index for near (mounted down)
            tmp_index=1
        return tmp_index
    def parse_orientation_to_rotation_index(self, p_orientation):
        tmp_index=0
        UNMOUNTED_FAR=p_orientation==1
        MOUNTED_NEAR=p_orientation==2
        MOUNTED_FAR=p_orientation==4
        # MOUNTED_DEADZONE=p_orientation==8
        # Mounted forward, deadzone and unmounted share the same color index
        if UNMOUNTED_FAR :
            tmp_index=0
        elif MOUNTED_NEAR or MOUNTED_FAR: # Change color index for near (mounted down)
            tmp_index=1
        return tmp_index
    def get_json_string(self):
        with self.lock:
            return json.dumps(self.data, indent=4)
    def set_json_obj_from_json_string(self, json_string):
        with self.lock:
            try:
                self.data = json.loads(json_string)
            except json.JSONDecodeError:
                raise ValueError("Invalid JSON string")
    def set_json_obj_from_json_obj(self, json_obj):
        with self.lock:
            if isinstance(json_obj, dict):
                self.data = json_obj
            else:
                raise ValueError("Invalid JSON object")

