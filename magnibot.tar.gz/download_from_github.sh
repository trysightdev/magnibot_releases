#!/bin/bash

{ # Prevent the script from executing until the client downloads the full file.

# Exit on first error.
set -e

# Echo commands to stdout.
set -x

while getopts v: flag
do
    case "${flag}" in
        v) TAG_VERSION=${OPTARG};;
    esac
done

git clone https://oauth2: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@github.com/trysightdev/magnibot.git /home/pi/tmp/
cd /home/pi/tmp/
git fetch --tags
git checkout $TAG_VERSION -b latest

} # Prevent the script from executing until the client downloads the full file.


