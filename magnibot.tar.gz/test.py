import socket
import netifaces as ni

def get_network_interfaces():
    interfaces = ni.interfaces()
    ip_addresses = {}
    
    for interface in interfaces:
        addrs = ni.ifaddresses(interface)
        # Check if the interface has an IPv4 address
        if ni.AF_INET in addrs:
            ip_info = addrs[ni.AF_INET][0]
            address = ip_info.get('addr')
            if address:
                ip_addresses[interface] = address
                
    return ip_addresses

if __name__ == "__main__":
    ip_addresses = get_network_interfaces()
    for interface, ip in ip_addresses.items():
        print(f"{interface}: {ip}")
