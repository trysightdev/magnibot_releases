import serial
import time

# Configure the serial connection
port = '/dev/ttyACM0'  # Replace with the actual port of your Arduino Leonardo
baud_rate = 9600

# Open the serial connection
arduino = serial.Serial(port, baud_rate, timeout=1)

try:
    # Main loop
    while True:
        # Read data from Arduino
        data = arduino.readline().decode().strip()
        
        # Print the received data
        print("Received data:", data)
        
        # Wait for 1 second
        time.sleep(1)

except KeyboardInterrupt:
    # Close the serial connection on program exit
    arduino.close()

