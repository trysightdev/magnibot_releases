#https://trysight.com/downloads/magnibot/latest.txt
import subprocess

subprocess.Popen(['rm','latest.txt'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
process = subprocess.Popen(['wget','https://trysight.com/downloads/magnibot/latest.txt'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = process.communicate()
out = out.decode("utf-8")
err = err.decode("utf-8")
print("", out, err)
f = open('latest.txt', 'r')
print(f.read())
f.close()
subprocess.Popen(['rm','latest.txt'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)