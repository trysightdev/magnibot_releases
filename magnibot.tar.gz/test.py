# main.py

from USBVideoDeviceMonitor import USBVideoDeviceMonitor

# Example callback function
def on_reconnect(device_path):
    print(f"Reconnected device: {device_path}")

if __name__ == "__main__":
    try:
        video_monitor = USBVideoDeviceMonitor(on_reconnect_callback=on_reconnect)
        video_monitor.start_monitoring()
        input("Press Enter to stop monitoring...\n")
        video_monitor.stop_monitoring()
    except KeyboardInterrupt:
        print("Stopped monitoring")