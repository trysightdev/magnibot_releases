motor_thread = None
motor_thread_lock = Lock()
h_direction = 0
def motor_loop():     
    global auto_counter
    global proc
    global h_direction 
    while True:  
        
        hMotor.motor_stop()
        if proc != None:
            proc.terminate()
        auto_counter = 0
        if h_direction == 1:
            h_direction = 0
        else:
            h_direction = 1
        proc = multiprocessing.Process(target=motor_task, args=())
        proc.start()
        socketio.sleep(2)
        print("Changed direction")


def motor_task():
    # block for a moment
    speed = .01
    if h_direction == 1:
        hMotor.motor_run(hGpioPins, speed,True,False,"half", .00)
    else:
        hMotor.motor_run(hGpioPins, speed,False,False,"half", .00)
    # display a message
    print('This is from another thread')

import multiprocessing
proc = None

auto_counter = 0
motor_thread = None
motor_thread_lock = Lock()
h_direction = 0
def motor_loop():     
    global auto_counter
    global proc
    global h_direction 
    while True:  
        
        hMotor.motor_stop()
        if proc != None:
            proc.terminate()
        auto_counter = 0
        if h_direction == 1:
            h_direction = 0
        else:
            h_direction = 1
        proc = multiprocessing.Process(target=motor_task, args=())
        proc.start()
        socketio.sleep(2)
        print("Changed direction")


def motor_task():
    # block for a moment
    speed = .01
    if h_direction == 1:
        hMotor.motor_run(hGpioPins, speed,True,False,"half", .00)
    else:
        hMotor.motor_run(hGpioPins, speed,False,False,"half", .00)
    # display a message
    print('This is from another thread')

import multiprocessing
proc = None

auto_counter = 0

def autonomous_motors():
    with motor_thread_lock:
        if motor_thread is None:
            motor_thread = socketio.start_background_task(motor_loop)