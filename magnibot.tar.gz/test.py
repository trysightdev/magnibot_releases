
import ArduinoReader as ArduinoReader
arduino_thread = None

arduino_thread = ArduinoReader.ArduinoReader() # replace '/dev/ttyACM0' with your port and 9600 with your baud rate
